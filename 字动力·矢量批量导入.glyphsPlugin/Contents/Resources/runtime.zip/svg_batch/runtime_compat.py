"""Read-only evidence about the Python actually loaded by this Glyphs process.

No dependency installs, sys.path changes, runtime replacement or class enumeration.
"""
import json,platform,sys
from pathlib import Path
_warned=False

def classify(python,pyobjc,system,glyphs,build,machine):
    try:
        number=float(build)
        build=str(int(number)) if number.is_integer() else str(build)
    except (ValueError,TypeError):build=str(build)
    if pyobjc=='10.2':
        return 'known-risk','已知风险：PyObjC 10.2 空参数回调可触发原生关闭崩溃。'
    if (python,pyobjc,system,glyphs,str(build),machine)==('3.11.9','11.1','26.1','3.5','3532','arm64'):
        return 'locally-verified','本机组合已验证；不代表全部第三方插件或其他设备均兼容。'
    return 'unverified','此组合尚未验收；不能根据版本较新就认定兼容。'

def snapshot():
    import objc,objc._objc,Foundation,AppKit
    from GlyphsApp import Glyphs
    import GlyphsApp.plugins as sdk
    python=platform.python_version();bridge=str(objc.__version__)
    system=platform.mac_ver()[0];glyphs=str(Glyphs.versionNumber);build=str(int(Glyphs.buildNumber))
    status,message=classify(python,bridge,system,glyphs,build,platform.machine())
    selected=str(Glyphs.defaults['GSPythonFrameworkPath'] or '')
    return dict(schema=1,python=python,pyobjc=bridge,macos=system,glyphs=glyphs,build=build,machine=platform.machine(),
        status=status,message=message,python_prefix=sys.prefix,python_executable=sys.executable,
        objc_module=str(objc.__file__),objc_binary=str(objc._objc.__file__),foundation_module=str(Foundation.__file__),
        appkit_module=str(AppKit.__file__),sdk_module=str(sdk.__file__),selected_python_preference=selected,
        temporary_path=any(part in ('diagnostics','build','backups') for part in Path(sys.prefix).parts),
        scope='Actual imported modules; preference is recorded separately and is not proof of loading.')

def text(info):
    pairs=[('检测结果',info['message']),('Python',info['python']),('PyObjC',info['pyobjc']),
        ('macOS',info['macos']),('Glyphs',info['glyphs']+' ('+info['build']+')'),('处理器',info['machine']),
        ('实际 Python 前缀',info['python_prefix']),('实际 PyObjC 二进制',info['objc_binary']),
        ('实际 Foundation',info['foundation_module']),('实际 AppKit',info['appkit_module']),
        ('实际 Glyphs SDK',info['sdk_module']),('已选择路径（下次启动设置）',info['selected_python_preference'])]
    result='\n\n'.join(k+'：\n'+v for k,v in pairs)
    if info['temporary_path']:result+='\n\n当前路径属于开发/诊断目录，请使用独立环境助手迁移到用户运行环境目录。'
    return result+'\n\n检测只读取信息，不安装依赖、不改变字体或工程。更新插件无需重复配置已验收环境。'

def show(panel,sender=None):
    if panel.raise_dialog('运行环境'):return
    import vanilla
    info=snapshot();w=panel.dialog((740,570),'运行环境')
    w.report=vanilla.TextEditor((20,20,-20,-65),text(info),readOnly=True)
    w.done=vanilla.Button((-150,-45,130,25),'关闭',callback=lambda s:panel.close_dialog(w))
    from .model import atomic_json
    from .storage import prepare
    atomic_json(prepare()/'reports'/'runtime-current.json',info)
    panel.show_dialog(w)

def check_launch():
    """Report once; never install/switch a runtime from customer plugin startup."""
    global _warned
    from .model import atomic_json
    from .storage import prepare
    info=snapshot();atomic_json(prepare()/'reports'/'runtime-current.json',info)
    if info['status']=='known-risk' and not _warned:
        from AppKit import NSAlert,NSAlertFirstButtonReturn
        _warned=True;a=NSAlert.alloc().init()
        a.setMessageText_('当前 PyObjC 10.2 存在已知关闭崩溃风险')
        a.setInformativeText_('建议先按运行环境指南准备并明确启用兼容环境，再重启 Glyphs。插件不会自动安装依赖或替换共享环境；继续打开也不能消除其他插件回调的风险。已有工程与字体不会被清空。')
        a.addButtonWithTitle_('取消打开');a.addButtonWithTitle_('仍然打开')
        return a.runModal()!=NSAlertFirstButtonReturn
    return True
