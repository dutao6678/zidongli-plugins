"""Lazy presentation messages. Canonical Chinese stays byte-for-byte unchanged.

No global UI patches. Only our presentation facade renders messages. JSON,
comparisons, glyph values, signatures and paths continue to use canonical text.
Resources ship inside runtime.zip and are pinned by the native integrity gate.
"""
import builtins,functools,hashlib,json,re,string
from importlib.resources import files
LANGUAGES=('zh-Hans','zh-Hant','en','ja','ko')
NAMES=('简体中文','繁體中文','English','日本語','한국어')
_active='zh-Hans'
_catalogs={}
_formatter=string.Formatter()
_percent=re.compile(r'%(?:\(([^)]+)\))?([-+#0 ]*\d*(?:\.\d+)?[diouxXeEfFgGcrsa%])')

def key(source):return hashlib.sha256(source.encode('utf-8')).hexdigest()[:16]

def percent_template(source):
    specs=[];used={}
    def part(m):
        spec=m[2]
        if spec=='%':return '%'
        base=m[1] or ('number' if spec[-1] in 'diouxXeEfFgG' else 'value')
        used[base]=used.get(base,0)+1;name=base if used[base]==1 else base+'_'+builtins.str(used[base])
        specs.append((name,'%'+spec,m[1]));return '{'+name+'}'
    return _percent.sub(part,source),specs

def normalize(source):
    if _percent.search(source):return percent_template(source)[0]
    return source

def catalog(language):
    if language not in _catalogs:
        _catalogs[language]=json.loads(files('svg_batch').joinpath('locales',language+'.json').read_text(encoding='utf-8'))
    return _catalogs[language]

def language():return _active

def activate(language):
    global _active
    if language not in LANGUAGES:language='zh-Hans'
    # Read and validate before altering active presentation, never mid-task.
    catalog(language);_active=language
    import sys
    panel=sys.modules.get('svg_batch.panel')
    if panel is not None:
        for name in ('measure_text','fitted_text'):
            callback=getattr(panel,name,None)
            if callback is not None and hasattr(callback,'cache_clear'):callback.cache_clear()

def template(source,params=None):
    k=key(source);fallback=catalog('zh-Hans').get(k) or normalize(source)
    result=catalog(_active).get(k) or fallback
    if isinstance(result,dict) and 'text' in result:
        text=result['text']
        for name,rule in result.get('plural',{}).items():
            count=(params or {}).get(rule['count'])
            try:singular=float(count)==1
            except (TypeError,ValueError):singular=False
            text=text.replace('{'+name+'}',rule['one' if singular else 'other'])
        return text
    if isinstance(result,dict):
        numeric=[v for n,v in (params or {}).items() if n.startswith(('number','count','total'))]
        result=result.get('one' if numeric and numeric[0]==1 else 'other') or result.get('other') or fallback
    return result

class Message(str):
    def __new__(cls,canonical,node=None):
        obj=str.__new__(cls,canonical);obj.node=node or ('literal',canonical);return obj
    def __str__(self):return str.__str__(self)
    def __add__(self,other):
        if not isinstance(other,str):return NotImplemented
        return Message(str.__add__(self,other),('parts',(self,other)))
    def __radd__(self,other):
        if not isinstance(other,str):return NotImplemented
        return Message(str.__add__(other,self),('parts',(other,self)))
    def __mod__(self,args):return percent_message(self,args)
    def format(self,*args,**kwargs):
        # Our source templates use named arguments; preserve existing positional
        # formats too without exporting or rewriting user text.
        canonical=str.format(self,*args,**kwargs)
        return Message(canonical,('format',str.__str__(self),tuple(_freeze(v) for v in args),{k:_freeze(v) for k,v in kwargs.items()}))
    def join(self,values):return join_message(self,values)
    def replace(self,old,new,count=-1):
        return Message(str.replace(self,old,new,count),('replace',self,old,new,count))
    def __reduce__(self):return Message,(str.__str__(self),self.node)

@functools.lru_cache(maxsize=2048)
def message(source):return Message(source)

def _freeze(value):
    if isinstance(value,(str,int,float,bool)) or value is None:return value
    return builtins.str(value)

def string_message(value='',*args,**kwargs):
    if isinstance(value,Message) and not args and not kwargs:return value
    if isinstance(value,BaseException) and len(value.args)==1 and isinstance(value.args[0],Message) and not args and not kwargs:return value.args[0]
    return builtins.str(value,*args,**kwargs)

def percent_message(source,args):
    canonical=str.__mod__(source,args)
    values=args if isinstance(args,tuple) else (args,)
    if not isinstance(source,Message) and not any(isinstance(v,Message) for v in values):return canonical
    source=str.__str__(source);_,specs=percent_template(source);params={};raw={}
    for i,(name,spec,mapping) in enumerate(specs):
        v=args[mapping] if mapping else values[i]
        params[name]=v if isinstance(v,Message) and spec.endswith('s') else str.__mod__(spec,v)
        raw[name]=v if isinstance(v,(int,float)) else None
    return Message(canonical,('percent',source,params,raw))

def format_message(source,/,**kwargs):
    canonical=str.format(source,**kwargs)
    return Message(canonical,('format',source,(),{k:_freeze(v) for k,v in kwargs.items()}))

def join_message(separator,values):
    values=list(values);canonical=str.join(separator,values)
    if not isinstance(separator,Message) and not any(isinstance(v,Message) for v in values):return canonical
    parts=[]
    for i,v in enumerate(values):
        if i:parts.append(separator)
        parts.append(v)
    return Message(canonical,('parts',tuple(parts)))

def render(value):
    """Opaque ordinary strings (including exact matches to UI text) never translate."""
    if not isinstance(value,Message):return value
    node=value.node;kind=node[0]
    if kind=='parts':return ''.join(render(v) for v in node[1])
    if kind=='replace':return render(node[1]).replace(render(node[2]),render(node[3]),node[4])
    if kind=='literal':return template(node[1])
    if kind=='percent':
        _,source,params,raw=node
        return template(source,raw).format(**{k:render(v) for k,v in params.items()})
    if kind=='format':
        _,source,args,kwargs=node
        return template(source,kwargs).format(*(render(v) for v in args),**{k:render(v) for k,v in kwargs.items()})
    raise ValueError('Invalid presentation message')

def data(value):
    """Recursively render only tagged messages, leaving dict keys and opaque data."""
    if isinstance(value,Message):return render(value)
    if isinstance(value,list):return [data(v) for v in value]
    if isinstance(value,tuple):return tuple(data(v) for v in value)
    if isinstance(value,dict):return {k:data(v) for k,v in value.items()}
    return value

def preferred():
    from .storage import DATA_ROOT
    try:value=json.loads((DATA_ROOT/'ui-preferences.json').read_text()).get('interface_language','zh-Hans')
    except (OSError,ValueError,TypeError):value='zh-Hans'
    return value if value in LANGUAGES else 'zh-Hans'

def save_preferred(value):
    if value not in LANGUAGES:raise ValueError('Invalid interface language')
    from .storage import DATA_ROOT
    from .model import atomic_json
    p=DATA_ROOT/'ui-preferences.json'
    try:prefs=json.loads(p.read_text())
    except FileNotFoundError:prefs={}
    if not isinstance(prefs,dict):raise ValueError(message('界面偏好文件无效；未覆盖原文件'))
    prefs['interface_language']=value;atomic_json(p,prefs)

def prepare_open():
    from .panel_entry import all_panels,live_panel
    if not any(live_panel(p) for p in all_panels()):activate(preferred())

def native_message(value):
    # Native verification emits a fixed, public set of messages. Do not attempt
    # fuzzy translation of arbitrary host/OS exceptions or file paths.
    if isinstance(value,Message):return value
    # Only errors originating from the native verifier are eligible for exact
    # matching. An ordinary label/file called e.g. '关闭' stays opaque.
    prefixes=('授权','机器码','设备标识','无法读取稳定设备标识','验证参数','产品分支','产品包路径','插件完整性','批次','活动批次','上下文/清单','原生批次')
    return message(value) if isinstance(value,str) and value.startswith(prefixes) and key(value) in catalog('zh-Hans') else value
