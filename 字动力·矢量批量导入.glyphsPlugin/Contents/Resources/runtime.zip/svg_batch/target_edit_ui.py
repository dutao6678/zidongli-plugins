from .i18n import message as M,format_message as MF,percent_message as MP,join_message as MJ,string_message as ms,render as R
"""One session-owned correction dialog, sharing the existing plan transaction."""
import copy
from . import localized_ui as vanilla
from Foundation import NSAttributedString
from .target_edit import parse_target,check_target,apply_target,codes
from .host import unicode_matches
from .native_collections import native_items
from .editor_fonts import entry_attributed,entry_warning,private_use,display_font
from AppKit import NSImage,NSColor,NSAffineTransform
from .model import states_equal
from .record_display import font_map

TITLE=M('修改目标字符／编码')

def display_warning(entry):
    warning=entry_warning(entry)
    if not warning and not private_use(entry['value']) and not display_font(entry['value'],16,None)[1]:
        warning=MF('{detail} 缺少可用显示字体；底层字符保持不变。',detail=codes(entry['value']))
    return warning


class TargetEditingUI:
    def open_target_edit(self,s=None,entry_id=None,initial=None,parent=None):
        def action():
            if self.raise_dialog(TITLE):return
            eid=entry_id or self.project.state['entries'][self.index()]['id']
            old=next(e for e in self.project.state['entries'] if e['id']==eid)
            w=self.dialog((650,405),TITLE,parent=parent);self.target_edit_window=w
            w.entry_id=eid;w.checked=None
            w.help=vanilla.TextBox((20,18,610,40),M('只修改本项导入目标，保留位置和 素材；不改字体编码。输入单个字符或 U+4E00、uni4E00、0x4E00。'))
            if old.get('host_binding'):w.help.set(MF('原目标为宿主字形 {glyph_name}。应用后解除原对象绑定，按新字符／编码重新匹配；不重编码字体。',glyph_name=old['host_binding']['glyph_name']))
            w.original=vanilla.TextBox((20,65,610,35),'')
            header=entry_attributed(old,16);header.appendAttributedString_(NSAttributedString.alloc().initWithString_(R(MF('  {detail}（原目标）',detail=codes(old['value'])))))
            w.original.getNSTextField().setAttributedStringValue_(header)
            w.input=vanilla.EditText((20,110,610,28),old['value'] if initial is None else initial,callback=lambda sender:self.target_input_changed(w))
            w.preview=vanilla.TextBox((20,150,610,35),'')
            w.match=vanilla.ImageView((530,200,100,105))
            w.result=vanilla.TextBox((20,192,495,125),M('输入后点击“核对目标”，查看字体匹配与冲突。'))
            w.verify=vanilla.Button((20,350,130,30),M('核对目标'),callback=lambda sender:self.verify_target_edit(w))
            w.cancel=vanilla.Button((350,350,110,30),M('取消'),callback=lambda sender:self.finish_dialog(w))
            w.apply=vanilla.Button((475,350,155,30),M('应用目标修改'),callback=lambda sender:self.commit_target_edit(w));w.apply.enable(False)
            self.show_dialog(w);self.target_input_changed(w)
        self.guard(action)

    def target_input_changed(self,w):
        w.checked=None;w.apply.enable(False);w.match.getNSImageView().setImage_(None)
        if not self.dialog_alive(w):return
        try:
            value=parse_target(ms(w.input.getNSTextField().stringValue()))
            entry=dict(value=value)
            old=next(e for e in self.project.state['entries'] if e['id']==w.entry_id)
            if value==old['value'] and old.get('display'):entry['display']=copy.deepcopy(old['display'])
            field=w.input.getNSTextField();editor=field.currentEditor()
            if editor is None or not editor.hasMarkedText():
                font,_=display_font(value,13,font_map(entry).get(0))
                if ms(field.stringValue())!=value:font,_=display_font('A',13,None)
                field.setFont_(font)
            header=entry_attributed(entry,16);header.appendAttributedString_(NSAttributedString.alloc().initWithString_(R('  '+codes(value)+(M(' · 私用区，未转换为标准汉字') if private_use(value) else ''))))
            w.preview.getNSTextField().setAttributedStringValue_(header)
            w.result.set(MF('{detail}尚未核对目标字体；点击“核对目标”。',detail=display_warning(entry)+'\n' if display_warning(entry) else ''))
        except Exception as exc:w.preview.set(M('输入待修正'));w.result.set(ms(exc))

    def target_host_result(self,value):
        font=self.locked_font
        if font is None:return M('尚未选择目标字体，未核验宿主字形；导入前仍须选择目标并预检。'),None
        from GlyphsApp import Glyphs
        if not any(f is font or f==font for f in native_items(Glyphs.fonts)):raise ValueError(M('目标字体已关闭，请重新选择目标'))
        matches=unicode_matches(font,ord(value))
        names=tuple(ms(g.name) for g in matches)
        if len(matches)>1:raise ValueError(MF('同一编码匹配多个宿主字形：{detail}；请先消除歧义。',detail=MJ(', ',names)))
        result=MF('目标字体：{detail}\n',detail=ms(font.familyName))
        result+=(MF('已匹配字形：{detail} · {detail_2}',detail=names[0],detail_2=codes(value))) if names else M('目标字形不存在；当前未匹配。实际导入须明确启用创建选项。')
        if matches:
            layer=matches[0].layers[self.locked_master] if self.locked_master else None
            result+='\n'+(M('匹配层暂无轮廓') if layer is not None and not len(layer.shapes) else M('指定母版层不存在') if layer is None else M('右侧为目标字体当前轮廓'))
        return result,(id(font),self.locked_master,names)

    def target_match_image(self,value):
        if self.locked_font is None:return None
        matches=unicode_matches(self.locked_font,ord(value))
        if len(matches)!=1 or not self.locked_master:return None
        layer=matches[0].layers[self.locked_master]
        if layer is None:return None
        path=layer.bezierPath
        if path is None:return None
        path=path.copy();bounds=path.bounds()
        if bounds.size.width<=0 or bounds.size.height<=0:return None
        scale=min(88/bounds.size.width,88/bounds.size.height)
        transform=NSAffineTransform.transform()
        transform.translateXBy_yBy_((100-bounds.size.width*scale)/2,(100-bounds.size.height*scale)/2)
        transform.scaleBy_(scale);transform.translateXBy_yBy_(-bounds.origin.x,-bounds.origin.y)
        path.transformUsingAffineTransform_(transform)
        image=NSImage.alloc().initWithSize_((100,100));image.lockFocus()
        try:NSColor.labelColor().set();path.fill()
        finally:image.unlockFocus()
        return image


    def verify_target_edit(self,w):
        if not self.dialog_alive(w):return
        try:
            value=parse_target(ms(w.input.getNSTextField().stringValue()));old=check_target(self.project.state,w.entry_id,value)
            message,host=self.target_host_result(value)
            w.match.getNSImageView().setImage_(self.target_match_image(value))
            entry=dict(value=value)
            if value==old['value'] and old.get('display'):entry['display']=copy.deepcopy(old['display'])
            warning=display_warning(entry)
            w.result.set(MF('{message}{detail}{detail_2}\n只改变导入计划；素材、原位置和几何设置保持。',message=message,detail=M('\n应用将解除原宿主字形绑定，改用新编码匹配。') if old.get('host_binding') else '',detail_2='\n'+warning if warning else ''))
            w.checked=dict(value=value,state=copy.deepcopy(self.project.state),host=host,display=entry.get('display'))
            w.apply.enable(True)
        except Exception as exc:w.checked=None;w.apply.enable(False);w.result.set(ms(exc))

    def commit_target_edit(self,w):
        if not self.dialog_alive(w):return
        def action():
            checked=w.checked
            if not checked:raise ValueError(M('请先核对目标'))
            if parse_target(ms(w.input.getNSTextField().stringValue()))!=checked['value']:raise ValueError(M('输入已变化，请重新核对'))
            _,host=self.target_host_result(checked['value'])
            if host!=checked['host'] or not states_equal(self.project.state,checked['state']):
                w.checked=None;w.apply.enable(False);raise ValueError(M('计划或目标字体已变化，请重新核对'))
            apply_target(self.project,w.entry_id,checked['value'],checked['display'],checked['state'])
            self.w.value.set(checked['value']);self.finish_dialog(w)
            # Detail resolves its existing stable entry ID; keep its view and zoom.
            self.refresh_detail()
        self.guard(action)
