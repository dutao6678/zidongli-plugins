"""Panel-local document ownership. No geometry or global host undo changes."""
import copy
from .native_collections import native_items
from .host_targets import same_object,prune_sessions,record

class DocumentOwner:
    def check_owner(self,allow_detached=False):
        self.update_document_context()
        if allow_detached:return
        if self.owner_invalid or self.owner_font is None:
            raise ValueError('所属字体文档已关闭或未关联；请使用文件 → 重新关联当前字体，核对后采用')
        if self.locked_font is not None and not same_object(self.locked_font,self.owner_font):
            raise ValueError('工程目标不是此面板所属文档；请重新关联，不能写入其他字体')

    def start_document_observer(self):
        from GlyphsApp import Glyphs,DOCUMENTCLOSED
        self._document_callback=self.document_will_close
        Glyphs.addCallback(self._document_callback,DOCUMENTCLOSED)

    def stop_document_observer(self):
        from GlyphsApp import Glyphs,DOCUMENTCLOSED
        callback=getattr(self,'_document_callback',None)
        if callback is not None:Glyphs.removeCallback(callback,DOCUMENTCLOSED);self._document_callback=None

    def document_will_close(self,notification):
        owner=getattr(self,'owner_font',None)
        if owner is not None and same_object(notification.object(),owner.parent):
            self.update_document_context(force_closed=True)
            self.refresh()

    def update_document_context(self,force_closed=False):
        from GlyphsApp import Glyphs
        if getattr(self,'_closed',False):return False
        owner=getattr(self,'owner_font',None);changed=False
        if owner is not None and (force_closed or not any(same_object(owner,f) for f in native_items(Glyphs.fonts))):
            self.owner_name=str(owner.familyName or '未命名字体')
            self.owner_font=None;self.owner_invalid=True
            self.locked_font=None;self.locked_master=None;self.pending_host=None
            self.cancel_host_read();self.cancel_pdf_intake()
            if getattr(self,'preview_lookup',None):self.preview_lookup.close()
            from .host_index import release
            release(owner)
            if self.timer:
                self.timer.invalidate();self.timer=None
                if self.host:self.host.cancelled=True
            if getattr(self,'tick_target',None):self.tick_target.owner=None
            # Journals remain on disk; closed GSFont/GSLayer proxies cannot be used again.
            detached=getattr(self,'detached_recoveries',[])
            for host in [self.host]+list(self.archived_hosts):
                if host is not None:
                    if host.started:host.journal()
                    host.release_permit()
                    detached.append(dict(run_id=host.run_id,root=str(host.root),backup=str(host.backup)))
            self.detached_recoveries=detached;self.host=None;self.archived_hosts=[]
            self.target_fonts=[];self.target_masters=[]
            for child in list(self.dialogs):
                if child.getNSWindow() is not None:child.close()
            self.gestures.active=None;self.gestures.pending=None
            self.drop_draft=None;self.drop_overlay={};self.drop_range=None
            self.cache.clear();self.errors.clear();self.render_cache.clear()
            prune_sessions([f for f in native_items(Glyphs.fonts) if not same_object(owner,f)])
            self.result_message='所属字体已关闭；工程和恢复资料保留，写入已禁用。请明确重新关联。'
            changed=True
        owner=getattr(self,'owner_font',None)
        name=str(owner.familyName or '未命名字体') if owner is not None else getattr(self,'owner_name','未关联字体')
        title='字动力 · 矢量批量导入 — '+name+('（文档已关闭）' if self.owner_invalid else '')
        window=self.main.getNSWindow()
        if window is not None and str(window.title())!=title:window.setTitle_(title)
        current=str(owner.selectedFontMaster.id) if owner is not None and owner.selectedFontMaster else None
        observation=(current,self.locked_master)
        if getattr(self,'_master_observation',observation)!=observation:
            self.pending_host=None
            self.result_message='宿主母版已切换；本面板仍绑定原母版。若要改绑，请使用文件 → 重新关联当前字体。'
            changed=True
        self._master_observation=observation
        return changed

    def reassociate(self,font,master_id):
        """Explicitly reviewed exact name + full Unicode provenance, never automatic."""
        from .panel_entry import document_panel,register_panel
        from .panel_actions import alert
        self.check_owner(allow_detached=True)
        other=document_panel(font)
        if other is not None and other is not self:
            raise ValueError('此字体已有独立面板，请使用其面板打开工程；不会合并两个工程')
        if self.owner_font is not None and not same_object(font,self.owner_font):
            raise ValueError('不能将此面板改绑到其他已打开文档，请在对应文档打开独立面板')
        from .host import unicode_values
        resolved=[];problems=[]
        from .host_index import service,identity
        snapshot=service(font).authoritative('explicit-reassociation')
        for entry in self.project.state['entries']:
            binding=entry.get('host_binding')
            if not binding:continue
            matches=[g for g in snapshot.by_name.get(binding['glyph_name'],()) if list(snapshot.codes[identity(g)])==binding['unicodes']]
            if len(matches)!=1:problems.append(binding['glyph_name']+'：缺失或身份信息不一致')
            else:resolved.append((entry,matches[0]))
        if problems:raise ValueError('重新关联未采用，原工程不变：\n'+'\n'.join(problems[:30]))
        master=next(m for m in native_items(font.masters) if str(m.id)==str(master_id))
        if not alert('明确重新关联：%s / %s\n核对 %d 项宿主目标（字形名和完整Unicode集一致）。\n此操作创建新的文档绑定，保留当前顺序和素材；旧预检失效。\n原恢复记录不会转移到新文档。是否采用？'%(font.familyName,master.name,len(resolved)),True):return
        replacements={}
        for entry,glyph in resolved:
            new=copy.deepcopy(entry);fresh=record(font,glyph,master_id,entry.get('original_position',1))
            new.setdefault('binding_history',[]).append(copy.deepcopy(entry['host_binding']))
            new['host_binding']=fresh['host_binding'];replacements[entry['id']]=new
        def apply():
            self.project.state['entries']=[replacements.get(e['id'],e) for e in self.project.state['entries']]
            self.project.state['target']=dict(font_path=str(font.filepath),family=str(font.familyName),master_id=str(master.id),master_name=str(master.name))
        self.project.edit(apply)
        if self.host is not None and not same_object(getattr(self.host,'font',None),font):
            self.archived_hosts.append(self.host);self.host=None
        self.owner_font=font;self.owner_invalid=False;self.locked_font=font;self.locked_master=str(master.id)
        self.pending_host=None;self.cache.clear();self.errors.clear()
        if not self.isolated:register_panel(self)
        self.update_document_context()
