from .i18n import message as M,format_message as MF,percent_message as MP,join_message as MJ,string_message as ms,render as R
"""Session-owned activation window. No new native subclasses or tooltips."""
from . import localized_ui as vanilla
from .version import VERSION
from .detail_text import DetailText
from .licensing import machine_code,status_text,install_license
from .panel_actions import choose,alert

def show(panel,sender=None):
    if panel.raise_dialog(M('授权与激活')):return
    w=panel.dialog((760,500),M('授权与激活'))
    w.heading=vanilla.TextBox((20,20,720,24),MF('字动力 · 矢量批量导入 {VERSION} · 离线授权',VERSION=VERSION))
    w.state=DetailText((20,53,720,90));w.state.update(status_text())
    w.label=vanilla.TextBox((20,153,720,22),M('机器码（选中文字后可复制，发送给作者签发授权）：'))
    w.machine=DetailText((20,180,720,68))
    try:w.machine.update(machine_code())
    except ValueError as exc:w.machine.update(ms(exc))
    w.note=vanilla.TextBox((20,260,720,82),M('机器码为设备标识的产品专用摘要，不包含设备序列号、IP或用户名。\n未激活或到期仅限制新写入；已有工程仍可查看、保存和恢复。'))
    def activate(sender):
        paths=choose(types=['svglicense'])
        if not paths:return
        try:install_license(paths[0],confirm_shorter=lambda old,new:alert(M('此授权将缩短当前有效期（例如短期到期测试）。原授权不会被撤销，请先保管原授权文件。确认替换本机授权？'),True))
        except (ValueError,OSError) as exc:alert(exc);return
        panel.license_monitor.poll(force=True);panel.refresh()
    w.activate=vanilla.Button((20,350,230,30),M('导入授权文件…'),callback=activate)
    w.done=vanilla.Button((-190,-50,170,30),M('完成'),callback=lambda s:panel.finish_dialog(w))
    from .deactivation_ui import confirm,show_receipts,refresh_actions
    w.revoke=vanilla.Button((270,350,220,30),M('注销此设备…'),callback=lambda s:confirm(panel,w))
    w.receipts=vanilla.Button((510,350,230,30),M('查看注销凭证…'),callback=lambda s:show_receipts(panel,w))
    refresh_actions(panel,w,recheck=True)
    panel.show_dialog(w)
