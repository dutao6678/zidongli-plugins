"""User-owned mutable data; never write into an installed bundle."""
from pathlib import Path

DATA_ROOT=Path.home()/'Library'/'Application Support'/'SVG拖拽批量导入'
CACHE_ROOT=Path.home()/'Library'/'Caches'/'local.svg-batch-import'

def prepare():
    for p in (DATA_ROOT,DATA_ROOT/'reports',DATA_ROOT/'backups',DATA_ROOT/'projects',CACHE_ROOT):
        p.mkdir(parents=True,exist_ok=True)
    return DATA_ROOT
