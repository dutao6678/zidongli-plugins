from .i18n import message as M,format_message as MF,percent_message as MP,join_message as MJ,string_message as ms,render as R
"""Main-thread native mouse gestures. NSDraggingSession owns cancellation."""
import copy,math,objc
import time
from uuid import uuid4
from AppKit import (NSView,NSCursor,NSColor,NSBezierPath,NSImage,NSDraggingItem,
    NSPasteboardItem,NSDragOperationMove,NSDragOperationNone,NSCommandKeyMask,
    NSShiftKeyMask,NSAlternateKeyMask,NSControlKeyMask,NSButton,NSCompositeSourceOver,NSGraphicsContext,NSPointInRect,NSFilenamesPboardType)
from .rearrange import key,plan,adopt
from .drop import pool_batch_candidate
from .model import states_equal
from .hit_testing import card_rect,intersects,resolve_drop,insertion_line,DropLocation,CARD_INSET,marquee_indices
from .panel_actions import text,alert
TYPE='local.svg-batch.assignment-drag'

class Gestures:
    def __init__(self,p):
        self.p=p;self.keys=set();self.anchor=None;self.active=None;self.pending=None
        self.highlight=set();self.insert_cell=None;self.error='';self.split_start=None
        self.events=[];self.drag_moves=0;self.rubber=None
    def record(self,name,detail=None):
        self.events.append(dict(event=name,time=time.time(),detail=detail,assignments=dict(self.p.project.state['assignments']),undo=len(self.p.project.undo_stack),redo=len(self.p.project.redo_stack)))
        self.events=self.events[-100:]
    def selected(self,c):return key(c) in self.keys
    def select(self,c,flags=0,preserve=False):
        p=self.p;old=set(self.keys)
        if c is None:self.keys.clear();self.anchor=None;p.selected=None;p.selection_changed(old);return
        k=key(c);grid=p.grid if c['kind']=='target' else p.pool_grid
        if any(a[0]!=k[0] for a in self.keys):self.keys.clear()
        if flags&NSShiftKeyMask and self.anchor in [key(x) for x in grid.cells]:
            values=[key(x) for x in grid.cells];a=values.index(self.anchor);b=values.index(k)
            chosen=set(values[min(a,b):max(a,b)+1])
            self.keys=self.keys|chosen if flags&NSCommandKeyMask else chosen
        elif flags&NSCommandKeyMask:
            if k in self.keys:self.keys.remove(k)
            else:self.keys.add(k)
            self.anchor=k
        elif not (preserve and k in self.keys):self.keys={k};self.anchor=k
        p.selected=c if k in self.keys else next((x for x in grid.cells if key(x) in self.keys),None)
        if c['kind']=='target':p.w.position.set(ms(c['position']));p.w.value.set(c['entry']['value'])
        p.selection_changed(old)
    def select_all(self,view):
        old=set(self.keys)
        self.keys={key(c) for c in view.cells};self.anchor=key(view.cells[0]) if view.cells else None
        self.p.selected=view.cells[0] if view.cells else None;self.p.selection_changed(old,view=view);self.record('select_all',dict(pool=view.pool,count=len(self.keys)))
    def begin_rubber(self,view,event):
        point=view.convertPoint_fromView_(event.locationInWindow(),None)
        flags=event.modifierFlags();self.rubber=dict(view=view,start=(point.x,point.y),end=(point.x,point.y),before=set(self.keys),base={k for k in self.keys if k[0]==('pool' if view.pool else 'target')},flags=flags,dragged=False,box=(point.x,point.y,0.,0.))
        # Defer selection changes until a real marquee or the blank click ends.
        # Clearing here loses the old selection delta and leaves stale outlines.
    def update_rubber(self,view,event):
        if not self.rubber:return
        view.autoscroll_(event);point=view.convertPoint_fromView_(event.locationInWindow(),None);r=self.rubber
        if not r['dragged'] and math.hypot(point.x-r['start'][0],point.y-r['start'][1])<3:return
        r['dragged']=True
        old=set(self.keys);old_box=r['box']
        r['end']=(point.x,point.y);x,y=r['start'];rect=(min(x,point.x),min(y,point.y),abs(x-point.x),abs(y-point.y));r['box']=rect
        hits={key(view.cells[i]) for i in marquee_indices(rect,len(view.cells),view.cols,view.unit,view.row_height,view.card_height)}
        base=r['base']
        self.keys=base^hits if r['flags']&NSCommandKeyMask else base|hits if r['flags']&NSShiftKeyMask else hits
        if self.p.selected is None or key(self.p.selected) not in self.keys:self.p.selected=next((c for c in view.cells if key(c) in self.keys),None)
        self.p.selection_changed(old,view=view,boxes=(old_box,rect),final=False)
    def cancel_rubber(self):
        if not self.rubber:return
        view=self.rubber['view'];view.down_event=None;view.origin=None;box=self.rubber['box'];old=set(self.keys)
        self.keys=set(self.rubber['before']);self.rubber=None
        self.p.selected=next((c for c in self.p.grid.cells+self.p.pool_grid.cells if key(c) in self.keys),None)
        self.p.selection_changed(old,view=view,boxes=(box,))
    def finish_rubber(self):
        if not self.rubber:return
        r=self.rubber;view=r['view'];box=r['box'];old=set(self.keys)
        if not r['dragged'] and not r['flags']&(NSCommandKeyMask|NSShiftKeyMask|NSAlternateKeyMask|NSControlKeyMask):
            region='pool' if view.pool else 'target'
            self.keys={k for k in self.keys if k[0]!=region}
            if self.anchor is not None and self.anchor[0]==region:self.anchor=None
            self.p.selected=next((c for grid in (self.p.grid,self.p.pool_grid) for c in grid.cells if key(c) in self.keys),None)
        self.record('marquee' if r['dragged'] else 'blank_click',dict(pool=view.pool,count=len(self.keys)))
        self.rubber=None
        self.p.selection_changed(old,view=view,boxes=(box,))
    def sources(self):
        return [c for c in self.p.grid.cells+self.p.pool_grid.cells if key(c) in self.keys]
    def start(self,view,event):
        p=self.p
        if view not in (p.grid,p.pool_grid):return
        if self.active or self.pending or p.drop_draft or p.timer:return
        sources=self.sources()
        if not sources:return
        assets=[c.get('asset') if c['kind']=='pool' else p.project.state['assignments'].get(c['entry']['id']) for c in sources]
        if sources[0]['kind']=='pool' and not all(assets):alert(M('待分配材料已变化，请重新选择'));return
        origin=view.origin
        if not origin:return
        i=view.cells.index(origin);x,y,w,h=card_rect(i,view.cols,view.unit,view.row_height,view.card_height)
        try:image=self.image(assets,w,h,sources)
        except (ValueError,OSError) as exc:
            # A missing native target is a recoverable preview validation error,
            # before any pasteboard/session or assignment mutation exists.
            self.record('drag_start_rejected',dict(reason=ms(exc)))
            view.origin=None;view.down_event=None
            alert(MF('无法生成拖动预览：{detail}',detail=ms(exc)));return
        token=ms(uuid4())
        writer=NSPasteboardItem.alloc().init();writer.setString_forType_(token,TYPE)
        item=NSDraggingItem.alloc().initWithPasteboardWriter_(writer)
        down=view.convertPoint_fromView_(view.down_event.locationInWindow(),None)
        current=view.convertPoint_fromView_(event.locationInWindow(),None)
        # The first drag event may already be far from the original cell. Rebase
        # the image to the current event while retaining the original grab offset.
        item.setDraggingFrame_contents_(((current.x-(down.x-x),current.y-(down.y-y)),(w,h)),image)
        self.active=dict(token=token,sources=copy.deepcopy(sources),before=copy.deepcopy(p.project.state),mode='auto',writer=writer,item=item,image=image)
        self.drag_moves=0
        point=view.convertPoint_fromView_(view.down_event.locationInWindow(),None)
        self.record('native_drag_start',dict(count=len(assets),grab_offset=[point.x-x,point.y-y],image_size=[w,h],mode=self.active['mode'],source_kind=sources[0]['kind'],origin=key(origin),payload_count=len(self.active['sources'])))
        view.session=view.beginDraggingSessionWithItems_event_source_([item],event,view)
        if view.session is None:self.active=None;raise ValueError(M('宿主未能启动拖动会话'))
        view.session.setAnimatesToStartingPositionsOnCancelOrFail_(False)
    def image(self,assets,w,h,sources=None):
        # At most three SVGs, all in the same 1000-unit canvas; no ink fitting.
        image=NSImage.alloc().initWithSize_((w,h));image.lockFocus()
        try:
            for n,aid in reversed(list(enumerate(assets[:3]))):
                off=n*5;box=NSBezierPath.bezierPathWithRoundedRect_xRadius_yRadius_(((off,off),(w-12,h-12)),8,8)
                NSColor.windowBackgroundColor().colorWithAlphaComponent_(.70).set();box.fill()
                NSColor.controlAccentColor().colorWithAlphaComponent_(.55).set();box.setLineWidth_(1);box.stroke()
                from .native_import import preview_frame
                from .target_fit import view_rect
                vx,vy,vw,vh=view_rect(self.p,aid)
                factor=min((w-28)/vw,(h-73)/vh);bx=off+(w-vw*factor)/2-vx*factor;by=off+42-vy*factor
                path=NSBezierPath.bezierPath()
                for contour in (self.p.geometry(aid) if aid else []):
                    point=lambda pt:(bx+pt[0]*factor,by+pt[1]*factor)
                    path.moveToPoint_(point(contour[0][1]))
                    for seg in contour[1:]:
                        if seg[0]=='L':path.lineToPoint_(point(seg[1]))
                        else:path.curveToPoint_controlPoint1_controlPoint2_(point(seg[3]),point(seg[1]),point(seg[2]))
                    path.closePath()
                NSGraphicsContext.saveGraphicsState()
                try:
                    NSBezierPath.bezierPathWithRect_(((off+10,off+38),(w-20,h-73))).addClip()
                    NSColor.labelColor().colorWithAlphaComponent_(.65).set();path.fill()
                finally:NSGraphicsContext.restoreGraphicsState()
            caption=(MP(M('%d 个字格'),len(assets))) if sources and sources[0]['kind']=='target' else (M('素材') if len(assets)==1 else MP(M('%d 个素材'),len(assets)))
            text(caption,12,h-30,13,NSColor.controlAccentColor())
            if sources and sources[0]['kind']=='target':
                from .editor_fonts import entry_attributed
                entry_attributed(sources[0]['entry'],14).drawAtPoint_((14,14))
        finally:image.unlockFocus()
        return image
    def internal(self,sender):
        return bool(self.active and ms(sender.draggingPasteboard().stringForType_(TYPE) or '')==self.active['token'])
    def preview(self,view,sender,header=False):
        p=self.p;point=view.convertPoint_fromView_(sender.draggingLocation(),None)
        if self.active.get('cancelled'):
            self.active['candidate']=None;self.error=M('已按Esc取消');return NSDragOperationNone
        if view not in (p.grid,p.pool_grid):return NSDragOperationNone
        visible=view.visibleRect()
        # Periodic AppKit draggingUpdated calls also scroll a stationary pointer.
        delta=-18 if point.y<visible.origin.y+28 else 18 if point.y>visible.origin.y+visible.size.height-28 else 0
        if delta:
            y=max(0,min(view.bounds().size.height-visible.size.height,visible.origin.y+delta))
            view.scrollPoint_((0,y));point=view.convertPoint_fromView_(sender.draggingLocation(),None)
            if y!=visible.origin.y:self.record('edge_scroll',dict(pool=view.pool,before=visible.origin.y,after=y))
        geometry=(len(view.cells),view.cols,view.unit,view.row_height,view.card_height)
        previous=self.active.get('landing') if self.active.get('landing_view') is view and self.active.get('landing_geometry')==geometry else None
        landing=resolve_drop(point.x,point.y,*geometry,previous=previous) if NSPointInRect(point,view.visibleRect()) else None
        # Material-to-target drops accept the WHOLE card, including its title
        # and status; edge insertion belongs to target record rearrangement.
        material_drop=self.active['sources'][0]['kind']=='pool' and not view.pool and not header
        if material_drop:
            landing=None
            if NSPointInRect(point,view.visibleRect()):
                for i in range(len(view.cells)):
                    x,y,w,h=card_rect(i,view.cols,view.unit,view.row_height,view.card_height)
                    if x<=point.x<=x+w and y<=point.y<=y+h:
                        landing=DropLocation('center',i);break
        if header:
            row,col=divmod(len(view.cells),view.cols);landing=DropLocation('append',len(view.cells),'x',row,col)
        self.active.update(landing=landing,landing_view=view,landing_geometry=geometry)
        cell=None;mode='swap';line_index=None
        if landing:
            zone,index=landing.zone,landing.index
            if view.pool:
                cell={'kind':'pool','asset':view.cells[index]['asset'] if index<len(view.cells) else None};mode='insert';line_index=index
            elif index<len(view.cells):
                cell=view.cells[index];mode='insert' if zone=='insert' else 'swap';line_index=index if mode=='insert' else None
            elif index==len(view.cells) and view.cells:
                cell={'kind':'target','index':index};mode='insert';line_index=index
        self.highlight=set();self.insert_cell=None;self.error='';draft=None
        try:
            if not cell:raise ValueError(M('无效落点，松手取消'))
            if not states_equal(self.active['before'],p.project.state):raise ValueError(M('工程已变化，请取消后重试'))
            pool_batch=len(self.active['sources'])>1 and self.active['sources'][0]['kind']=='pool' and cell['kind']=='target'
            if pool_batch:
                if 'entry' not in cell:raise ValueError(M('批量分配需要现有目标字格作为起点，请移到字格内'))
                draft=pool_batch_candidate(p.project,self.active['sources'],cell['position'],bool(p.w.search.get()) or p.w.filter.get()!=0)
            else:draft=plan(p.project,self.active['sources'],cell,mode,bool(p.w.search.get()) or p.w.filter.get()!=0)
            self.highlight=set(draft['target'] if draft['mode']=='shift' or pool_batch else draft['target']+draft['source']) if mode=='swap' or pool_batch else set();self.insert_cell=None
            self.insert_view=view if mode=='insert' and not pool_batch else None;self.insert_index=line_index
            if pool_batch:
                marker=(draft['start'],tuple(draft['stats'].items()))
                if marker!=self.active.get('batch_feedback_marker'):
                    self.record('batch_drag_feedback',dict(start=draft['start'],payload_count=len(self.active['sources']),**draft['stats']));self.active['batch_feedback_marker']=marker
            hint=self.summary(draft)+(MP(M(' · %d 项进入待分配区'),len(draft['pool_added'])) if draft['pool_added'] else '')
        except ValueError as exc:self.error=ms(exc);self.active['last_rejection']=self.error;hint=self.error
        self.active['candidate']=draft
        location=sender.draggingLocation();visible=view.visibleRect()
        self.active['feedback']=dict(view=view,header=header,point=(float(location.x),float(location.y)),visible=(float(visible.origin.y),float(visible.size.width),float(visible.size.height)))
        p.main.materials.show(False);p.main.issues.show(False);p.main.dragHint.show(True)
        p.main.dragHint.setPosSize((24,146,-220,22));p.main.dragHint.set(hint)
        for v in (p.grid,p.pool_grid):v.setNeedsDisplay_(True)
        return NSDragOperationMove if draft else NSDragOperationNone
    def summary(self,d):
        span=lambda xs:M('待分配区') if not xs else MF('第{detail}格',detail=MJ(',',map(str,xs)))
        affected=d['affected'];extent=M('无') if not affected else MP('%d—%d',(min(affected),max(affected)))
        if d['mode']=='batch-map':
            stats=d['stats']
            return MP(M('起点第%d格 · 可分配%d项 · 冲突%d项 · 超界%d项%s · 松手核对'),(d['start'],stats['allocated'],stats['conflicts'],stats['overflow'],MP(M(' · 其他待分配%d项'),stats['other']) if stats['other'] else ''))
        if d['mode']=='shift':
            direction=M('前移') if d['delta']<0 else M('后移') if d['delta']>0 else M('原位')
            def locations(xs):
                return MP(M('第%d—%d格'),(xs[0],xs[-1])) if xs[-1]-xs[0]+1==len(xs) else span(xs)
            return MP(M('批量素材挪位 %d项 · %s%d格：%s → %s · 保留间隔，字符与顺序不变'),(d['count'],direction,abs(d['delta']),locations(d['source']),locations(d['target'])))
        if d['mode']=='reorder':
            return MF('{detail} · 字符与素材一同移动',detail=M('顺序不变') if d.get('noop') else MP(M('整格重排 %d项：%s → %s · 影响第%s格'),(d['count'],span(d['source']),span(d['target']),extent)))
        return MP(M('%s %d项：%s → %s · 影响第%s格 · 仅调整素材'),(M('插入') if d['mode']=='insert' else M('交换/移动'),d['count'],span(d['source']),span(d['target']),extent))
    def ready(self,view,sender,header=False):
        # Release must commit the already advertised candidate. In particular,
        # prepare/perform must NOT scroll again or resolve another landing.
        if not self.active or self.active.get('cancelled') or not self.active.get('candidate'):return False
        feedback=self.active.get('feedback');point=sender.draggingLocation();visible=view.visibleRect()
        if not feedback or feedback['view'] is not view or feedback['header']!=header:return False
        if max(abs(float(point.x)-feedback['point'][0]),abs(float(point.y)-feedback['point'][1]))>3:return False
        if feedback['visible']!=(float(visible.origin.y),float(visible.size.width),float(visible.size.height)):return False
        if self.active.get('landing_geometry')!=(len(view.cells),view.cols,view.unit,view.row_height,view.card_height):return False
        return states_equal(self.active['before'],self.p.project.state)
    def perform(self,view,sender,header=False):
        if not self.ready(view,sender,header):return False
        draft=self.active['candidate']
        self.record('drop_commit',dict(mode=draft['mode'],landing=list(self.active['landing']),count=draft['count'],same_as_feedback=True,pool=view.pool))
        if draft['mode']=='batch-map':
            self.p.guard(lambda:self.p.present_drop_preview(draft['start'],draft['additions'],draft['rows'],draft['extent'],draft['before']))
            return True
        if draft.get('noop'):return True
        if draft['count']>1 or (draft['mode']=='insert' and draft.get('destination_kind')=='target'):self.show_group(draft)
        else:self.p.guard(lambda:adopt(self.p.project,draft))
        return True
    def end(self,view,operation):
        self.record('native_drag_end',dict(operation=int(operation),moves=self.drag_moves,error=self.error,unchanged=bool(self.active and states_equal(self.active['before'],self.p.project.state))))
        error=self.error;self.active=None;self.highlight=set();self.insert_cell=None;self.error=''
        view.origin=None;view.down_event=None;view.session=None
        if not operation and error:self.p.result_message=MF('拖动已取消：{error}',error=error)
        elif operation and self.p.result_message.startswith(M('拖动已取消')):self.p.result_message=''
        if self.p.main.getNSWindow() is not None:self.p.refresh()
    def show_group(self,draft):
        from . import localized_ui as vanilla
        p=self.p;self.pending=draft;w=self.group_window=p.dialog((780,500),M('核对整组素材排布'))
        reordering=draft['mode']=='reorder'
        w.caption=vanilla.TextBox((20,18,740,80),self.summary(draft)+(M('\n完整目标条目重排；字符、编码、素材和宿主绑定保持在一起。\n采用后是一次可撤销操作，不改变字体内部顺序。') if reordering else MP(M('\n目标文字、Unicode和字表顺序保持固定。\n退回待分配区 %d 个素材；采用后是一次可撤销操作，不写字体。'),len(draft['pool_added']))))
        w.rows=vanilla.List((20,106,740,300),draft['rows'],columnDescriptions=[dict(title=M('位置'),key='position',width=50),dict(title=M('目标'),key='char',width=80),dict(title=M('原位置') if reordering else M('原素材'),key='before',width=250),dict(title=M('新位置') if reordering else M('调整后素材'),key='after',width=270)])
        w.cancel=vanilla.Button((20,438,150,30),M('取消'),callback=lambda s:self.cancel_group())
        w.adopt=vanilla.Button((540,438,220,30),M('采用整格重排') if reordering else M('采用对应调整'),callback=self.confirm_group)
        p.show_dialog(w)
    def confirm_group(self,s):
        def action():
            adopt(self.p.project,self.pending);self.record('group_adopt');self.cancel_group(True)
        self.p.guard(action)
    def cancel_group(self,adopted=False):
        if self.pending:self.record('group_finish' if adopted else 'group_cancel',dict(unchanged=self.pending['before']==self.p.project.state))
        self.pending=None
        if getattr(self,'group_window',None) is not None and self.group_window.getNSWindow() is not None:self.p.hide_dialog(self.group_window)
    def resize_split(self,event):
        p=self.p;pt=p.main.chrome._nsObject.convertPoint_fromView_(event.locationInWindow(),None)
        ref=p.main.chrome._nsObject
        top=pt.y if ref.isFlipped() else ref.bounds().size.height-pt.y
        if self.split_start is None:self.split_start=(top,p.pool_pixels)
        p.pool_fraction=max(.05,min(.95,(self.split_start[1]-(top-self.split_start[0]))/max(1,p.split_available)))
        p.layout()

if 'SVGBatchSplitHandleV10' not in globals():
    class SVGBatchSplitHandleV10(NSView):
        def isFlipped(self):return True
        def resetCursorRects(self):self.addCursorRect_cursor_(self.bounds(),NSCursor.resizeUpDownCursor())
        def drawRect_(self,rect):
            NSColor.separatorColor().set();path=NSBezierPath.bezierPath()
            mid=self.bounds().size.width/2;path.moveToPoint_((mid-18,4));path.lineToPoint_((mid+18,4));path.setLineWidth_(2);path.stroke()
        def mouseDown_(self,event):self.owner.gestures.split_start=None;self.owner.gestures.resize_split(event)
        def mouseDragged_(self,event):self.owner.gestures.resize_split(event)
        def mouseUp_(self,event):self.owner.gestures.split_start=None;self.owner.save_ui_preferences();self.owner.gestures.record('split_resize',dict(fraction=self.owner.pool_fraction,pool_pixels=self.owner.pool_pixels))

def make_grid(Base):
    global SVGBatchInteractiveGridV22
    if 'SVGBatchInteractiveGridV22' in globals():return SVGBatchInteractiveGridV22
    class SVGBatchInteractiveGridV22(Base,protocols=[objc.protocolNamed('NSDraggingSource')]):
        @objc.python_method
        def setup(self,owner,pool=False):
            Base.setup(self,owner,pool);self.registerForDraggedTypes_([TYPE,NSFilenamesPboardType,'public.file-url']);self.down_event=None;self.session=None
        def drawRect_(self,rect):
            if not self.owner:return
            Base.drawRect_(self,rect)
            gestures=self.owner.gestures if self.owner else None
            if not gestures:return
            candidate=gestures.active.get('candidate') if gestures.active else None
            if candidate and candidate['mode'] in ('swap','shift') and not self.pool:
                NSColor.controlAccentColor().colorWithAlphaComponent_(.09).set()
                for i,cell in enumerate(self.cells):
                    if cell.get('position') in candidate['target']:
                        x,y,w,h=card_rect(i,self.cols,self.unit,self.row_height,self.card_height)
                        NSBezierPath.bezierPathWithRoundedRect_xRadius_yRadius_(((x,y),(w,h)),8,8).fill()
            r=gestures.rubber
            if r and r['view'] is self:
                x,y=r['start'];xx,yy=r['end'];box=((min(x,xx),min(y,yy)),(abs(xx-x),abs(yy-y)))
                NSColor.controlAccentColor().colorWithAlphaComponent_(.12).set();NSBezierPath.bezierPathWithRect_(box).fill()
                NSColor.controlAccentColor().set();NSBezierPath.bezierPathWithRect_(box).stroke()
            if gestures.active and getattr(gestures,'insert_view',None) is self and gestures.active.get('candidate') is not None:
                index=gestures.insert_index
                if index is not None:
                    start,end=insertion_line(gestures.active['landing'],self.cols,self.unit,self.row_height,self.card_height)
                    NSColor.colorWithCalibratedRed_green_blue_alpha_(.30,.65,1.,.8).set();path=NSBezierPath.bezierPath()
                    path.moveToPoint_(start);path.lineToPoint_(end);path.setLineWidth_(3);path.stroke()
        def mouseDown_(self,event):
            self.window().makeFirstResponder_(self);self.origin=self.hit(self.convertPoint_fromView_(event.locationInWindow(),None));self.down_event=event
            flags=event.modifierFlags()
            if self.origin is None:self.owner.gestures.begin_rubber(self,event);return
            self.defer_toggle=bool(self.origin and self.owner.gestures.selected(self.origin) and flags&NSCommandKeyMask and not flags&NSShiftKeyMask)
            self.owner.gestures.select(self.origin,0 if self.defer_toggle else flags,True)
            if self.origin and event.clickCount()==2:self.owner.enlarge(self.origin)
        def acceptsFirstMouse_(self,event):return True
        def keyDown_(self,event):
            if self.owner.handle_display_key(self.window(),event):return
            return objc.super(SVGBatchInteractiveGridV22,self).keyDown_(event)
        def scrollWheel_(self,event):
            owner=getattr(self,'owner',None)
            if owner and owner.handle_display_wheel(self,event):return
            return objc.super(SVGBatchInteractiveGridV22,self).scrollWheel_(event)
        def mouseDragged_(self,event):
            if self.owner.gestures.rubber:self.owner.gestures.update_rubber(self,event)
            else:self.owner.gestures.start(self,event)
        def mouseUp_(self,event):
            if self.owner.gestures.rubber:self.owner.gestures.finish_rubber();self.origin=None;self.down_event=None;return
            if self.down_event and not self.session:
                if getattr(self,'defer_toggle',False):self.owner.gestures.select(self.origin,NSCommandKeyMask)
                elif not (self.down_event.modifierFlags()&(NSCommandKeyMask|NSShiftKeyMask)):self.owner.gestures.select(self.origin)
            self.origin=None;self.down_event=None
        def draggingSession_sourceOperationMaskForDraggingContext_(self,session,context):return NSDragOperationMove if context==0 else NSDragOperationNone
        def ignoreModifierKeysForDraggingSession_(self,session):return True
        def draggingSession_endedAtPoint_operation_(self,session,point,operation):self.owner.gestures.end(self,operation)
        def wantsPeriodicDraggingUpdates(self):return True
        def draggingEntered_(self,sender):return self.draggingUpdated_(sender)
        def draggingUpdated_(self,sender):
            if self.owner.gestures.internal(sender):return self.owner.gestures.preview(self,sender)
            return Base.draggingUpdated_(self,sender)
        def draggingExited_(self,sender):
            if self.owner.gestures.internal(sender):
                self.owner.gestures.highlight=set();self.owner.gestures.insert_cell=None
                self.owner.gestures.error=self.owner.gestures.active.get('last_rejection') or M('无效落点，松手取消');self.owner.gestures.active['candidate']=None;self.setNeedsDisplay_(True)
            else:Base.draggingExited_(self,sender)
        def prepareForDragOperation_(self,sender):
            if self.owner.gestures.internal(sender):return self.owner.gestures.ready(self,sender)
            return Base.prepareForDragOperation_(self,sender)
        def performDragOperation_(self,sender):
            if self.owner.gestures.internal(sender):return self.owner.gestures.perform(self,sender)
            return Base.performDragOperation_(self,sender)
    return SVGBatchInteractiveGridV22

if 'SVGBatchPoolDropHeaderV2' not in globals():
    class SVGBatchPoolDropHeaderV2(NSButton):
        def draggingEntered_(self,sender):return self.draggingUpdated_(sender)
        def draggingUpdated_(self,sender):
            p=getattr(self,'owner',None)
            if not p or not p.gestures.internal(sender):return NSDragOperationNone
            if not p.pool_expanded:p.pool_expanded=True;p.refresh()
            return p.gestures.preview(p.pool_grid,sender,True)
        def prepareForDragOperation_(self,sender):return self.owner.gestures.ready(self.owner.pool_grid,sender,True)
        def performDragOperation_(self,sender):return self.owner.gestures.perform(self.owner.pool_grid,sender,True)
        def draggingExited_(self,sender):
            if self.owner and self.owner.gestures.active:self.owner.gestures.active['candidate']=None
        def wantsPeriodicDraggingUpdates(self):return True
