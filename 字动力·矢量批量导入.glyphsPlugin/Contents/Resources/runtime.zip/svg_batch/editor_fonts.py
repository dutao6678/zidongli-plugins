from .i18n import message as M,format_message as MF,percent_message as MP,join_message as MJ,string_message as ms,render as R
"""Display-only system fallback and provenance-bound PUA font hints.
Never imports RTF content/styles or maps private-use characters to other codes.
"""
from functools import lru_cache
import unicodedata
import objc
from . import localized_ui as vanilla
from AppKit import (NSTextView,NSFont,NSFontAttributeName,NSPasteboard,
                    NSStringPboardType,NSRTFPboardType)
from Foundation import NSString,NSAttributedString
from CoreText import CTFontCreateForString,CTFontCopyCharacterSet,CTFontCopyPostScriptName,CTFontCopyFontDescriptor
from CoreFoundation import CFCharacterSetIsLongCharacterMember
from .model import clusters


def private_use(char):
    n=ord(char)
    return 0xE000<=n<=0xF8FF or 0xF0000<=n<=0xFFFFD or 0x100000<=n<=0x10FFFD


def line_compare(text):return text.replace('\r\n','\n').replace('\r','\n')


def clipboard_hints(expected):
    """Font name only, and only when RTF text equals the actual plain payload."""
    board=NSPasteboard.generalPasteboard()
    plain=board.stringForType_(NSStringPboardType)
    if plain is None or line_compare(ms(plain))!=line_compare(expected):return {}
    data=board.dataForType_(NSRTFPboardType)
    if data is None:return {}
    try:attributed,_=NSAttributedString.alloc().initWithRTF_documentAttributes_(data,None)
    except Exception:
        import traceback
        traceback.print_exc()
        return {}
    if attributed is None or line_compare(ms(attributed.string()))!=line_compare(expected):return {}
    hints={};offset=0
    for char in ms(attributed.string()):
        if private_use(char):
            attrs,_=attributed.attributesAtIndex_effectiveRange_(offset,None)
            font=attrs.get(NSFontAttributeName);name=ms(font.fontName()) if font else None
            if char in hints and hints[char]!=name:hints[char]=None
            else:hints[char]=name
        offset+=2 if ord(char)>0xFFFF else 1
    return hints


@lru_cache(maxsize=2048)
def display_font(value,size,provenance):
    base=NSFont.systemFontOfSize_(size)
    if any(private_use(c) for c in value):
        # A different installed font covering the same PUA is NOT a valid guess.
        font=NSFont.fontWithName_size_(provenance,size) if provenance else None
        if font is None or ms(font.fontName()).startswith('LastResort'):return base,False
    else:
        string=NSString.stringWithString_(R(value))
        resolved=CTFontCreateForString(base,string,(0,string.length()))
        name=ms(CTFontCopyPostScriptName(resolved))
        if name.startswith('LastResort'):return base,False
        font=NSFont.fontWithName_size_(name,size)
        if font is None:font=NSFont.fontWithDescriptor_size_(CTFontCopyFontDescriptor(resolved),size)
        if font is None:return base,False
    charset=CTFontCopyCharacterSet(font)
    required=[c for c in value if not (0xFE00<=ord(c)<=0xFE0F or 0xE0100<=ord(c)<=0xE01EF or unicodedata.category(c)=='Cf')]
    return font,all(CFCharacterSetIsLongCharacterMember(charset,ord(c)) for c in required)


def apply_fonts(view,size,hints):
    """Keep content untouched; apply only font attributes, uniform size/color."""
    storage=view.textStorage();offset=0;issues=[];runs=[]
    for value in clusters(ms(view.string())):
        length=NSString.stringWithString_(R(value)).length()
        names=set();part_offset=offset
        for char in value:
            if private_use(char):
                attrs,_=storage.attributesAtIndex_effectiveRange_(part_offset,None)
                names.add(attrs.get('SVGBatchSourceFontName') or hints.get(char))
            part_offset+=2 if ord(char)>0xFFFF else 1
        provenance=next(iter(names)) if len(names)==1 else None
        font,covered=display_font(value,size,provenance)
        if not value.isspace() and (not covered or names):
            issues.append(dict(value=value,codes=MJ(' ',(MP('U+%04X',ord(c)) for c in value)),range=(offset,length),private=bool(names),covered=bool(covered),font=ms(font.fontName()) if covered else M('无已确认的显示字体')))
        name=ms(font.fontName())
        if runs and runs[-1][0]==name:runs[-1][2]+=length
        else:runs.append([name,offset,length,font])
        offset+=length
    storage.beginEditing()
    try:
        for name,start,length,font in runs:storage.addAttribute_value_range_(NSFontAttributeName,font,(start,length))
    finally:storage.endEditing()
    attrs=dict(view.typingAttributes());attrs[NSFontAttributeName]=NSFont.systemFontOfSize_(size);attrs.pop('SVGBatchSourceFontName',None);view.setTypingAttributes_(attrs)
    return issues


if 'SourceTextViewV2' not in globals():
    class SourceTextViewV2(NSTextView):
        def paste_(self,sender):
            owner=getattr(self,'owner',None)
            if owner:
                plain=NSPasteboard.generalPasteboard().stringForType_(NSStringPboardType)
                if plain is not None:
                    incoming=clipboard_hints(ms(plain))
                    selected=self.selectedRange()
                    if selected.location==0 and selected.length==self.textStorage().length():owner.editor_font_hints=incoming
                    else:
                        for char,name in incoming.items():
                            if char in owner.editor_font_hints and owner.editor_font_hints[char]!=name:owner.editor_font_hints[char]=None
                            else:owner.editor_font_hints[char]=name
            # Keep AppKit's native plain-text paste/undo and exact string behavior.
            objc.super(SourceTextViewV2,self).paste_(sender)
            if owner:owner.apply_table_text_size()

class SourceTextEditor(vanilla.TextEditor):
    nsTextViewClass=SourceTextViewV2

# Per-record rendering is shared by grid labels, editors and read-only views.
from .record_display import font_map,attach_display
from AppKit import NSForegroundColorAttributeName,NSColor
from Foundation import NSMutableAttributedString


def entry_attributed(entry,size=14):
    value=entry.get('value','')
    if entry.get('host_binding') and (not value or (len(value)==1 and private_use(value) and not display_font(value,size,font_map(entry).get(0))[1])):
        return NSMutableAttributedString.alloc().initWithString_attributes_(R(entry['host_binding']['glyph_name']),{NSFontAttributeName:NSFont.systemFontOfSize_(size),NSForegroundColorAttributeName:NSColor.labelColor()})
    output=NSMutableAttributedString.alloc().initWithString_(R(value))
    fonts=font_map(entry);offset=0
    for index,char in enumerate(value):
        font,covered=display_font(char,size,fonts.get(index))
        if private_use(char) and not covered:font=NSFont.fontWithName_size_('LastResort',size) or font
        length=2 if ord(char)>0xFFFF else 1
        output.addAttribute_value_range_(NSFontAttributeName,font,(offset,length))
        output.addAttribute_value_range_(NSForegroundColorAttributeName,NSColor.labelColor(),(offset,length))
        offset+=length
    return output


def entry_warning(entry):
    fonts=font_map(entry);missing=[]
    for index,char in enumerate(entry.get('value','')):
        if private_use(char) and not display_font(char,14,fonts.get(index))[1]:
            missing.append(MP('U+%04X %s',(ord(char),MF('源显示字体不可用：{detail}',detail=fonts[index]) if index in fonts else M('缺少源显示字体'))))
    return MJ('；',missing)


def attach_editor_records(view,records):
    """Use exact source line/cluster position; font provenance stays per occurrence."""
    from .model import clusters
    text=ms(view.string());lines=text.split('\n');offsets=[];offset=0
    for line in lines:offsets.append(offset);offset+=len(line)+1
    # One composed-character scan per source line, not per target record.
    # Keep Python offsets and UTF-16 offsets distinct (non-BMP/IVS safe).
    columns={};utf16_offsets=[0]
    for char in text:utf16_offsets.append(utf16_offsets[-1]+(2 if ord(char)>0xFFFF else 1))
    # Only our verified per-occurrence metadata or already verified legacy hints.
    owner=getattr(view,'owner',None);hints=getattr(owner,'editor_font_hints',{})
    for entry in records:
        line_index=entry.get('line',0)-1
        if not 0<=line_index<len(lines):continue
        line=lines[line_index].removesuffix('\r');value=entry.get('value','')
        if not value:continue
        if 'code_record' in entry:
            if line.count(value)!=1:continue
            at=line.find(value)
        else:
            column=entry.get('column',1)-1
            if value==line:at=0
            else:
                if line_index not in columns:
                    starts=[0]
                    for part in clusters(line):starts.append(starts[-1]+len(part))
                    columns[line_index]=starts
                starts=columns[line_index]
                # Preserve slice semantics of the previous parts[:column].
                index=min(column,len(starts)-1) if column>=0 else max(0,len(starts)-1+column)
                at=starts[index]
            if line[at:at+len(value)]!=value:continue
        fonts={}
        for index,char in enumerate(value):
            if not private_use(char):continue
            absolute=offsets[line_index]+at+index
            utf16=utf16_offsets[absolute]
            attrs,_=view.textStorage().attributesAtIndex_effectiveRange_(utf16,None)
            name=attrs.get('SVGBatchSourceFontName') or hints.get(char)
            if name:fonts[index]=ms(name)
        attach_display(entry,fonts)
    return records


from vanilla.vanillaEditText import VanillaEditTextDelegate
if 'TargetEditDelegateV1' not in globals():
    class TargetEditDelegateV1(VanillaEditTextDelegate):
        def controlTextDidBeginEditing_(self,notification):self.action_(notification.object())
class TargetEditText(vanilla.EditText):
    nsTextFieldDelegateClass=TargetEditDelegateV1
    def get(self):return ms(self.getNSTextField().stringValue())


def clipboard_occurrences(expected):
    board=NSPasteboard.generalPasteboard();plain=board.stringForType_(NSStringPboardType)
    if plain is None or line_compare(ms(plain))!=line_compare(expected):return {}
    data=board.dataForType_(NSRTFPboardType)
    if data is None:return {}
    try:attributed,_=NSAttributedString.alloc().initWithRTF_documentAttributes_(data,None)
    except Exception:
        import traceback;traceback.print_exc();return {}
    if attributed is None or line_compare(ms(attributed.string()))!=line_compare(expected):return {}
    return attributed_occurrences(attributed,expected)


def attributed_occurrences(attributed,expected):
    if line_compare(ms(attributed.string()))!=line_compare(expected):return {}
    source=[];offset=0
    for char in ms(attributed.string()):
        if private_use(char):
            attrs,_=attributed.attributesAtIndex_effectiveRange_(offset,None);font=attrs.get(NSFontAttributeName)
            source.append((char,ms(font.fontName()) if font else None))
        offset+=2 if ord(char)>0xFFFF else 1
    positions=[(i,c) for i,c in enumerate(expected) if private_use(c)]
    if [c for i,c in positions]!=[c for c,name in source]:return {}
    return {ms(i):name for (i,c),(char,name) in zip(positions,source) if name}


def snapshot_fonts(view,hints=None):
    text=ms(view.string());fonts={};offset=0
    for index,char in enumerate(text):
        if private_use(char):
            attrs,_=view.textStorage().attributesAtIndex_effectiveRange_(offset,None)
            name=attrs.get('SVGBatchSourceFontName') or (hints or {}).get(char)
            if name:fonts[ms(index)]=ms(name)
        offset+=2 if ord(char)>0xFFFF else 1
    return dict(text=text,fonts=fonts)


def restore_snapshot(view,snapshot):
    text=ms(view.string())
    if not snapshot or snapshot.get('text')!=text:return
    storage=view.textStorage();offset=0
    for index,char in enumerate(text):
        length=2 if ord(char)>0xFFFF else 1
        name=snapshot.get('fonts',{}).get(ms(index))
        if name:storage.addAttribute_value_range_('SVGBatchSourceFontName',name,(offset,length))
        offset+=length


if 'SourceTextViewV3' not in globals():
    class SourceTextViewV3(NSTextView):
        def paste_(self,sender):
            owner=getattr(self,'owner',None);board=NSPasteboard.generalPasteboard();plain=board.stringForType_(NSStringPboardType)
            if owner is None or plain is None:return objc.super(SourceTextViewV3,self).paste_(sender)
            before=snapshot_fonts(self,owner.editor_font_hints);selected=self.selectedRange();native=NSString.stringWithString_(R(before['text']))
            prefix=ms(native.substringToIndex_(selected.location));suffix=ms(native.substringFromIndex_(selected.location+selected.length))
            owner._styling_source=True
            try:objc.super(SourceTextViewV3,self).paste_(sender)
            finally:owner._styling_source=False
            current=ms(self.string())
            if current.startswith(prefix) and current.endswith(suffix) and len(current)>=len(prefix)+len(suffix):
                inserted=current[len(prefix):len(current)-len(suffix) if suffix else len(current)]
                if line_compare(inserted)==line_compare(ms(plain)):
                    start=len(prefix);end=len(before['text'])-len(suffix);delta=len(inserted)-(end-start)
                    fonts={ms(int(i) if int(i)<start else int(i)+delta):name for i,name in before['fonts'].items() if int(i)<start or int(i)>=end}
                    fonts.update({ms(start+int(i)):name for i,name in clipboard_occurrences(inserted).items()})
                    owner.editor_font_snapshot=dict(text=current,fonts=fonts)
                    # No generic codepoint hint may override per-occurrence sources.
                    owner.editor_font_hints={}
            owner.apply_table_text_size()
SourceTextEditor.nsTextViewClass=SourceTextViewV3
