"""Selectable native read-only text. Clipboard plain text is the true storage."""
import objc
import vanilla
from AppKit import (NSTextView,NSPasteboard,NSPasteboardTypeString,NSMenu,NSMenuItem,NSFont,
    NSColor,NSFontAttributeName,NSForegroundColorAttributeName,NSNoBorder)
from Foundation import NSAttributedString

if 'SVGBatchDetailTextViewV2' not in globals():
    class SVGBatchDetailTextViewV2(NSTextView):
        def copy_(self,sender):
            selection=self.selectedRange()
            if not selection.length:return
            # Cocoa supplies its usual rich-text flavors; always include exact
            # UTF-16 substring as public plain text, never a rendered label.
            value=self.textStorage().attributedSubstringFromRange_(selection).string()
            pasteboard=NSPasteboard.generalPasteboard()
            if selection.location<getattr(self,'rich_prefix_length',0):
                objc.super(SVGBatchDetailTextViewV2,self).copy_(sender)
            else:
                # Code/filename/source/dimensions selections are plain text.
                pasteboard.clearContents()
            pasteboard.setString_forType_(value,NSPasteboardTypeString)
        def menuForEvent_(self,event):
            menu=NSMenu.alloc().initWithTitle_('文字');menu.setAutoenablesItems_(False)
            for title,action,enabled in [('复制  ⌘C','copy:',self.selectedRange().length>0),('全选  ⌘A','selectAll:',self.textStorage().length()>0)]:
                item=NSMenuItem.alloc().initWithTitle_action_keyEquivalent_(title,action,'');item.setTarget_(self);item.setEnabled_(enabled);menu.addItem_(item)
            from .menu_hints import apply_hints
            apply_hints(menu)
            return menu

class DetailText(vanilla.TextEditor):
    nsTextViewClass=SVGBatchDetailTextViewV2
    def __init__(self,posSize,text='',size=13):
        super().__init__(posSize,text,readOnly=True)
        scroll=self.getNSScrollView();scroll.setBorderType_(NSNoBorder);scroll.setDrawsBackground_(False);scroll.setAutohidesScrollers_(True)
        view=self.getNSTextView();view.setSelectable_(True);view.setEditable_(False);view.setRichText_(True);view.setDrawsBackground_(False)
        view.setFont_(NSFont.systemFontOfSize_(size));view.setTextColor_(NSColor.labelColor());view.setTextContainerInset_((0,2));view.textContainer().setLineFragmentPadding_(0)
        view.setAllowsUndo_(False)
    def update(self,value,rich_prefix_length=0):
        view=self.getNSTextView();view.rich_prefix_length=rich_prefix_length
        attributed=value if isinstance(value,NSAttributedString) else NSAttributedString.alloc().initWithString_attributes_(value,{NSFontAttributeName:NSFont.systemFontOfSize_(13),NSForegroundColorAttributeName:NSColor.labelColor()})
        if view.textStorage().isEqualToAttributedString_(attributed):return
        selection=view.selectedRange();view.textStorage().setAttributedString_(attributed)
        view.setSelectedRange_((min(selection.location,attributed.length()),min(selection.length,max(0,attributed.length()-selection.location))))
