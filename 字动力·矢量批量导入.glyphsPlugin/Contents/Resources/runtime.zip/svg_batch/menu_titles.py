"""Window-local menu titles and nonmodal AppKit popover presentation.

NSMenu retains the existing items, targets and command callbacks. Independent
NSMenu popup tracking cannot transfer to window titles; NSPopover therefore
presents those same flat items without a custom event loop, polling or timers.
"""
import weakref
import objc
import vanilla
from Foundation import NSObject,NSString
from AppKit import (NSButton,NSView,NSViewController,NSPopover,NSPopoverBehaviorTransient,
    NSColor,NSBezierPath,NSFont,NSTrackingArea,NSTrackingMouseEnteredAndExited,
    NSTrackingActiveInActiveApp,NSTrackingInVisibleRect,NSTrackingMouseMoved,
    NSTrackingEnabledDuringMouseDrag,NSFontAttributeName,NSForegroundColorAttributeName,
    NSPointInRect,NSMaxYEdge,NSCommandKeyMask,NSSetFocusRingStyle,NSFocusRingOnly,
    NSAccessibilityMenuRole,NSAccessibilityMenuItemRole,NSShiftKeyMask)
from .i18n import render
from .menu_hints import split_hint


def title_width(title):
    return measure(render(title),12)+24.


def measure(text,size):
    return float(NSString.stringWithString_(text).sizeWithAttributes_({NSFontAttributeName:NSFont.systemFontOfSize_(size)}).width)


def menu_parts(title):
    # Existing attributed NSMenu shortcut hints use a single tab; untouched
    # menu titles retain the original double-space convention.
    return tuple(title.rsplit('\t',1)) if '\t' in title else (split_hint(title) or (title,''))


def pointer_index(view,event,buttons):
    point=view.convertPoint_fromView_(event.locationInWindow(),None)
    for index,button in enumerate(buttons):
        if NSPointInRect(point,button.frame()):return index
    return None


class SVGBatchMenuTitleButtonRC36(NSButton):
    def updateTrackingAreas(self):
        old=getattr(self,'_title_tracking',None)
        if old is not None:self.removeTrackingArea_(old)
        objc.super(SVGBatchMenuTitleButtonRC36,self).updateTrackingAreas()
        self._title_tracking=NSTrackingArea.alloc().initWithRect_options_owner_userInfo_(self.bounds(),
            NSTrackingMouseEnteredAndExited|NSTrackingActiveInActiveApp|NSTrackingInVisibleRect|NSTrackingMouseMoved|NSTrackingEnabledDuringMouseDrag,self,None)
        self.addTrackingArea_(self._title_tracking)
    def mouseEntered_(self,event):
        group=getattr(self,'_title_group',lambda:None)()
        if group is not None:group.hover(self._title_index)
    def mouseMoved_(self,event):self.mouseEntered_(event)
    def mouseExited_(self,event):
        group=getattr(self,'_title_group',lambda:None)()
        if group is not None:group.hover(None)
    def mouseDown_(self,event):
        self.performClick_(self)
    def keyDown_(self,event):
        group=getattr(self,'_title_group',lambda:None)()
        if group is not None and event.keyCode() in (125,126):group.open(self._title_index,keyboard=True);return
        objc.super(SVGBatchMenuTitleButtonRC36,self).keyDown_(event)
    def drawRect_(self,rect):
        group=getattr(self,'_title_group',lambda:None)()
        on=group is not None and (group.active==self._title_index or (group.active is None and group.hovered==self._title_index))
        if on:
            NSColor.colorWithCalibratedRed_green_blue_alpha_(.77,.88,1.,.72).set()
            NSBezierPath.bezierPathWithRoundedRect_xRadius_yRadius_(self.bounds(),5.,5.).fill()
        attrs={NSFontAttributeName:self.font(),NSForegroundColorAttributeName:NSColor.labelColor()}
        value=NSString.stringWithString_(self.title());size=value.sizeWithAttributes_(attrs);bounds=self.bounds()
        value.drawAtPoint_withAttributes_(((bounds.size.width-size.width)/2.,(bounds.size.height-size.height)/2.),attrs)
        if self.window() is not None and self.window().firstResponder()==self:
            NSSetFocusRingStyle(NSFocusRingOnly);NSBezierPath.bezierPathWithRoundedRect_xRadius_yRadius_(bounds,5.,5.).fill()


class SVGBatchMenuRowRC36(NSButton):
    def drawRect_(self,rect):
        group=getattr(self,'_menu_group',lambda:None)()
        selected=group is not None and group.selected==self._row_index
        if selected:
            NSColor.selectedContentBackgroundColor().set()
            NSBezierPath.bezierPathWithRoundedRect_xRadius_yRadius_(self.bounds(),4.,4.).fill()
        color=NSColor.selectedMenuItemTextColor() if selected else NSColor.labelColor()
        attrs={NSFontAttributeName:NSFont.menuFontOfSize_(13),NSForegroundColorAttributeName:color}
        value=NSString.stringWithString_(self._label);height=value.sizeWithAttributes_(attrs).height
        value.drawAtPoint_withAttributes_((10.,(self.bounds().size.height-height)/2.),attrs)
        if self._hint:
            hint=NSString.stringWithString_(self._hint);width=hint.sizeWithAttributes_(attrs).width
            hint.drawAtPoint_withAttributes_((self.bounds().size.width-width-10.,(self.bounds().size.height-height)/2.),attrs)
    def keyDown_(self,event):
        group=getattr(self,'_menu_group',lambda:None)()
        if group is not None and group.key(event):return
        objc.super(SVGBatchMenuRowRC36,self).keyDown_(event)
    def performKeyEquivalent_(self,event):
        group=getattr(self,'_menu_group',lambda:None)()
        if group is not None and event.modifierFlags() & NSCommandKeyMask:return group.key(event)
        return objc.super(SVGBatchMenuRowRC36,self).performKeyEquivalent_(event)


class SVGBatchMenuListRC36(NSView):
    def isFlipped(self):return True
    def acceptsFirstResponder(self):return True
    def updateTrackingAreas(self):
        old=getattr(self,'_tracking',None)
        if old is not None:self.removeTrackingArea_(old)
        objc.super(SVGBatchMenuListRC36,self).updateTrackingAreas()
        self._tracking=NSTrackingArea.alloc().initWithRect_options_owner_userInfo_(self.bounds(),NSTrackingMouseEnteredAndExited|NSTrackingMouseMoved|NSTrackingActiveInActiveApp|NSTrackingInVisibleRect,self,None)
        self.addTrackingArea_(self._tracking)
    def mouseMoved_(self,event):
        group=getattr(self,'_menu_group',lambda:None)()
        if group is not None:group.select(pointer_index(self,event,group.rows))
    def mouseEntered_(self,event):self.mouseMoved_(event)
    def mouseExited_(self,event):
        group=getattr(self,'_menu_group',lambda:None)()
        if group is not None:group.select(None)
    def keyDown_(self,event):
        group=getattr(self,'_menu_group',lambda:None)()
        if group is not None and group.key(event):return
        objc.super(SVGBatchMenuListRC36,self).keyDown_(event)
    def performKeyEquivalent_(self,event):
        group=getattr(self,'_menu_group',lambda:None)()
        if group is not None and event.modifierFlags() & NSCommandKeyMask:return group.key(event)
        return objc.super(SVGBatchMenuListRC36,self).performKeyEquivalent_(event)


class SVGBatchMenuPopoverDelegateRC36(NSObject):
    def choose_(self,sender):
        group=getattr(self,'group',lambda:None)()
        if group is not None:group.choose(sender._row_index)
    def popoverDidClose_(self,notification):
        group=getattr(self,'group',lambda:None)()
        if group is not None:group.did_close(notification.object())


class MenuTitle(vanilla.Button):
    nsButtonClass=SVGBatchMenuTitleButtonRC36
    frameAdjustments=None
    def __init__(self,pos,title,items):
        self._title=title
        from . import localized_ui
        object.__setattr__(self,'_adapter',localized_ui.ActionButton((0,0,1,1),items))
        super().__init__(pos,render(title),callback=self._open)
        native=self.getNSButton();native.setBordered_(False);native.setFont_(NSFont.systemFontOfSize_(12));native.setAccessibilityLabel_(render(title))
        self._sync_title()
    def _sync_title(self):
        first=self.getNSPopUpButton().itemAtIndex_(0);first.setImage_(None);first.setTitle_(render(self._title))
    def getNSPopUpButton(self):return self._adapter.getNSPopUpButton()
    def setItems(self,items):self._adapter.setItems(items);self._sync_title()
    def _open(self,sender):
        group=getattr(self.getNSButton(),'_title_group',lambda:None)()
        if group is not None:group.open(self.getNSButton()._title_index)
    def native_menu(self):
        menu=self.getNSPopUpButton().menu().copy()
        if menu.numberOfItems():menu.removeItemAtIndex_(0)
        return menu


class MenuTitles:
    def __init__(self,owner,controls):
        self.owner=weakref.ref(owner);self.controls=tuple(controls);self.active=None;self.hovered=None
        self.popover=None;self.rows=[];self.menu=None;self.selected=None;self.closed=False;self.switching=False;self.focus=None
        self.delegate=SVGBatchMenuPopoverDelegateRC36.alloc().init();self.delegate.group=weakref.ref(self)
        for index,control in enumerate(self.controls):
            button=control.getNSButton();button._title_group=weakref.ref(self);button._title_index=index
    def layout(self,width):
        widths=[title_width(c._title) for c in self.controls];x=width-24-sum(widths)-12
        for control,w in zip(self.controls,widths):control.setPosSize((x,8,w,26));x+=w+6
    def redraw(self):
        for control in self.controls:control.getNSButton().setNeedsDisplay_(True)
    def select(self,index):
        self.selected=index
        for button in self.rows:button.setNeedsDisplay_(True)
    def hover(self,index):
        self.hovered=index;self.redraw()
        if self.active is not None and index is not None and index!=self.active:self.open(index)
    def open(self,index,keyboard=False):
        owner=self.owner()
        if self.closed or self.switching or owner is None or getattr(owner,'_closed',False):return
        if index==self.active:
            self.dismiss();return
        window=self.controls[index].getNSButton().window()
        if self.active is None:self.focus=window.firstResponder()
        self.switching=True
        try:
            self.dismiss(restore=False)
            if index==1:owner.update_edit_menu()
            self.active=index;self.menu=self.controls[index].native_menu();self.rows=[];self.selected=None
            specs=[];width=230.
            for i in range(self.menu.numberOfItems()):
                item=self.menu.itemAtIndex_(i)
                if item.isSeparatorItem():specs.append(None);continue
                label,hint=menu_parts(str(item.title()))
                width=max(width,measure(label,13)+measure(hint,13)+(50 if hint else 24));specs.append((i,item,label,hint))
            height=12+sum(9 if row is None else 26 for row in specs)
            view=SVGBatchMenuListRC36.alloc().initWithFrame_(((0,0),(width,height)));view._menu_group=weakref.ref(self)
            view.setAccessibilityRole_(NSAccessibilityMenuRole);view.setAccessibilityLabel_(render(self.controls[index]._title))
            y=6.
            for spec in specs:
                if spec is None:
                    line=NSView.alloc().initWithFrame_(((8,y+4),(width-16,1)));line.setWantsLayer_(True);line.layer().setBackgroundColor_(NSColor.separatorColor().CGColor());view.addSubview_(line);y+=9;continue
                native_index,item,label,hint=spec
                button=SVGBatchMenuRowRC36.alloc().initWithFrame_(((4,y),(width-8,26)))
                button._menu_group=weakref.ref(self);button._row_index=len(self.rows);button._native_index=native_index;button._label=label;button._hint=hint
                button.setTitle_(str(item.title()));button.setBordered_(False);button.setEnabled_(item.isEnabled());button.setTarget_(self.delegate);button.setAction_('choose:')
                button.setAccessibilityRole_(NSAccessibilityMenuItemRole);button.setAccessibilityLabel_(label+(' '+hint if hint else ''))
                view.addSubview_(button);self.rows.append(button);y+=26
            controller=NSViewController.alloc().init();controller.setView_(view)
            pop=NSPopover.alloc().init();pop.setAnimates_(False);pop.setBehavior_(NSPopoverBehaviorTransient);pop.setContentViewController_(controller);pop.setContentSize_((width,height));pop.setDelegate_(self.delegate)
            self.popover=pop;button=self.controls[index].getNSButton();pop.showRelativeToRect_ofView_preferredEdge_(button.bounds(),button,NSMaxYEdge)
            view.window().makeFirstResponder_(view)
            if keyboard:self.select(0)
        except Exception:
            self.dismiss();raise
        finally:self.switching=False;self.redraw()
    def did_close(self,pop):
        if pop is not self.popover:return
        self.popover=None;self.active=None;self.selected=None;self.rows=[];self.menu=None;self.hovered=None;self.focus=None;self.redraw()
        # Outside clicks keep the responder chosen by AppKit; do not refocus
        # the previous editor after the user's new click.
    def restore_focus(self):
        owner=self.owner()
        if owner is None or self.closed:return
        window=self.controls[0].getNSButton().window()
        if window is not None and self.focus is not None:window.makeFirstResponder_(self.focus)
        self.focus=None
    def dismiss(self,restore=True):
        pop=self.popover;self.popover=None;self.active=None;self.rows=[];self.selected=None;self.menu=None
        if pop is not None:pop.setDelegate_(None);pop.close()
        if restore:self.restore_focus();self.hovered=None
        self.redraw()
    def choose(self,index):
        if self.closed or self.menu is None or not (0<=index<len(self.rows)):return
        menu=self.menu;native=self.rows[index]._native_index
        if not menu.itemAtIndex_(native).isEnabled():return
        self.dismiss();menu.performActionForItemAtIndex_(native)
    def key(self,event):
        key=event.keyCode()
        if event.modifierFlags() & NSCommandKeyMask:
            owner=self.owner();self.dismiss()
            if owner is None:return False
            window=owner.main.getNSWindow()
            if window.performKeyEquivalent_(event):return True
            focus=window.firstResponder()
            return bool(focus is not None and hasattr(focus,'performKeyEquivalent_') and focus.performKeyEquivalent_(event))
        if key==53:self.dismiss();return True
        if key in (123,124) and self.active is not None:self.open((self.active+(-1 if key==123 else 1))%len(self.controls),keyboard=True);return True
        if key==48 and self.rows:
            step=-1 if event.modifierFlags() & NSShiftKeyMask else 1
            self.select(((self.selected if self.selected is not None else (-1 if step==1 else 0))+step)%len(self.rows));return True
        if key in (125,126) and self.rows:
            self.select(((self.selected if self.selected is not None else (-1 if key==125 else 0))+(1 if key==125 else -1))%len(self.rows));return True
        if key in (36,49,76):
            if self.selected is not None:self.choose(self.selected)
            return True
        return False
    def dispose(self):
        self.closed=True;self.focus=None;self.dismiss();self.delegate.group=lambda:None
        for control in self.controls:control._adapter.setItems([])

