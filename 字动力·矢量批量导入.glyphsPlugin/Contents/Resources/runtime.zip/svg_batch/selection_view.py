"""Selection-only UI updates. No model edits, host reads, candidates, layout or parser."""
from .hit_testing import card_rect
from .rearrange import key


def update(panel,old_keys=None,view=None,boxes=(),final=True):
    current=panel.gestures.keys
    base=getattr(panel,'selection_base_materials',panel.main.materials.get().partition(' · 选中 ')[0])
    label=base+(' · 选中 %d 项（当前结果）'%len(current) if current else '')
    if panel.main.materials.get()!=label:panel.main.materials.set(label)
    panel.main.issues.show(bool(panel.main.issues.get()) and not current)
    panel.main.selectionMenu.show(panel.selected is not None)
    if not final and panel.selected:
        item=panel.main.selectionMenu.getNSPopUpButton().itemAtIndex_(0)
        title='选中 %d 项'%len(current)
        if item is not None and str(item.title())!=title:item.setTitle_(title)
    if final:
        if panel.selected and panel.selected['kind']=='target':
            panel.w.position.set(str(panel.selected['position']));panel.w.value.set(panel.selected['entry']['value'])
        if panel.selected:
            panel.main.selectionMenu.setItems([dict(title=t,callback=c) for t,c in panel.cell_items(panel.selected)])
            item=panel.main.selectionMenu.getNSPopUpButton().itemAtIndex_(0);item.setImage_(None);item.setTitle_('选中 %d 项'%len(current))
        panel.update_edit_menu();panel.style_target_editor()
    changed=current.symmetric_difference(old_keys) if old_keys is not None else None
    lookup=getattr(panel,'selection_lookup',{})
    if changed is None or len(changed)>128:
        for grid in ((view,) if view is not None else (panel.grid,panel.pool_grid)):grid.setNeedsDisplay_(True)
    else:
        for item in changed:
            found=lookup.get(item)
            if found is None:continue
            grid,index=found;x,y,w,h=card_rect(index,grid.cols,grid.unit,grid.row_height,grid.card_height)
            grid.setNeedsDisplayInRect_(((x-2,y-2),(w+4,h+4)))
    if view is not None:
        for x,y,w,h in boxes:view.setNeedsDisplayInRect_(((x-2,y-2),(w+4,h+4)))


def rebuild_lookup(panel):
    panel.selection_lookup={key(c):(grid,i) for grid in (panel.grid,panel.pool_grid) for i,c in enumerate(grid.cells)}
