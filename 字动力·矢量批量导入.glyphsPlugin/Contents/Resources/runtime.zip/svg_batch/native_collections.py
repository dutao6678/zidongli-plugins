"""Scoped snapshots of host collections; no global bridge/SDK modification."""
def native_items(values):
    if values is None:return []
    return [values[index] for index in range(len(values))]


def descendant_views(root):
    stack=[root] if root is not None else []
    while stack:
        view=stack.pop()
        stack.extend(native_items(view.subviews()))
        yield view
