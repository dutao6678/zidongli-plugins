"""Right-aligned display hints only: no keyEquivalent or event registration."""
import re

def split_hint(title):
    match=re.match(r'^(.*?)\s{2,}((?:⇧)?⌘.*|Delete)$',title)
    return match.groups() if match else None

def apply_hints(menu):
    from AppKit import (NSMutableParagraphStyle,NSTextTab,NSRightTextAlignment,
                        NSParagraphStyleAttributeName,NSFontAttributeName,NSFont)
    from Foundation import NSAttributedString
    menu.setMinimumWidth_(230)
    for index in range(menu.numberOfItems()):
        item=menu.itemAtIndex_(index);parts=split_hint(str(item.title()))
        if parts is None:continue
        paragraph=NSMutableParagraphStyle.alloc().init()
        paragraph.setTabStops_([NSTextTab.alloc().initWithTextAlignment_location_options_(NSRightTextAlignment,210.,{})])
        item.setAttributedTitle_(NSAttributedString.alloc().initWithString_attributes_(parts[0]+'\t'+parts[1],{NSParagraphStyleAttributeName:paragraph,NSFontAttributeName:NSFont.menuFontOfSize_(0)}))
