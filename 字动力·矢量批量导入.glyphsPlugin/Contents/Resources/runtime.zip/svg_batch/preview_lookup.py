"""Panel-local incremental Unicode index for display only; writes validate afresh."""
import contextvars,time,weakref
from contextlib import contextmanager
from functools import wraps
from .native_collections import native_items

_active=contextvars.ContextVar('svg_batch_display_lookup',default=None)
class PreviewPending(ValueError):pass

def active_matches(font,code):
    current=_active.get()
    if current is None or current.font is not font:return None
    return current.matches(code)

class PreviewLookup:
    def __init__(self,panel):
        self.owner=weakref.ref(panel);self.font=None;self.host_index=None;self.cancelled=False;self.timer=None;self.target=None;self.running=False;self.stats={}
    @property
    def ready(self):return bool(self.host_index is not None and self.host_index.ready)
    @property
    def count(self):return len(self.font.glyphs) if self.font is not None else 0
    @property
    def cursor(self):return self.host_index.cursor if self.host_index is not None and hasattr(self.host_index,'cursor') else 0
    @property
    def index(self):return self.host_index.snapshot.by_code if self.ready else {}
    def stop(self,cancelled=False):
        if self.timer is not None:self.timer.invalidate();self.timer=None
        if self.target is not None:self.target.owner=None;self.target=None
        self.running=False;self.cancelled=cancelled
        if cancelled and self.host_index is not None:self.host_index.reading=False
    def close(self):
        self.stop(True)
        if self.host_index is not None:self.host_index.close()
        self.host_index=None;self.font=None
    def invalidate(self):
        self.stop()
        if self.host_index is not None:self.host_index.invalidate()
    def revalidate(self):
        self.cancelled=False
        if self.host_index is not None and not self.host_index.signals_verified:self.invalidate()
    def ensure(self,font):
        if font is None:raise ValueError('尚未绑定目标字体')
        from .host_index import service,same
        if not same(self.font,font):
            self.stop();self.font=font;self.host_index=service(font)
        elif self.host_index is None or self.host_index.closed:self.host_index=service(font)
        if self.ready:return
        if self.cancelled:raise PreviewPending('目标预览读取已取消；重新置前主窗口可重试')
        if not self.running:
            from .panel_actions import SVGBatchTick
            from Foundation import NSTimer,NSRunLoop,NSRunLoopCommonModes
            self.host_index.start('display');self.stats=self.host_index.build_stats
            self.target=SVGBatchTick.alloc().init();self.target.owner=self
            self.timer=NSTimer.timerWithTimeInterval_target_selector_userInfo_repeats_(.01,self.target,'tick:',None,True)
            NSRunLoop.mainRunLoop().addTimer_forMode_(self.timer,NSRunLoopCommonModes);self.running=True
        raise PreviewPending('正在分批读取目标字形：%d/%d；Esc可取消'%(self.cursor,self.count))
    def tick(self,timer):
        p=self.owner()
        if p is None or getattr(p,'_closed',False) or self.font is None:self.close();return
        from .host_targets import same_object
        if not same_object(p.locked_font,self.font):self.close();return
        try:
            done=self.host_index.advance()
            p.main.status.set('读取目标预览 %d/%d；Esc取消（不改变工程）'%(self.cursor,self.count))
            if not done:return
            self.stop();self.stats=self.host_index.build_stats
            p._preview_lookup_completion=True
            try:p.refresh()
            finally:p._preview_lookup_completion=False
        except Exception as exc:
            import traceback
            traceback.print_exc();self.stop(True);p.result_message='目标预览读取失败：'+str(exc);p.main.status.set(p.result_message)
    def matches(self,code):
        from .host import unicode_values
        from .host_targets import same_object
        self.ensure(self.font);matches=self.host_index.snapshot.matches(code)
        for glyph in matches:
            if not same_object(self.font.glyphs[str(glyph.name)],glyph) or code not in unicode_values(glyph):
                self.invalidate();raise PreviewPending('宿主字形已变化，正在重新读取预览')
        return matches

@contextmanager
def scope(panel,entry):
    needs=bool(entry and not entry.get('host_binding') and len(entry.get('value',''))==1 and panel.locked_font is not None and getattr(panel,'preview_lookup_enabled',False))
    if not needs:
        yield;return
    lookup=getattr(panel,'preview_lookup',None)
    if lookup is None:lookup=panel.preview_lookup=PreviewLookup(panel)
    lookup.ensure(panel.locked_font)
    token=_active.set(lookup)
    try:yield
    finally:_active.reset(token)

def geometry_scope(method):
    @wraps(method)
    def wrapped(panel,aid,entry=None):
        target=entry or next((e for e in panel.project.state['entries'] if panel.project.state['assignments'].get(e['id'])==aid),None)
        with scope(panel,target):return method(panel,aid,entry)
    return wrapped

def entry_scope(method):
    @wraps(method)
    def wrapped(panel,entry,*args,**kwargs):
        with scope(panel,entry):return method(panel,entry,*args,**kwargs)
    return wrapped
