"""Our module-local Vanilla facade; never patch Vanilla, AppKit or Glyphs globally."""
import vanilla as _v
from .i18n import data,render

def __getattr__(name):return getattr(_v,name)

class SVGBatchLocalizedTextBoxRC35(_v.TextBox):
    def __init__(self,posSize,text='',*a,**kw):self._canonical_text=text;super().__init__(posSize,render(text),*a,**kw)
    def set(self,text):self._canonical_text=text;return super().set(render(text))
    def get(self):return self._canonical_text
class SVGBatchLocalizedButtonRC35(_v.Button):
    def __init__(self,posSize,title,*a,**kw):super().__init__(posSize,render(title),*a,**kw)
    def setTitle(self,title):return super().setTitle(render(title))
class SVGBatchLocalizedCheckBoxRC35(_v.CheckBox):
    def __init__(self,posSize,title,*a,**kw):super().__init__(posSize,render(title),*a,**kw)
class SVGBatchLocalizedPopUpButtonRC35(_v.PopUpButton):
    def __init__(self,posSize,items,*a,**kw):super().__init__(posSize,data(items),*a,**kw)
    def setItems(self,items):return super().setItems(data(items))
class SVGBatchLocalizedActionButtonRC35(_v.ActionButton):
    def __init__(self,posSize,items,*a,**kw):super().__init__(posSize,data(items),*a,**kw)
    def setItems(self,items):return super().setItems(data(items))
class SVGBatchLocalizedEditTextRC35(_v.EditText):
    def __init__(self,posSize,text='',*a,**kw):
        from .i18n import Message
        self._default_message=text if isinstance(text,Message) else None
        if 'placeholder' in kw:kw['placeholder']=render(kw['placeholder'])
        super().__init__(posSize,render(text),*a,**kw)
    def set(self,value):
        from .i18n import Message
        self._default_message=value if isinstance(value,Message) else None
        return super().set(render(value))
    def get(self):
        value=super().get();default=self._default_message
        return default if default is not None and value==render(default) else value
class SVGBatchLocalizedTextEditorRC35(_v.TextEditor):
    def __init__(self,posSize,text='',*a,**kw):
        self._presentation_read_only=bool(kw.get('readOnly',False))
        super().__init__(posSize,render(text) if self._presentation_read_only else text,*a,**kw)
    def set(self,text):return super().set(render(text) if self._presentation_read_only else text)
class SVGBatchLocalizedListRC35(_v.List):
    def __init__(self,posSize,items,*a,**kw):
        if 'columnDescriptions' in kw:kw['columnDescriptions']=data(kw['columnDescriptions'])
        super().__init__(posSize,data(items),*a,**kw)
    def set(self,items):return super().set(data(items))
class SVGBatchLocalizedWindowRC35(_v.Window):
    def __init__(self,posSize,title='',*a,**kw):super().__init__(posSize,render(title),*a,**kw)

TextBox=SVGBatchLocalizedTextBoxRC35
Button=SVGBatchLocalizedButtonRC35
CheckBox=SVGBatchLocalizedCheckBoxRC35
PopUpButton=SVGBatchLocalizedPopUpButtonRC35
ActionButton=SVGBatchLocalizedActionButtonRC35
EditText=SVGBatchLocalizedEditTextRC35
TextEditor=SVGBatchLocalizedTextEditorRC35
List=SVGBatchLocalizedListRC35
Window=SVGBatchLocalizedWindowRC35

class SVGBatchLocalizedSearchBoxRC35(_v.SearchBox):
    def __init__(self,*a,**kw):
        if 'placeholder' in kw:kw['placeholder']=render(kw['placeholder'])
        super().__init__(*a,**kw)
SearchBox=SVGBatchLocalizedSearchBoxRC35


def fit_labels(window):
    """Fit translated button/pop-up labels within their existing control bounds.
    Main-thread UI only. Editable text/font-source runs are never touched.
    """
    from .i18n import language
    from AppKit import NSFont,NSFontAttributeName
    from Foundation import NSString
    for control in vars(window).values():
        if not isinstance(control,(SVGBatchLocalizedButtonRC35,SVGBatchLocalizedCheckBoxRC35,SVGBatchLocalizedPopUpButtonRC35,SVGBatchLocalizedActionButtonRC35)):continue
        native=getattr(control,'_nsObject',None)
        if native is None or not hasattr(native,'font'):continue
        width=float(native.frame().size.width)-32
        if width<=0:continue
        if hasattr(native,'title'):label=str(native.title() or '')
        else:continue
        if not label:continue
        size=min(13.,float(native.font().pointSize()))
        while size>11 and NSString.stringWithString_(label).sizeWithAttributes_({NSFontAttributeName:NSFont.systemFontOfSize_(size)}).width>width:size-=.5
        native.setFont_(NSFont.systemFontOfSize_(size))


from functools import lru_cache
@lru_cache(maxsize=128)
def text_height(rendered_text,width,size=13):
    # UI-only cached measurement, never file parsing or font-source lookup.
    import math
    from Foundation import NSString
    from AppKit import NSFont,NSFontAttributeName,NSStringDrawingUsesLineFragmentOrigin,NSStringDrawingUsesFontLeading
    rect=NSString.stringWithString_(rendered_text).boundingRectWithSize_options_attributes_((width,100000),NSStringDrawingUsesLineFragmentOrigin|NSStringDrawingUsesFontLeading,{NSFontAttributeName:NSFont.systemFontOfSize_(size)})
    return math.ceil(rect.size.height)+3
