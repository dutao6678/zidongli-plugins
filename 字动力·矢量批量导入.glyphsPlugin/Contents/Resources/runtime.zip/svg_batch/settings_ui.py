"""Compact mode-specific settings, latest-only single-entry preview on main thread."""
import time,weakref
import vanilla
from Foundation import NSTimer,NSRunLoop,NSRunLoopCommonModes
from .panel_actions import SVGBatchTick,alert
from .settings_logic import preview_entry_id,settings_values
from .settings_canvas import SVGBatchSettingsCanvasV1,bezier

class PreviewQueue:
    interval=.04
    def __init__(self,panel,window):
        self.owner=weakref.ref(panel);self.window=window;self.timer=None;self.target=None;self.pending=False;self.commit=False;self.sync=False;self.generation=0;self.events=[];self.valid=True;self.parameters_valid=True
    def request(self,commit=False,sync=False):
        p=self.owner();w=self.window
        if p is None or w is None or w.getNSWindow() is None:return
        self.generation+=1;self.pending=True;self.commit=self.commit or commit or not self.parameters_valid;self.sync=self.sync or sync
        w.canvas.update(message='正在更新预览…');w.previewStatus.set('正在计算当前项；设置作用于整批。')
        if self.timer is None:
            self.target=SVGBatchTick.alloc().init();self.target.owner=self
            self.timer=NSTimer.timerWithTimeInterval_target_selector_userInfo_repeats_(self.interval,self.target,'tick:',None,False)
            NSRunLoop.mainRunLoop().addTimer_forMode_(self.timer,NSRunLoopCommonModes)
    def stop_timer(self):
        if self.timer is not None:self.timer.invalidate();self.timer=None
        if self.target is not None:self.target.owner=None;self.target=None
    def tick(self,timer):self.flush()
    def close(self):self.stop_timer();self.pending=False;self.window=None
    def flush(self):
        self.stop_timer();p=self.owner();w=self.window
        if not self.pending or p is None or w is None:return self.valid
        if getattr(p,'_closed',False) or w.getNSWindow() is None:self.close();return False
        generation=self.generation;commit=self.commit;sync=self.sync;self.pending=False;self.commit=False;self.sync=False;start=time.perf_counter()
        parameters_done=not commit
        try:
            if commit:
                updates=p.collect_settings();parameters_done=True;self.parameters_valid=True
                if updates!=p.project.state['settings']:p.project.edit(lambda:p.project.state['settings'].update(updates))
                # Update only this dialog; main grid refresh waits until returning.
                if sync:p.sync_settings()
                else:p.layout_settings()
            entry=next((e for e in p.project.state['entries'] if e['id']==w.preview_entry_id),None)
            if entry is None:
                message='预览目标已移除，请关闭后重新打开设置' if w.preview_entry_id else '没有已分配材料的目标，可先在主面板分配素材'
                w.canvas.update(message=message);w.previewStatus.set(message);self.valid=True;return True
            from .target_identity import label
            w.previewCaption.set('效果预览：%s · 设置作用于整批'%label(entry))
            aid=p.project.state['assignments'].get(entry['id'])
            if not aid:
                w.canvas.update(message='该目标未分配材料');w.previewStatus.set('未计算其他目标；预览对象在本次设置窗口内固定。');self.valid=True;return True
            from .preview_reference import reference
            frame=reference(p,aid,entry,full=True)
            contours=p.geometry(aid,entry)
            from .append_preview import existing_path
            existing=existing_path(p,entry)
            snapshot=dict(frame=frame,path=bezier(contours),existing=existing,entry_id=entry['id'],asset_id=aid,settings=dict(p.project.state['settings']))
            if generation!=self.generation or self.window is not w or w.getNSWindow() is None or getattr(p,'_closed',False):return False
            w.canvas.update(snapshot)
            w.previewStatus.set('当前字宽 %g → 预计 %g；母版 %g → %g%s'%(frame['current_width'],frame['width'],frame['descender'],frame['ascender'],' · 轮廓超框，已完整显示' if frame['outside'] else ''))
            self.valid=True;return True
        except Exception as exc:
            if not isinstance(exc,(ValueError,OSError,TypeError,KeyError,OverflowError)):
                import traceback
                traceback.print_exc()
            self.valid=False
            if not parameters_done:self.parameters_valid=False
            if generation==self.generation and self.window is w and w.getNSWindow() is not None:
                message='预览不可用：'+str(exc);w.canvas.update(message=message);w.previewStatus.set(message)
            return False
        finally:
            self.events.append(dict(generation=generation,entry_id=w.preview_entry_id,commit=commit,seconds=time.perf_counter()-start,valid=self.valid));self.events=self.events[-150:]

class SettingsUI:
    def build_settings_dialog(self):
        old=getattr(self,'settings_queue',None)
        if old is not None:old.close()
        w=self.settings_window=self.dialog((760,470),'导入设置');self.settings_grid=None
        w.preview_entry_id=None;w.advanced_open=False
        w.help=vanilla.TextBox((20,12,720,23),'调整整批导入参数；右侧仅核对一个固定目标，不写入字体。')
        self.add_control(w,'importmethod',vanilla.PopUpButton((20,44,720,26),['原生导入（Glyphs原生轮廓行为）','统一画布（手动定位／适配目标）'],callback=self.change_settings))
        self.add_control(w,'fitTarget',vanilla.CheckBox((20,86,330,24),'适配目标字格（保留原字宽）',value=False,callback=self.change_settings))
        for name,title,value in [('height','画布高度','1000'),('scale','整体缩放','1'),('x','画布左边位置','0'),('y','画布底边位置','0'),('width','字宽','1000')]:
            setattr(w,name+'Label',vanilla.TextBox((20,124,130,24),title));self.add_control(w,name,vanilla.EditText((155,124,195,26),value,callback=self.change_settings))
        self.add_control(w,'widthpolicy',vanilla.PopUpButton((20,260,330,26),['保留已有字宽','使用统一字宽'],callback=self.change_settings))
        self.add_control(w,'existing',vanilla.PopUpButton((20,300,330,26),['已有内容：跳过（默认）','已有内容：替换轮廓','追加到已有图层'],callback=self.change_settings))
        self.add_control(w,'create',vanilla.CheckBox((20,338,330,24),'允许创建缺失字形',value=False,callback=self.change_settings))
        w.reference=vanilla.TextBox((20,374,330,62),'')
        w.previewCaption=vanilla.TextBox((380,86,360,40),'效果预览 · 设置作用于整批')
        w.preview=vanilla.Group((380,130,360,230))
        w.canvas=SVGBatchSettingsCanvasV1.alloc().initWithFrame_(((0,0),(360,230)));w.canvas.setup(self);w.canvas.setAutoresizingMask_(18);w.preview._nsObject.addSubview_(w.canvas)
        w.previewStatus=vanilla.TextBox((380,368,360,44),'没有可预览材料',sizeStyle='small')
        w.advanced=vanilla.Button((20,424,330,24),'▸ 高级：EPS／PDF 源画布',callback=self.toggle_settings_advanced)
        w.sourceHelp=vanilla.TextBox((20,450,720,24),'源范围用于EPS/PDF，保留留白；不猜测裁切前的位置。')
        self.add_control(w,'vectorCustomFrame',vanilla.CheckBox((20,480,720,24),'使用自定义源画布范围',value=False,callback=self.change_settings))
        for i,(name,title) in enumerate([('vectorFrameX','原点X'),('vectorFrameY','原点Y'),('vectorFrameWidth','宽'),('vectorFrameHeight','高')]):
            x=20+i*180;setattr(w,name+'Label',vanilla.TextBox((x,512,168,22),title));self.add_control(w,name,vanilla.EditText((x,538,165,26),'0' if i<2 else '1000',callback=self.change_settings))
        w.sourceNote=vanilla.TextBox((20,574,720,38),'裁切EPS可显式补充源范围和原点，不能自动恢复丢失的留白。\n只变换本次素材，不移动原有轮廓或智能部件。',sizeStyle='small')
        w.done=vanilla.Button((545,430,195,30),'完成，返回校对',callback=self.finish_settings)
        self.settings_queue=PreviewQueue(self,w)
        w.bind('became key',lambda sender:self.refresh_settings_preview())
        self.sync_settings()
    def open_settings(self,s=None):
        if self.raise_dialog('导入设置'):return
        self.ensure_dialog('settings_window',self.build_settings_dialog)
        w=self.settings_window;w.advanced_open=False
        w.preview_entry_id=preview_entry_id(self.project.state,self.grid.cells,self.gestures.keys)
        self.sync_settings();self.show_dialog(w);self.settings_queue.request()
    def toggle_settings_advanced(self,s=None):
        w=self.settings_window;w.advanced_open=not w.advanced_open;self.layout_settings()
    def sync_settings(self):
        super().sync_settings()
        self.layout_settings()
    def layout_settings(self):
        w=getattr(self,'settings_window',None)
        if w is None or not hasattr(w,'canvas'):return
        st=self.project.state['settings'];native=st.get('import_method','canvas')=='native';fit=not native and bool(st.get('fit_target',False));manual=not native and not fit
        for name in ('height','scale','x','y','width'):
            getattr(w,name).show(False);getattr(w,name+'Label').show(False)
        w.fitTarget.show(not native);w.widthpolicy.show(manual and st['existing']!='append')
        y=86
        if not native:y+=38
        if manual:
            for name in ('height','scale','x','y'):
                getattr(w,name).show(True);getattr(w,name+'Label').show(True);getattr(w,name).setPosSize((155,y,195,26));getattr(w,name+'Label').setPosSize((20,y+2,130,24));y+=34
            if st['existing']!='append':
                w.widthpolicy.setPosSize((20,y,330,26));y+=34
                if st['width_policy']=='uniform' or st['create']:
                    w.width.show(True);w.widthLabel.show(True);w.width.setPosSize((155,y,195,26));w.widthLabel.setPosSize((20,y+2,130,24));y+=34
        w.existing.setPosSize((20,y,330,26));y+=36;w.create.show(not fit)
        if not fit:w.create.setPosSize((20,y,330,24));y+=34
        note='原生候选保留Glyphs的位置和缩放，可能改变字宽。' if native else '需要已有目标字格；整个源画布等比例适配目标字宽和母版范围，保留留白与原字宽。' if fit else '画布左边=X、底边=Y，基线为0；按整幅画布定位。'
        if st['existing']=='append':note+='\n追加仅处理新素材；保留原内容和字宽。'
        w.reference.set(note);w.reference.setPosSize((20,y,330,66));y+=66
        bottom=max(412,y);advanced=not native and w.advanced_open
        w.advanced.show(not native);w.advanced.setTitle(('▾' if advanced else '▸')+' 高级：EPS／PDF 源画布');w.advanced.setPosSize((20,bottom,330,24))
        for control in (w.sourceHelp,w.vectorCustomFrame,w.sourceNote):control.show(advanced)
        custom=advanced and bool(st.get('vector_custom_frame',False))
        for name in ('vectorFrameX','vectorFrameY','vectorFrameWidth','vectorFrameHeight'):
            getattr(w,name).show(custom);getattr(w,name+'Label').show(custom)
        if not native:bottom+=34
        if advanced:
            w.sourceHelp.setPosSize((20,bottom,720,24));bottom+=28;w.vectorCustomFrame.setPosSize((20,bottom,720,24));bottom+=30
            if custom:
                for i,name in enumerate(('vectorFrameX','vectorFrameY','vectorFrameWidth','vectorFrameHeight')):
                    getattr(w,name+'Label').setPosSize((20+i*180,bottom,168,22));getattr(w,name).setPosSize((20+i*180,bottom+24,165,26))
                bottom+=60
            w.sourceNote.setPosSize((20,bottom,720,38));bottom+=44
        w.done.setPosSize((545,bottom+10,195,30));height=bottom+60
        left,top,width,old_height=w.getPosSize()
        if old_height!=height:w.setPosSize((left,top,760,height))
    def save(self,s):
        if getattr(self,'settings_queue',None):self.settings_queue.flush()
        super().save(s)
    def collect_settings(self):
        c=self.w
        values=dict(import_method='native' if c.importmethod.get()==0 else 'canvas',fit_target=bool(c.fitTarget.get()),existing=['skip','replace','append'][c.existing.get()],create=bool(c.create.get()),width_policy='preserve' if c.widthpolicy.get()==0 else 'uniform',vector_custom_frame=bool(c.vectorCustomFrame.get()))
        for name,key in [('height','canvas_height'),('scale','scale'),('x','x'),('y','y'),('width','width'),('vectorFrameX','vector_frame_x'),('vectorFrameY','vector_frame_y'),('vectorFrameWidth','vector_frame_width'),('vectorFrameHeight','vector_frame_height')]:values[key]=getattr(c,name).get()
        return settings_values(self.project.state['settings'],values)
    def change_settings(self,s=None):
        if self.timer:alert('导入中只允许取消，完成后再调整');return
        self.pending_host=None
        summary=getattr(self,'summary',None)
        if summary is not None and summary.getNSWindow() is not None:summary.confirm.enable(False)
        sync=any(s is getattr(self.w,name,None) for name in ('importmethod','fitTarget','vectorCustomFrame','existing','widthpolicy','create'))
        self.settings_queue.request(commit=True,sync=sync)
    def refresh_settings_preview(self):
        w=getattr(self,'settings_window',None)
        if w is not None and hasattr(w,'canvas') and w.getNSWindow() is not None and w.getNSWindow().isVisible():self.settings_queue.request()
    def finish_settings(self,s=None):
        self.settings_queue.flush()
        if not self.settings_queue.parameters_valid:return
        self.finish_dialog(self.settings_window)
