from .target_identity import has_target,label,unicode_label
from .search import Search
from .native_collections import native_items, descendant_views
import copy
import math
import traceback
from collections import OrderedDict
from pathlib import Path
import objc
import Quartz  # Register CoreGraphics bridge types before accessing NSColor.CGColor.
import vanilla
from AppKit import (NSView, NSColor, NSBezierPath, NSFont, NSFontAttributeName,
    NSForegroundColorAttributeName, NSRectFill, NSOpenPanel, NSSavePanel, NSAlert,
    NSAlertFirstButtonReturn, NSDragOperationCopy, NSFilenamesPboardType)
from Foundation import NSString, NSURL, NSTimer, NSObject
from GlyphsApp import Glyphs
from .model import Project, entries, read_txt, target_status, identifier
from .svg import read_svg, mapped
from .vector_source import read_source,native_only
from .table import entry_status
from .host import HostSession, unicode_matches
from .preview_lookup import geometry_scope

from .storage import DATA_ROOT as ROOT


def alert(message, confirm=False):
    a=NSAlert.alloc().init(); a.setMessageText_('字动力 · 矢量批量导入'); a.setInformativeText_(str(message))
    a.addButtonWithTitle_('确认' if confirm else '好')
    if confirm: a.addButtonWithTitle_('取消')
    return a.runModal()==NSAlertFirstButtonReturn


def choose(save=False, directory=False, types=None):
    p=NSSavePanel.savePanel() if save else NSOpenPanel.openPanel()
    if not save:
        p.setCanChooseDirectories_(directory); p.setCanChooseFiles_(not directory)
        p.setAllowsMultipleSelection_(not directory)
    if types: p.setAllowedFileTypes_(types)
    p.setDirectoryURL_(NSURL.fileURLWithPath_(str(Path.home()/'Documents')))
    if p.runModal()!=1: return []
    return [str(p.URL().path())] if save else [str(u.path()) for u in native_items(p.URLs())]


def text(value, x,y,size=11,color=None):
    NSString.stringWithString_(str(value)).drawAtPoint_withAttributes_((x,y),{
        NSFontAttributeName:NSFont.systemFontOfSize_(size),
        NSForegroundColorAttributeName:color or NSColor.labelColor()})


if 'SVGBatchCompactTickV2' not in globals():
    class SVGBatchCompactTickV2(NSObject):
        def tick_(self,timer):
            if self.owner is not None:self.owner.tick(timer)
            else:timer.invalidate()
SVGBatchCompactTick=SVGBatchCompactTickV2


class PanelActions:
    def closed(self,s):
        if self.timer:
            self.cancel(None)

    def guard(self,action):
        try:
            if self.timer: raise ValueError('导入中只允许取消，完成后再调整')
            action(); self.refresh()
        except Exception as exc:
            traceback.print_exc(); alert(exc)

    def status(self,e):
        if e['id'] in self.project.duplicates(): return '重复目标：选择一个版本'
        st=entry_status(e)
        if st!='可用': return st
        aid=self.project.state['assignments'].get(e['id'])
        if aid in self.errors: return '解析失败'
        return '已分配' if aid else '缺字稿'

    def parsed_svg(self,aid):
        a=self.project.state['assets'][aid];p=Path(a['path']);stat=p.stat()
        key=('svg-source',aid,a.get('pdf_page'),stat.st_mtime_ns,stat.st_size)
        if key not in self.cache:
            prepared=getattr(self,'pdf_sources',{}).get((str(p),a['sha256'],a.get('pdf_page'),stat.st_mtime_ns,stat.st_size))
            self.cache[key]=prepared if prepared is not None else read_source(p,a.get('pdf_page'))
            while len(self.cache)>64:self.cache.popitem(last=False)
        self.cache.move_to_end(key)
        if self.cache[key].get('page_problem'):raise ValueError(self.cache[key]['page_problem'])
        return self.cache[key]

    @geometry_scope
    def geometry(self,aid,entry=None):
        from .target_fit import enabled,preview_candidate,assigned_entry
        if Path(self.project.state['assets'][aid]['path']).suffix.lower() in ('.eps','.pdf') and self.project.state['settings'].get('import_method','canvas')!='native':
            from .vector_canvas import preview_candidate as vector_candidate
            result=vector_candidate(self,aid,entry);self.errors.pop(aid,None);return result['contours']
        if enabled(self.project.state['settings']):
            target=entry or assigned_entry(self,aid)
            if target is not None:
                result=preview_candidate(self,aid,target);self.errors.pop(aid,None);return result['contours']
            return mapped(self.parsed_svg(aid),dict(canvas_height=1000.,scale=1.,x=0.,y=0.))
        a=self.project.state['assets'][aid]
        p=Path(a['path']); stat=p.stat()
        native=self.project.state['settings'].get('import_method','canvas')=='native'
        context=()
        if native:
            from .native_import import preview_candidate as native_candidate
            result=native_candidate(self,aid,entry);self.errors.pop(aid,None);return result['contours']
        key=(context,aid,stat.st_mtime_ns,stat.st_size,tuple(sorted(self.project.state['settings'].items())))
        if key not in self.cache:
            if native:
                from .native_import import candidate
                self.parsed_svg(aid)  # Retain SVG support and external-reference guards.
                self.cache[key]=candidate(p,self.locked_font,self.locked_master,layer=layer,width=self.project.state['settings']['width'])['contours']
            else:self.cache[key]=mapped(self.parsed_svg(aid),self.project.state['settings'])
            while len(self.cache)>64: self.cache.popitem(last=False)
        self.cache.move_to_end(key)
        self.errors.pop(aid,None)  # A successful re-read supersedes old failures.
        return self.cache[key]

    def refresh(self,s=None):
        cells=[]; query=str(self.w.search.get()); f=self.w.filter.get()
        search=Search(query);self.search_plan=search
        duplicates=self.project.duplicates()
        for i,e in enumerate(self.project.state['entries']):
            aid=self.project.state['assignments'].get(e['id'])
            a=self.project.state['assets'].get(aid,{})
            if not search.entry(e,a.get('name','')):continue
            if f==1 and aid and has_target(e): continue
            if f==2 and e['id'] not in duplicates: continue
            if f==3:
                if aid:
                    try: self.geometry(aid)
                    except Exception as exc: self.errors[aid]=str(exc)
                if aid not in self.errors: continue
            if f==4:
                if not self.locked_font:continue
                if e.get('host_binding'):
                    from .host_targets import resolve_binding
                    try:
                        b=e['host_binding'];matches=[resolve_binding(e,self.locked_font,self.locked_master,{b['glyph_id']:self.locked_font.glyphs[b['glyph_name']]})]
                    except ValueError:continue
                else:
                    if len(e['value'])!=1:continue
                    from .preview_lookup import scope,PreviewPending
                    try:
                        with scope(self,e):matches=unicode_matches(self.locked_font,ord(e['value']))
                    except PreviewPending:continue
                if not any(g.layers[self.locked_master] and len(g.layers[self.locked_master].shapes) for g in matches): continue
            if f==5: continue
            cells.append(dict(kind='target',entry=e,position=i+1))
        if search.text and search.values:cells.sort(key=lambda cell:search.rank(cell['entry']))
        cells.append(dict(kind='pool'))
        for aid in self.project.unassigned():
            if not search.asset(self.project.state['assets'][aid]['name']):continue
            cells.append(dict(kind='pool',asset=aid))
        self.grid.cells=cells
        self.grid.setFrameSize_((800,max(410,math.ceil(len(cells)/5)*205)))
        self.grid.setNeedsDisplay_(True)
        self.w.status.set('目标 %d · 素材 %d · 已分配 %d · 待分配 %d'%(len(self.project.state['entries']),len(self.project.state['assets']),len(self.project.state['assignments']),len(self.project.unassigned())))

    def history(self,redo):
        def action():
            self.project.redo() if redo else self.project.undo()
            self.sync_settings()
        self.guard(action)

    def load_txt(self,s):
        paths=choose(types=['txt'])
        if paths:
            self.guard(lambda:self.set_source(read_txt(paths[0],['utf-8-sig','utf-16','gb18030','big5'][self.w.encoding.get()]),paths[0]))

    def set_source(self,text,source):
        self.w.source.set(text); self.source_path=source; self.loaded_source_text=text

    def extract(self,s):
        def action():
            raw=self.w.source.get(); lines=raw.split('\n')
            a,sep,b=self.w.range.get().partition('-'); start=int(a or '1'); end=int(b) if b else len(lines)
            if not 1<=start<=end<=len(lines): raise ValueError('来源行范围无效')
            source=getattr(self,'source_path','粘贴') if raw==getattr(self,'loaded_source_text',None) else '粘贴/编辑'
            es=entries('\n'.join(lines[start-1:end]),'continuous' if self.w.readmode.get()==0 else 'items',self.w.whitespace.get(),source,start)
            message='提取 %d 个位置（空项 %d）。\n'%(len(es),sum(not e['value'] for e in es))+'\n'.join('%d: %s [%s]'%(i+1,e['value'] or '□',target_status(e['value'])) for i,e in enumerate(es[:35]))
            if self.project.state['assignments']:
                message+='\n现有字表将被替换：保留绑定模式退回全部素材；位置模式重新按位置绑定。'
            if alert(message+'\n采用此预览？',True):
                self.project.replace_entries(es,'identity' if self.w.binding.get()==0 else 'position')
        self.guard(action)

    def add_files(self,paths):
        self.guard(lambda:self.project.add_files(paths))
    def load_svg(self,s): self.add_files(choose(types=['svg','eps','pdf']))
    def load_folder(self,s): self.add_files(choose(directory=True))

    def index(self):
        if self.w.mode.get()!=1: raise ValueError('请切换字表整理模式')
        i=int(self.w.position.get())-1
        if not 0<=i<len(self.project.state['entries']): raise ValueError('目标序号越界')
        return i

    def apply_entries(self,es):
        if alert('字表调整将影响 %d 个位置。\n%s。删除/留空的素材退回待分配；不删除源文件。'%(len(es),self.w.binding.getItems()[self.w.binding.get()]),True):
            self.project.replace_entries(es,'identity' if self.w.binding.get()==0 else 'position')

    def edit_target(self,s):
        def action():
            i=self.index();value=str(self.w.value.get())
            if value=='':
                es=copy.deepcopy(self.project.state['entries']);es[i]['value']='';es[i].pop('host_binding',None)
                es[i].pop('display',None);es[i].pop('code_record',None)
                self.apply_entries(es)
            else:self.open_target_edit(s,entry_id=self.project.state['entries'][i]['id'],initial=value)
        self.guard(action)
    def add_target(self,s):
        def action():
            if self.w.mode.get()!=1: raise ValueError('请切换字表整理模式')
            es=copy.deepcopy(self.project.state['entries']); i=int(self.w.position.get())-1
            if not 0<=i<=len(es): raise ValueError('插入序号越界')
            entry=dict(id=identifier(),value=self.w.value.get(),source='人工补字',original_position=None)
            display=self.record_display_for_edit(entry['value'])
            if display:entry['display']=display
            es.insert(i,entry)
            self.apply_entries(es)
        self.guard(action)
    def delete_target(self,s):
        def action():
            es=copy.deepcopy(self.project.state['entries']); del es[self.index()]; self.apply_entries(es)
        self.guard(action)
    def reorder(self,delta):
        def action():
            i=self.index(); es=copy.deepcopy(self.project.state['entries']); j=i+delta
            if not 0<=j<len(es): raise ValueError('已经到达边界')
            es[i],es[j]=es[j],es[i]; self.apply_entries(es); self.w.position.set(str(j+1))
        self.guard(action)
    def dedupe(self,s):
        def action():
            if self.w.dup.get()==0: return
            if self.w.dup.get()==2 and self.project.state['assignments']: raise ValueError('已绑定素材时请使用重复位置留空，避免压缩原编号')
            if alert('重复处理会将移除位置的素材退回待分配，确认？',True): self.project.deduplicate('blank' if self.w.dup.get()==1 else 'delete')
        self.guard(action)

    def map(self,s):
        def action():
            mode=['number','order','unicode'][self.w.mapmode.get()]
            proposal,rows=self.project.mapping_proposal(mode,int(self.w.group.get()),int(self.w.firstnumber.get()),int(self.w.firstposition.get()))
            msg='数字组 %s，起始编号 %s → 位置 %s\n'%(self.w.group.get(),self.w.firstnumber.get(),self.w.firstposition.get())
            msg+='\n'.join('%s 数字%s → %s %s'%(r['file'],r['numbers'],r['position'],r['status']) for r in rows[:40])
            msg+='\n可对应 %d / 文件 %d。完整结果保存在reports/mapping-preview.json。\n数量一致不证明内容正确；自然顺序模式遇漏文件会错位。\n确认替换当前分配？'%(len(proposal),len(rows))
            from .model import atomic_json
            atomic_json(ROOT/'reports'/'mapping-preview.json',rows)
            if alert(msg,True):
                def adopt():
                    self.project.state.update(assignments=proposal,mapping_preview=rows)
                    self.project.state['settings'].update(mapping_mode=mode,number_group=int(self.w.group.get()),first_number=int(self.w.firstnumber.get()),first_position=int(self.w.firstposition.get()))
                    for row in rows: self.project.state['assets'][row['asset']]['number_groups']=row['numbers']
                self.project.edit(adopt)
        self.guard(action)

    def drag(self,source,dest):
        def action():
            if self.w.mode.get()!=0: raise ValueError('字表整理模式请用目标操作；素材拖动需切回校对模式')
            aid=source.get('asset') if source['kind']=='pool' else self.project.state['assignments'].get(source['entry']['id'])
            if not aid: return
            target=dest['entry']['id'] if dest['kind']=='target' else None
            mode='insert' if self.w.dragmode.get()==1 else 'swap'
            filtered=bool(self.w.search.get()) or self.w.filter.get()!=0
            if mode=='insert' and target:
                if filtered: raise ValueError('筛选状态禁止插入；请清除搜索/筛选')
                pos=dest['position']; total=len(self.project.state['entries'])
                if not alert('插入将顺移位置 %d–%d 的素材，超出范围的文件退回待分配。确认？'%(pos,total),True): return
            self.project.move(aid,target,mode,filtered)
        self.guard(action)

    def enlarge(self,cell):
        aid=cell.get('asset') if cell['kind']=='pool' else self.project.state['assignments'].get(cell['entry']['id'])
        if not aid: return
        # Reuse same grid geometry, scale the view for zoom; no alternate SVG renderer.
        self.zoom=vanilla.Window((650,750),'对应放大预览')
        v=SVGBatchGridView.alloc().initWithFrame_(((0,0),(800,205))); v.setup(self); v.cells=[cell]
        v.scaleUnitSquareToSize_((3.5,3.5)); v.setFrameSize_((600,720))
        self.zoom.scroll=vanilla.ScrollView((10,10,-10,-10),v); self.zoom.open()

    def sync_settings(self):
        st=self.project.state['settings']
        for key,name in [('canvas_height','height'),('scale','scale'),('x','x'),('y','y'),('width','width')]: getattr(self.w,name).set(str(st[key]))
        if hasattr(self.w,'importmethod'):self.w.importmethod.set(0 if st.get('import_method','canvas')=='native' else 1)
        self.w.widthpolicy.set(0 if st['width_policy']=='preserve' else 1)
        self.w.existing.set(['skip','replace','append'].index(st['existing']))
        self.w.create.set(st['create'])
        native=st.get('import_method','canvas')=='native'
        fit=not native and bool(st.get('fit_target',False))
        if hasattr(self.w,'fitTarget'):
            self.w.fitTarget.set(bool(st.get('fit_target',False)))
            if hasattr(self.w.fitTarget,'enable'):self.w.fitTarget.enable(not native)
        window=getattr(self,'settings_window',None)
        if window is not None and hasattr(window,'reference'):
            window.reference.set('整个源画布等比例适配目标实际字宽与母版范围。\n保留原字宽；旧画布参数暂不生效。' if fit else '使用当前字体和母版的原生位置、缩放、字宽。\n左侧画布参数仅用于统一画布方式。' if native else '画布左边=X、底边=Y；基线为0。\n按画布定位，字宽由下方策略决定。')
        if window is not None and hasattr(window,'reference') and st['existing']=='append':
            window.reference.set(('使用Glyphs原生轮廓坐标；追加保留目标原字宽。' if native else window.reference.get())+'\n灰色为已有内容，不自动找空位。')
        for name in ('height','scale','x','y','width','widthpolicy'):
            control=getattr(self.w,name,None)
            if hasattr(control,'enable'):control.enable(not native and not fit and not (st['existing']=='append' and name in ('width','widthpolicy')))
        if hasattr(self.w,'vectorCustomFrame'):
            self.w.vectorCustomFrame.set(bool(st.get('vector_custom_frame',False)))
            if hasattr(self.w.vectorCustomFrame,'enable'):self.w.vectorCustomFrame.enable(not native)
            for key,name,default in [('vector_frame_x','vectorFrameX',0),('vector_frame_y','vectorFrameY',0),('vector_frame_width','vectorFrameWidth',1000),('vector_frame_height','vectorFrameHeight',1000)]:
                control=getattr(self.w,name);control.set(str(st.get(key,default)))
                if hasattr(control,'enable'):control.enable(not native and bool(st.get('vector_custom_frame',False)))
        self.w.group.set(str(st['number_group']))
        self.w.firstnumber.set(str(st['first_number']))
        self.w.firstposition.set(str(st['first_position']))
        self.w.mapmode.set(['number','order','unicode'].index(st.get('mapping_mode','number')))

    def change_settings(self,s):
        def action():
            updates={k:float(getattr(self.w,n).get()) for k,n in [('canvas_height','height'),('scale','scale'),('x','x'),('y','y'),('width','width')]}
            if not all(math.isfinite(v) for v in updates.values()) or any(updates[k]<=0 for k in ('canvas_height','scale','width')): raise ValueError('参数必须有限，尺寸/缩放必须大于0')
            if hasattr(self.w,'importmethod'):updates['import_method']='native' if self.w.importmethod.get()==0 else 'canvas'
            if hasattr(self.w,'fitTarget'):updates['fit_target']=bool(self.w.fitTarget.get())
            if hasattr(self.w,'vectorCustomFrame'):
                updates['vector_custom_frame']=bool(self.w.vectorCustomFrame.get())
                for key,name in [('vector_frame_x','vectorFrameX'),('vector_frame_y','vectorFrameY'),('vector_frame_width','vectorFrameWidth'),('vector_frame_height','vectorFrameHeight')]:updates[key]=float(getattr(self.w,name).get())
                if not all(math.isfinite(updates[k]) for k in ('vector_frame_x','vector_frame_y','vector_frame_width','vector_frame_height')) or min(updates['vector_frame_width'],updates['vector_frame_height'])<=0:raise ValueError('源画布宽高须为有限正数，原点须有限')
            updates.update(width_policy='preserve' if self.w.widthpolicy.get()==0 else 'uniform',existing=['skip','replace','append'][self.w.existing.get()],create=bool(self.w.create.get()))
            self.project.edit(lambda:self.project.state['settings'].update(updates))
            if any(s is getattr(self.w,name,None) for name in ('importmethod','fitTarget','vectorCustomFrame','existing','widthpolicy')):self.sync_settings()
        self.guard(action)

    def lock(self,s):
        def action():
            f=Glyphs.font
            if not f or not f.selectedFontMaster: raise ValueError('请打开目标字体并选择母版')
            self.locked_font=f; self.locked_master=f.selectedFontMaster.id
            target=dict(font_path=str(f.filepath),family=f.familyName,master_id=self.locked_master,master_name=f.selectedFontMaster.name)
            self.project.edit(lambda:self.project.state.update(target=target))
            self.w.target.set('%s · %s · 母版层ID %s'%(f.familyName,f.selectedFontMaster.name,self.locked_master))
        self.guard(action)

    def import_batch(self,s):
        def action():
            if not self.locked_font: raise ValueError('先锁定目标字体/母版')
            if self.host and any(not r.get('recovered') for r in self.host.records): raise ValueError('请先处理上次恢复记录或重开面板；完整备份仍保存')
            self.host=HostSession(self.project,self.locked_font,self.locked_master,ROOT)
            rows=self.host.preflight()
            from .model import atomic_json
            atomic_json(ROOT/'reports'/'preflight.json',rows)
            msg='目标：'+self.w.target.get()+'\n'+'\n'.join('%s %s: %s'%(r['position'],r['value'],r['status']) for r in rows[:45])
            if any(r['status'].startswith('阻止') for r in rows): alert(msg+'\n存在阻止项，未写入。完整列表见reports/preflight.json'); return
            if len(self.host.plan)>30: raise ValueError('开发首版小批限制30项；100/1000性能阶段尚未验收')
            if not alert(msg+'\n写入 %d 项；将先保存完整字体副本。确认？'%len(self.host.plan),True): return
            self.host.begin()
            self.tick_target=SVGBatchCompactTick.alloc().init(); self.tick_target.owner=self
            self.timer=NSTimer.scheduledTimerWithTimeInterval_target_selector_userInfo_repeats_(.05,self.tick_target,'tick:',None,True)
        self.guard(action)

    def tick(self,timer):
        try:
            more=self.host.step()
            self.w.status.set('已写入 %d/%d，取消停止后续，备份：%s'%(len(self.host.records),len(self.host.plan),self.host.backup))
            if not more:
                timer.invalidate(); self.timer=None; self.refresh(); alert('本次已写入 %d 项。\nCmd+Z为宿主字形级撤销，整批范围尚需实测；可使用本面板恢复。'%len(self.host.records))
        except Exception as exc:
            timer.invalidate(); self.timer=None; self.host.cancelled=True
            if self.host.cursor<len(self.host.plan): self.host.plan[self.host.cursor]['row']['status']='失败：'+str(exc)
            self.host.journal()
            alert('停止，已写入 %d 项，可恢复。\n%s'%(len(self.host.records),exc))
    def cancel(self,s):
        if self.host: self.host.cancelled=True
        if self.timer: self.timer.invalidate(); self.timer=None
        if self.host and self.host.backup: self.host.journal()
        self.w.status.set('已取消后续；本次已写入 %d 项'%(len(self.host.records) if self.host else 0))
    def recover(self,s):
        def action():
            if not self.host or not self.host.records: raise ValueError('本面板没有可恢复写入；关闭后请使用backups内完整字体副本另开对照')
            if alert('恢复本次已写入；后续独立编辑会阻止恢复。确认？',True): alert('已恢复 %d 项'%self.host.recover())
        self.guard(action)

    def save(self,s):
        def action():
            p=choose(save=True,types=['json'])
            if p:
                self.project.save(p[0]); self.project_path=p[0]; self.saved_state=copy.deepcopy(self.project.state)
        self.guard(action)
    def open(self,s):
        def action():
            p=choose(types=['json'])
            if not p: return
            self.project=Project.load(p[0]); self.project_path=p[0]; self.saved_state=copy.deepcopy(self.project.state); self.locked_font=None; self.locked_master=None
            self.w.target.set('工程已读取，宿主目标必须重新锁定')
            st=self.project.state['settings']
            for key,name in [('canvas_height','height'),('scale','scale'),('x','x'),('y','y'),('width','width')]: getattr(self.w,name).set(str(st[key]))
            self.sync_settings()
            checks=self.project.file_checks(); bad=[self.project.state['assets'][k]['name']+': '+v for k,v in checks.items() if v!='正常']
            self.cache.clear(); self.errors.clear()
            if bad: alert('\n'.join(bad[:35]))
        self.guard(action)
    def relocate(self,s):
        def action():
            i=int(self.w.position.get())-1; e=self.project.state['entries'][i]; aid=self.project.state['assignments'].get(e['id'])
            if not aid: raise ValueError('该目标未分配素材')
            p=choose(types=['svg','eps','pdf'])
            if len(p)==1: self.project.relocate(aid,p[0]); self.errors.pop(aid,None)
        self.guard(action)

SVGBatchTick = SVGBatchCompactTick
