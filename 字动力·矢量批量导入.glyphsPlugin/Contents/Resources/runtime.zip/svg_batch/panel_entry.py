"""Session selection across close/reopen and Python hot reload; no host writes."""
def live_panel(panel):
    main=getattr(panel,'main',None)
    return bool(panel is not None and getattr(panel,'_initialized',False) and not getattr(panel,'_closed',False) and main is not None and main.getNSWindow() is not None)


def select_session(active,fallback=None):
    candidates=(active,fallback)
    for panel in candidates:
        if live_panel(panel):return panel,True
    for panel in candidates:
        if panel is not None and getattr(panel,'_closed',False) and hasattr(panel,'project') and hasattr(panel,'main'):
            return panel,False
    return None,False


def raise_panel(panel):
    """Keep pending preview/dialog and ongoing tasks; activate without rebuilding."""
    panel.main.show();panel.main.getNSWindow().makeKeyAndOrderFront_(None)
    pending=getattr(panel,'drop_window',None) if getattr(panel,'drop_draft',None) else None
    visible=[w for w in getattr(panel,'dialogs',[]) if w.getNSWindow() is not None and w.getNSWindow().isVisible()]
    child=pending if pending is not None and pending.getNSWindow() is not None else visible[-1] if visible else None
    if child is not None:child.show();child.getNSWindow().makeKeyAndOrderFront_(None)
    return panel


# Strong references retain closed plans, not ownership inferred from names/paths.
# A detached document is never selected automatically after it is reopened.
if '_document_panels' not in globals():_document_panels=[]

def owner_matches(panel,font):
    from .host_targets import same_object
    owner=getattr(panel,'owner_font',None)
    return not getattr(panel,'owner_invalid',False) and ((owner is None and font is None) or (owner is not None and font is not None and same_object(owner,font)))

def document_panel(font):
    for panel in reversed(_document_panels):
        if owner_matches(panel,font):return panel
    return None

def register_panel(panel):
    if not any(panel is existing for existing in _document_panels):_document_panels.append(panel)

def all_panels():return tuple(_document_panels)
