"""Session selection across close/reopen and Python hot reload; no host writes."""
def live_panel(panel):
    main=getattr(panel,'main',None)
    return bool(panel is not None and getattr(panel,'_initialized',False) and not getattr(panel,'_closed',False) and main is not None and main.getNSWindow() is not None)


def select_session(active,fallback=None):
    candidates=(active,fallback)
    for panel in candidates:
        if live_panel(panel):return panel,True
    for panel in candidates:
        if panel is not None and getattr(panel,'_closed',False) and hasattr(panel,'project') and hasattr(panel,'main'):
            return panel,False
    return None,False


def raise_panel(panel):
    """Keep pending preview/dialog and ongoing tasks; activate without rebuilding."""
    panel.main.show();panel.main.getNSWindow().makeKeyAndOrderFront_(None)
    pending=getattr(panel,'drop_window',None) if getattr(panel,'drop_draft',None) else None
    visible=[w for w in getattr(panel,'dialogs',[]) if w.getNSWindow() is not None and w.getNSWindow().isVisible()]
    child=pending if pending is not None and pending.getNSWindow() is not None else visible[-1] if visible else None
    if child is not None:child.show();child.getNSWindow().makeKeyAndOrderFront_(None)
    return panel
