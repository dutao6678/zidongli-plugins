from .i18n import message as M,format_message as MF,percent_message as MP,join_message as MJ,string_message as ms,render as R
"""Settings-only selection and validation. No geometry or host operations."""
import math

def preview_entry_id(state,cells,keys):
    for cell in cells:
        entry=cell.get('entry')
        if entry and ('target',entry['id']) in keys:return entry['id']
    return next((e['id'] for e in state['entries'] if e['id'] in state['assignments']),None)

def settings_values(previous,values):
    result=dict(previous)
    result.update(import_method=values['import_method'],fit_target=bool(values['fit_target']),
                  existing=values['existing'],create=bool(values['create']))
    canvas=result['import_method']=='canvas';manual=canvas and not result['fit_target']
    if manual:
        for key in ('canvas_height','scale','x','y'):
            result[key]=float(values[key])
            if not math.isfinite(result[key]) or (key in ('canvas_height','scale') and result[key]<=0):raise ValueError(M('画布高度/缩放须为有限正数，位置须为有限数值'))
        if result['existing']!='append':
            result['width_policy']=values['width_policy']
            if result['width_policy']=='uniform' or result['create']:
                result['width']=float(values['width'])
                if not math.isfinite(result['width']) or result['width']<=0:raise ValueError(M('字宽须为有限正数'))
    if canvas:
        result['vector_custom_frame']=bool(values['vector_custom_frame'])
        if result['vector_custom_frame']:
            for key in ('vector_frame_x','vector_frame_y','vector_frame_width','vector_frame_height'):
                result[key]=float(values[key])
                if not math.isfinite(result[key]) or (key in ('vector_frame_width','vector_frame_height') and result[key]<=0):raise ValueError(M('源画布宽高须为有限正数，原点须为有限数值'))
    return result
