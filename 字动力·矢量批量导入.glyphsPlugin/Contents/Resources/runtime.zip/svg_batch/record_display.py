"""Serializable display provenance. Never defines character identity or mapping."""
import copy


def font_map(entry):
    display=entry.get('display',{})
    if not isinstance(display,dict) or display.get('value')!=entry.get('value'):return {}
    fonts=display.get('fonts',{})
    if not isinstance(fonts,dict):return {}
    return {int(i):name for i,name in fonts.items() if str(i).isascii() and str(i).isdigit() and int(i)<len(entry['value']) and isinstance(name,str) and name}


def attach_display(entry,fonts):
    entry.pop('display',None)
    clean={str(i):name for i,name in fonts.items() if 0<=i<len(entry.get('value','')) and isinstance(name,str) and name}
    if clean:entry['display']=dict(value=entry['value'],fonts=clean,provenance='verified-source-font')
    return entry


def edited_display(old,value,known=None):
    if value==old.get('value'):return copy.deepcopy(old.get('display'))
    temp=attach_display(dict(value=value),{i:known[c] for i,c in enumerate(value) if known and known.get(c)})
    return temp.get('display')
