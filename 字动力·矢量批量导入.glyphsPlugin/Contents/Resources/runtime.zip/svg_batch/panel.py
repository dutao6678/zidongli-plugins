from .i18n import message as M,format_message as MF,percent_message as MP,join_message as MJ,string_message as ms,render as R
from .native_collections import native_items, descendant_views
"""Compact native presentation; existing model/parser/transactions stay authoritative."""
import copy
import math
import traceback
from collections import OrderedDict
from functools import lru_cache
from pathlib import Path
import objc
import Quartz
from . import localized_ui as vanilla
from AppKit import (NSView, NSWindow, NSColor, NSBezierPath, NSRectFill, NSGraphicsContext,
    NSMenu, NSMenuItem, NSCommandKeyMask, NSShiftKeyMask, NSTextView,
    NSPointInRect, NSDragOperationCopy, NSFilenamesPboardType, NSFont, NSFontAttributeName, NSForegroundColorAttributeName, NSAffineTransform)
from Foundation import NSObject, NSURL, NSTimer, NSString, NSAttributedString
from GlyphsApp import Glyphs
from .model import Project, entries, target_status, identifier, atomic_json
from .drop import proposal as drop_proposal, adopt as adopt_drop, placement_stats, direct_proposal
from .table import parse_table, record_problem, entry_status, status_label
from .host import HostSession
from .document_ui import DocumentUI
from .session_ui import SessionUI, DetachedControl
from .target_edit_ui import TargetEditingUI
from .host_source_ui import HostSourceUI
from .pdf_material_ui import PDFMaterialUI
from .host_targets import prune_sessions
from .target_identity import has_target,label,unicode_label,code_caption
from .display_text import target_label
from .label_layout import header_layout
from .hit_testing import card_rect,CARD_INSET,intersects
from .editor_fonts import (SourceTextEditor, clipboard_hints, apply_fonts, entry_attributed, entry_warning,
    attach_editor_records, snapshot_fonts, restore_snapshot, TargetEditText)
from .record_display import font_map,attach_display,edited_display
from .native_interaction import Gestures, SVGBatchSplitHandleV10, SVGBatchPoolDropHeaderV2, make_grid
from .rearrange import key as selection_key, remove_selected, target_delete_plan, adopt_target_delete
from .model import states_equal
from .editor_resize import FontRuns,ResizeQueue,cancel_resize
from .search_control import SearchControl
from .menu_titles import MenuTitle,MenuTitles
from .panel_entry import live_panel,select_session,raise_panel
from .panel_actions import PanelActions, SVGBatchTick, ROOT, alert, choose, text


class ControlRouter:
    """Legacy callbacks resolve their controls without moving NSViews between windows."""
    def __init__(self, main): self.main=main; self.controls={}
    def __getattr__(self,name):
        if name in self.controls: return self.controls[name]
        return getattr(self.main,name)


@lru_cache(maxsize=4096)
def _measure_text_rendered(value,size=13):
    return NSString.stringWithString_(value).sizeWithAttributes_({NSFontAttributeName:NSFont.systemFontOfSize_(size)}).width

def measure_text(value,size=13):return _measure_text_rendered(R(value),size)
measure_text.cache_clear=_measure_text_rendered.cache_clear


@lru_cache(maxsize=4096)
def _fitted_text_rendered(value,width,size=11):
    """Presentation-only truncation; full names remain in cell details."""
    value=R(value)
    if measure_text(value,size)<=width:return value
    while value and measure_text(value+'…',size)>width:value=value[:-1]
    return value+'…'


def fitted_text(value,width,size=11):return _fitted_text_rendered(R(value),width,size)
fitted_text.cache_clear=_fitted_text_rendered.cache_clear


def draw_target_header(entry,position,x,y,width,cache=None):
    """One label path for host, parsed, pasted and manually edited targets."""
    if cache is None:cache={}
    if not cache:
        label,_=target_label(entry['value']);binding=entry.get('host_binding')
        name_label=bool(binding and (not entry['value'] or entry_warning(entry)))
        if name_label:label=binding['glyph_name']
        code=code_caption(entry)
        attributed=entry_attributed(entry,14) if font_map(entry) and not name_label else None
        label_width=attributed.size().width if attributed is not None else NSString.stringWithString_(R(label)).sizeWithAttributes_({NSFontAttributeName:NSFont.systemFontOfSize_(14)}).width
        code_width=NSString.stringWithString_(R(code)).sizeWithAttributes_({NSFontAttributeName:NSFont.systemFontOfSize_(10)}).width
        cache.update(label=label,code=code,name_label=name_label,attributed=attributed,label_width=label_width,code_width=code_width)
    label=cache['label'];code=cache['code'];name_label=cache['name_label'];attributed=cache['attributed'];label_width=cache['label_width'];code_width=cache['code_width']
    layout=header_layout(width,label_width,code_width,name_label)
    if attributed is not None:
        NSGraphicsContext.saveGraphicsState()
        try:
            NSBezierPath.bezierPathWithRect_(((x+12,y+7),(layout['label_width'],24))).addClip()
            attributed.drawAtPoint_((x+12,y+10))
        finally:NSGraphicsContext.restoreGraphicsState()
    else:text(fitted_text(label,layout['label_width'],14),x+12,y+10,14)
    if code:text(fitted_text(code,layout['code_width'],10),x+layout['code_x'],y+layout['code_y'],10,NSColor.secondaryLabelColor())
    text(MP('%02d',position),x+width-29,y+13,11,NSColor.secondaryLabelColor())


if 'SVGBatchPolishedChromeV2' not in globals():
    class SVGBatchPolishedChromeV2(NSView):
        def isFlipped(self):return True
        def drawRect_(self,rect):
            bounds=self.bounds();width=bounds.size.width;height=bounds.size.height
            NSColor.controlBackgroundColor().set();NSRectFill(rect)
            NSColor.windowBackgroundColor().set()
            footer=getattr(getattr(self,'owner',None),'footer_height',96)
            NSRectFill(((0,0),(width,42)));NSRectFill(((0,height-footer),(width,footer)))
            NSColor.labelColor().blendedColorWithFraction_ofColor_(.88,NSColor.controlBackgroundColor()).set()
            NSRectFill(((0,41),(width,1)));NSRectFill(((0,height-footer),(width,1)))


if 'SVGBatchCompactWindow' not in globals():
    class SVGBatchCompactWindow(NSWindow):
        def cancelOperation_(self,sender):
            owner=getattr(self,'batch_owner',None)
            if owner and owner.escape(self):return
            return objc.super(SVGBatchCompactWindow,self).cancelOperation_(sender)
        def performKeyEquivalent_(self,event):
            owner=getattr(self,'batch_owner',None)
            if owner and owner.handle_display_key(self,event):return True
            flags=event.modifierFlags(); char=ms(event.charactersIgnoringModifiers() or '').lower()
            if owner and flags & NSCommandKeyMask and char=='w':
                focus=self.firstResponder()
                if isinstance(focus,NSTextView) and focus.hasMarkedText():return False
                self.performClose_(None);return True
            if owner and flags & NSCommandKeyMask and char=='z':
                focus=self.firstResponder()
                if isinstance(focus,NSTextView):
                    if not focus.isEditable():return True
                else:
                    # Child previews never send undo to a font or another plan.
                    if self==owner.main.getNSWindow():owner.history(bool(flags & NSShiftKeyMask))
                    return True
            return objc.super(SVGBatchCompactWindow,self).performKeyEquivalent_(event)


if 'SVGBatchWindowShellV3' not in globals():
    class SVGBatchWindowShellV3(vanilla.Window):
        nsWindowClass=SVGBatchCompactWindow
        @objc.python_method
        def open(self):
            if getattr(self,'_batch_open_hold',False):
                self.show();return
            super().open()
            self._batch_open_hold=True
        def windowWillClose_(self,notification):
            if getattr(self,'_batch_close_started',False) or self._window is None:return
            # Vanilla.open() retains the Python/NSObject wrapper; its close
            # delegate unconditionally autoreleases it. Eager child windows may
            # never have been opened. Balance that delegate release locally.
            if not getattr(self,'_batch_open_hold',False):
                self.retain();self._batch_open_hold=True
            self._batch_close_started=True
            return objc.super(SVGBatchWindowShellV3,self).windowWillClose_(notification)
        @objc.python_method
        def _breakCycles(self):
            # Vanilla's default recursive cleanup also iterates subviews/drawers.
            # Keep its callback-release semantics, scoped to our window subclass.
            self._bindings={};self._menuItemCallbackWrappers=None
            roots=[self._window.contentView()]+[d.contentView() for d in native_items(self._window.drawers())]
            for root in roots:
                for view in descendant_views(root):
                    if hasattr(view,'vanillaWrapper'):
                        wrapper=view.vanillaWrapper()
                        if wrapper is not None and hasattr(wrapper,'_breakCycles'):wrapper._breakCycles()
CompactWindow=SVGBatchWindowShellV3

if 'SVGBatchInteractionWindowV12' not in globals():
    class SVGBatchInteractionWindowV12(SVGBatchCompactWindow):
        def cancelOperation_(self,sender):
            owner=getattr(self,'batch_owner',None)
            if owner and owner.escape(self):return
            return objc.super(SVGBatchInteractionWindowV12,self).cancelOperation_(sender)
        def keyDown_(self,event):
            owner=getattr(self,'batch_owner',None)
            if owner and owner.handle_display_key(self,event):return
            if event.keyCode()==53 and owner and owner.escape(self):return
            return objc.super(SVGBatchInteractionWindowV12,self).keyDown_(event)
        def performKeyEquivalent_(self,event):
            owner=getattr(self,'batch_owner',None)
            if owner and owner.handle_display_key(self,event):return True
            if event.keyCode()==53 and owner and owner.escape(self):return True
            return objc.super(SVGBatchInteractionWindowV12,self).performKeyEquivalent_(event)
CompactWindow.nsWindowClass=SVGBatchInteractionWindowV12


if 'SVGBatchCellActionTarget' not in globals():
    class SVGBatchCellActionTarget(NSObject):
        def invoke_(self,sender): self.callback(sender)


if 'SVGBatchReviewGridV14' not in globals():
    class SVGBatchReviewGridV14(NSView):
        def acceptsFirstResponder(self): return True
        def isFlipped(self): return True
        @objc.python_method
        def setup(self,owner,pool=False):
            self.owner=owner; self.pool=pool; self.cells=[]; self.origin=None; self.hover=None
            self.cols=6; self.unit=160; self.row_height=228; self.large=False
            self.registerForDraggedTypes_([NSFilenamesPboardType,'public.file-url'])
        @objc.python_method
        def layout_cells(self):
            width=max(160,float(self.superview().bounds().size.width) if self.superview() else 1020)
            self.cols=1 if self.large else max(1,int(width//(160*self.owner.display_size+6))); self.unit=width/self.cols
            self.row_height=330 if self.large else ((180 if self.pool else 228)-100+100*self.owner.display_size+6)
            self.card_height=314 if self.large else self.row_height-2*CARD_INSET
            viewport_height=float(self.superview().bounds().size.height) if self.superview() else 0
            frame_size=(width,max(viewport_height,120 if self.pool else 400,math.ceil(len(self.cells)/self.cols)*self.row_height))
            if (self.frame().size.width,self.frame().size.height)!=frame_size:self.setFrameSize_(frame_size)
        @objc.python_method
        def hit(self,p):
            if p.x<0 or p.y<0: return None
            col=int(p.x//self.unit); i=int(p.y//self.row_height)*self.cols+col
            inside=CARD_INSET<=p.x%self.unit<=self.unit-CARD_INSET and CARD_INSET<=p.y%self.row_height<=self.card_height+CARD_INSET
            return self.cells[i] if inside and col<self.cols and i<len(self.cells) else None
        def drawRect_(self,rect):
            self.layout_cells()
            NSColor.controlBackgroundColor().set();NSRectFill(rect)
            if not self.cells and not self.pool:
                text(M('没有匹配结果') if self.owner.w.search.get() or self.owner.w.filter.get()!=0 else M('导入字表，开始校对'),32,60,20,NSColor.secondaryLabelColor())
                text(M('请调整搜索或筛选条件。') if self.owner.w.search.get() or self.owner.w.filter.get()!=0 else M('可拖入 SVG、EPS、矢量PDF（按页加载）；松开后先预览对应。'),32,96,13,NSColor.secondaryLabelColor());return
            visible=self.visibleRect();first=max(0,int(visible.origin.y//self.row_height)*self.cols)
            last=min(len(self.cells),(int((visible.origin.y+visible.size.height)//self.row_height)+1)*self.cols)
            for i in range(first,last):
                cell=self.cells[i];x,y,width,_=card_rect(i,self.cols,self.unit,self.row_height,self.card_height)
                height=self.card_height
                if not intersects((x-2,y-2,width+4,height+4),(rect.origin.x,rect.origin.y,rect.size.width,rect.size.height)):continue
                selected=self.owner.gestures.selected(cell);eid=cell['entry']['id'] if cell['kind']=='target' else None
                candidate=eid in self.owner.drop_overlay
                aid=cell.get('asset') if self.pool else self.owner.drop_overlay.get(eid,self.owner.project.state['assignments'].get(eid))
                from .render_view import data as render_data
                rendered=render_data(self.owner,cell,aid)
                status=rendered['status']
                missing=not aid
                shape=NSBezierPath.bezierPathWithRoundedRect_xRadius_yRadius_(((x,y),(width,height)),8,8)
                NSColor.controlBackgroundColor().set();shape.fill()
                if missing:NSColor.labelColor().colorWithAlphaComponent_(.025).set();shape.fill()
                if candidate:
                    NSColor.controlAccentColor().colorWithAlphaComponent_(.06).set();shape.fill()
                    shape.setLineWidth_(1.4);shape.setLineDash_count_phase_([4.,3.],2,0.)
                    NSColor.controlAccentColor().set();shape.stroke()
                else:
                    NSColor.labelColor().colorWithAlphaComponent_(.12).set();shape.setLineWidth_(.6);shape.stroke()
                if selected or self.hover==cell or cell.get("position") in self.owner.gestures.highlight:
                    outline=NSBezierPath.bezierPathWithRoundedRect_xRadius_yRadius_(((x,y),(width,height)),8,8)
                    NSColor.controlAccentColor().set();outline.setLineWidth_(2.);outline.stroke()
                elif cell['kind']=='target' and self.owner.drop_range and self.owner.drop_range[0]<=cell['position']<=self.owner.drop_range[1] and not candidate:
                    NSColor.controlAccentColor().colorWithAlphaComponent_(.35).set();shape.stroke()
                if eid:
                    draw_target_header(cell['entry'],cell['position'],x,y,width,rendered['header'])
                else:text(M('素材'),x+12,y+10,12,NSColor.secondaryLabelColor())
                footer=y+height-26
                fitted_frame=None
                from .preview_reference import reference
                if eid:
                    try:
                        fitted_frame=rendered['frame']
                        if fitted_frame is None:raise ValueError(rendered['frame_error'])
                        fitted_frame=dict(fitted_frame)
                        fw=fitted_frame['width'];fh=fitted_frame['ascender']-fitted_frame['descender']
                        ph=225 if self.large else height-73
                        ff=min((width-28)/fw,ph/fh)
                        fx=x+(width-fw*ff)/2;fy=y+35+(ph-fh*ff)/2
                        fitted_frame.update(factor=ff,bx=fx,by=fy+fitted_frame['ascender']*ff)
                        NSColor.separatorColor().colorWithAlphaComponent_(.7).set()
                        frame=NSBezierPath.bezierPathWithRect_(((fx,fy),(fw*ff,fh*ff)));frame.setLineWidth_(.6);frame.stroke()
                        # Main cards omit decorative baseline; the frame/coordinates stay exact.
                    except ValueError as exc:
                        status=M('目标范围无效');fitted_frame=None
                if rendered.get('existing_path') is not None and fitted_frame:
                    old=rendered['existing_path'].copy();t=NSAffineTransform.transform()
                    t.setTransformStruct_((fitted_frame['factor'],0.,0.,-fitted_frame['factor'],fitted_frame['bx'],fitted_frame['by']));old.transformUsingAffineTransform_(t)
                    NSGraphicsContext.saveGraphicsState()
                    try:
                        NSBezierPath.bezierPathWithRect_(((x+10,y+35),(width-20,height-73))).addClip()
                        NSColor.secondaryLabelColor().colorWithAlphaComponent_(.55).set();old.fill()
                    finally:NSGraphicsContext.restoreGraphicsState()
                if aid:
                    asset=self.owner.project.state['assets'][aid]
                    # No per-cell native tooltip: addToolTipRect holds owner weakly.
                    # A temporary bridged string can die before AppKit's delayed
                    # display timer (the Oct 14 native host crashes). Full names
                    # remain available in details; do not register owners in draw.
                    try:
                        if rendered['error']:raise ValueError(rendered['error'])
                        path=rendered['path'].copy()
                        preview_height=225 if self.large else height-73
                        if fitted_frame:
                            factor=fitted_frame['factor'];bx=fitted_frame['bx'];by=fitted_frame['by']
                            if rendered.get('diagnostic_badge'):status=rendered['diagnostic_badge']
                        else:
                            span,bottom=rendered['fallback']
                            factor=220./span if self.large else min((width-28)/span,preview_height/span)
                            bx=x+(width-span*factor)/2;by=y+(265 if self.large else height-42)+bottom*factor
                        transform=NSAffineTransform.transform();transform.setTransformStruct_((factor,0.,0.,-factor,bx,by));path.transformUsingAffineTransform_(transform)
                        NSGraphicsContext.saveGraphicsState()
                        try:
                            NSBezierPath.bezierPathWithRect_(((x+10,y+35),(width-20,preview_height))).addClip()
                            NSColor.labelColor().set();path.fill()
                            # Reference lines remain in details, not main thumbnails.
                        finally:NSGraphicsContext.restoreGraphicsState()
                    except Exception as exc:
                        if rendered.get('pending'):status=''
                        else:self.owner.errors[aid]=ms(exc);status=M('读取失败')
                    if not candidate and not status:
                        material_label=(MP(M('第%d页 · %s'),(asset['pdf_page'],Path(asset['path']).name))) if asset.get('pdf_page') else asset['name']
                        text(fitted_text(material_label,width-24),x+12,footer,11,NSColor.secondaryLabelColor())
                if candidate:label=M('待采用');color=NSColor.controlAccentColor()
                else:
                    label=status_label(status) if status==M('读取失败') else rendered.get('diagnostic_badge') or status_label(status)
                    color=NSColor.secondaryLabelColor() if label in (M('缺稿'),M('空位')) else NSColor.systemRedColor() if label in (M('重复目标'),M('字符编码不一致'),M('格式错误'),M('读取失败')) else NSColor.systemOrangeColor()
                if label:
                    attrs={NSFontAttributeName:NSFont.systemFontOfSize_(11)}
                    chip_width=min(width-24,NSString.stringWithString_(R(label)).sizeWithAttributes_(attrs).width+12)
                    color.colorWithAlphaComponent_(.09).set()
                    NSBezierPath.bezierPathWithRoundedRect_xRadius_yRadius_(((x+10,footer-1),(chip_width,19)),4,4).fill()
                    text(label,x+16,footer+1,11,color)
        def draggingEntered_(self,sender): return self.draggingUpdated_(sender)
        def draggingUpdated_(self,sender):
            self.hover=self.hit(self.convertPoint_fromView_(sender.draggingLocation(),None));self.setNeedsDisplay_(True)
            self.owner.main.materials.show(False);self.owner.main.issues.show(False)
            self.owner.main.dragHint.show(True)
            self.owner.main.dragHint.set(MP(M('从第%d格开始，松开后先预览'),self.hover['position']) if self.hover and self.hover['kind']=='target' else M('拖到字格指定起点；空白处仅添加素材'))
            return NSDragOperationCopy
        def draggingExited_(self,sender):
            self.hover=None;self.setNeedsDisplay_(True);self.owner.refresh()

        def prepareForDragOperation_(self,sender): return True
        def performDragOperation_(self,sender):
            pb=sender.draggingPasteboard(); paths=pb.propertyListForType_(NSFilenamesPboardType)
            if not paths:
                paths=[ms(u.path()) for u in native_items(pb.readObjectsForClasses_options_([NSURL],{'NSPasteboardURLReadingFileURLsOnlyKey':True}))]
            cell=self.hit(self.convertPoint_fromView_(sender.draggingLocation(),None))
            self.hover=None
            if cell and cell['kind']=='target':self.owner.drop_files(native_items(paths),cell['position'])
            else:self.owner.add_files(native_items(paths))
            return True
        def mouseDown_(self,event):
            self.window().makeFirstResponder_(self)
            self.origin=self.hit(self.convertPoint_fromView_(event.locationInWindow(),None)); self.owner.select_cell(self.origin)
            if self.origin and event.clickCount()==2: self.owner.enlarge(self.origin)
        def mouseDragged_(self,event):
            self.hover=self.hit(self.convertPoint_fromView_(event.locationInWindow(),None)); self.setNeedsDisplay_(True); self.autoscroll_(event)
        def mouseUp_(self,event):
            source=self.origin; dest=self.hit(self.convertPoint_fromView_(event.locationInWindow(),None))
            other=self.owner.grid if self.pool else self.owner.pool_grid
            if dest is None and not other.isHiddenOrHasHiddenAncestor(): dest=other.hit(other.convertPoint_fromView_(event.locationInWindow(),None))
            toggle=self.owner.main.poolToggle.getNSButton()
            if NSPointInRect(toggle.convertPoint_fromView_(event.locationInWindow(),None),toggle.bounds()): dest={'kind':'pool'}
            self.origin=None; self.hover=None
            if source and dest and source!=dest: self.owner.drag(source,dest)
            self.setNeedsDisplay_(True)
        def rightMouseDown_(self,event):
            self.window().makeFirstResponder_(self)
            cell=self.hit(self.convertPoint_fromView_(event.locationInWindow(),None))
            if cell:self.owner.gestures.select(cell,preserve=self.owner.gestures.selected(cell))
            if cell: NSMenu.popUpContextMenu_withEvent_forView_(self.owner.cell_menu(cell),event,self)


InteractiveGrid=make_grid(SVGBatchReviewGridV14)


from .document_owner import DocumentOwner
from .settings_ui import SettingsUI
from .help_ui import HelpUI

class SVGBatchPreflightTickRC34(NSObject):
    def tick_(self,timer):
        if self.owner is not None:self.owner.preflight_tick(timer)
        else:timer.invalidate()

class Panel(HelpUI,SettingsUI,DocumentOwner,PDFMaterialUI,HostSourceUI,TargetEditingUI,SessionUI,DocumentUI,PanelActions):
    def __new__(cls,previous=None,isolated=False,auto_host=None,owner_font=None):
        from .panel_entry import document_panel
        owner=owner_font if owner_font is not None else getattr(Glyphs,'font',None)
        active=document_panel(owner) if not isolated and previous is None else None
        if live_panel(active):return active
        return super().__new__(cls)
    def __init__(self,previous=None,isolated=False,auto_host=None,owner_font=None):
        global _active_panel
        if getattr(self,'_initialized',False):raise_panel(self);return
        from .panel_entry import document_panel
        owner=owner_font if owner_font is not None else getattr(Glyphs,'font',None)
        if previous is None and not isolated:previous=document_panel(owner)
        self.owner_font=owner;self.owner_invalid=False;self.isolated=isolated
        if previous and previous.timer:raise ValueError(M('请等待当前导入结束，再更换界面'))
        if previous and not getattr(previous,'_closed',False) and getattr(previous,'drop_draft',None):raise ValueError(M('请先采用或取消当前排布预览，再更新界面'))
        from .storage import prepare
        prepare()
        self.detached_recoveries=list(getattr(previous,'detached_recoveries',[]))
        self._initialized=False;self._closed=False;self.archived_hosts=list(getattr(previous,'archived_hosts',[]));self.pending_host=None
        self.gestures=Gestures(self)
        try:
            import json
            prefs=json.loads((ROOT/"ui-preferences.json").read_text())
        except FileNotFoundError:prefs={}
        except (ValueError,TypeError):traceback.print_exc();prefs={}
        try:
            self.pool_fraction=float(getattr(previous,"pool_fraction",prefs.get("pool_fraction",.33)))
            if not math.isfinite(self.pool_fraction) or not 0<self.pool_fraction<1:raise ValueError(M('无效分隔位置'))
        except (ValueError,TypeError):traceback.print_exc();self.pool_fraction=.33
        try:self.display_size=max(.75,min(2.,float(getattr(previous,'display_size',prefs.get('display_size',1.)))))
        except (ValueError,TypeError):self.display_size=1.
        if not math.isfinite(self.display_size):self.display_size=1.
        try:self.table_text_size=max(12.,min(48.,float(getattr(previous,'table_text_size',prefs.get('table_text_size',16.)))))
        except (ValueError,TypeError):self.table_text_size=16.
        if not math.isfinite(self.table_text_size):self.table_text_size=16.
        self.editor_font_hints=copy.deepcopy(getattr(previous,'editor_font_hints',{}))
        self.editor_font_snapshot=copy.deepcopy(getattr(previous,'editor_font_snapshot',None))
        self.editor_font_issues=[]
        self._styling_source=False
        self.source_task=None;self.source_timer=None;self.source_tick=None;self.preview_lookup_enabled=True
        prune_sessions(native_items(Glyphs.fonts))
        self.project=previous.project if previous else Project()
        self.project.__class__=Project
        if previous and hasattr(previous,'gestures'):
            self.gestures.keys=set(previous.gestures.keys);self.gestures.anchor=previous.gestures.anchor
            self.gestures.events=list(getattr(previous.gestures,"events",[]))
        self.cache=previous.cache if previous else OrderedDict(); self.errors=previous.errors if previous else {}
        self.host=previous.host if previous else None; self.timer=None
        if self.host:
            self.host.__class__=HostSession
            if not hasattr(self.host,'retired'):self.host.retired=False
            if not hasattr(self.host,'started'):self.host.started=bool(self.host.backup)
        self.locked_font=previous.locked_font if previous else None; self.locked_master=previous.locked_master if previous else None
        self.project_path=previous.project_path if previous else None
        self.drop_draft=None; self.drop_overlay={}; self.drop_range=None
        self.selected=previous.selected if previous else None; self.pool_expanded=previous.pool_expanded if previous else bool(prefs.get("pool_expanded",False)); self.result_message=previous.result_message if previous else ''; self.dialogs=[]; self.menu_targets=[]
        self.main=CompactWindow((1080,800),M('字动力 · 矢量批量导入'),minSize=(940,680))
        self.main.getNSWindow().batch_owner=self
        self.w=ControlRouter(self.main)
        self.main.getNSWindow().contentView().setWantsLayer_(True)
        self.main.getNSWindow().contentView().layer().setBackgroundColor_(NSColor.controlBackgroundColor().CGColor())
        self.main.chrome=vanilla.Group((0,0,-0,-0))
        backdrop=SVGBatchPolishedChromeV2.alloc().initWithFrame_(((0,0),(1080,800)));backdrop.setAutoresizingMask_(18)
        self.main.chrome._nsObject.addSubview_(backdrop);self.backdrop=backdrop;backdrop.owner=self
        self.main.importTable=self.menu_button((24,23,150,32),M('导入字表'),[
            {'title':M('从当前 Glyphs 字体读取…'),'callback':self.read_current_glyphs}, {'title':M('粘贴文字…'),'callback':self.open_table}, {'title':M('选择字表文件…'),'callback':self.load_table_file}])
        self.main.addSVG=self.menu_button((185,23,140,32),M('添加矢量文件…'),[
            {'title':M('选择文件…（SVG、EPS、矢量PDF（按页加载））'),'callback':self.load_svg},{'title':M('选择文件夹…'),'callback':self.load_folder}])
        self.main.materials=vanilla.TextBox((26,69,750,22),'')
        self.main.sizeSlider=vanilla.Slider((-204,88,180,30),minValue=.75,maxValue=2.,value=self.display_size,continuous=True,callback=self.slider_display)
        self.main.sizeSlider.getNSSlider().setAccessibilityLabel_(R(M('缩略图大小')))
        self.main.issues=vanilla.TextBox((350,131,100,24),'')
        self.main.files=MenuTitle((24,6,62,26),M('文件'),[
            {'title':M('打开工程…'),'callback':self.open},{'title':M('保存工程…'),'callback':self.save},'----',
            {'title':M('批量对应…'),'callback':self.open_rules},{'title':M('重新关联当前字体…'),'callback':self.open_target}])
        self.main.helpMenu=MenuTitle((168,6,62,26),M('帮助'),[
            {'title':M('关于插件…'),'callback':self.open_about},{'title':M('检查更新…'),'callback':self.open_update},'----',
            {'title':M('界面语言…'),'callback':self.open_language},'----',
            {'title':M('授权与激活…'),'callback':self.open_activation},
            {'title':M('运行环境…'),'callback':lambda s:__import__('svg_batch.runtime_compat',fromlist=['show']).show(self)}])
        self.main.editMenu=MenuTitle((-94,28,70,24),M('编辑'),[
            {'title':M('撤销校对  ⌘Z'),'callback':lambda s:self.history(False)},
            {'title':M('重做校对  ⇧⌘Z'),'callback':lambda s:self.history(True)}])
        self.menu_titles=MenuTitles(self,(self.main.files,self.main.editMenu,self.main.helpMenu))
        self.main.search=SearchControl((24,109,330,25),'',placeholder=M('搜索字符、U码或文件名'),callback=self.search_changed)
        self.main.filter=vanilla.PopUpButton((366,109,150,25),[M('全部'),M('缺字稿 / 空位'),M('重复'),M('读取失败'),M('已有内容'),M('待分配')],callback=self.refresh)
        self.main.duplicates=vanilla.Button((529,109,104,25),M('处理重复…'),callback=self.open_duplicates)
        self.main.organize=vanilla.Button((656,109,104,25),M('字表整理…'),callback=self.open_table)
        self.main.ruleSummary=vanilla.TextBox((26,146,550,22),'')
        self.main.dragHint=vanilla.TextBox((630,146,426,22),M('拖动 素材 交换，字符位置不变'),alignment='right')
        self.grid=InteractiveGrid.alloc().initWithFrame_(((0,0),(1020,420))); self.grid.setup(self)
        self.main.scroll=vanilla.ScrollView((24,170,-24,-168),self.grid,hasHorizontalScroller=False,autohidesScrollers=True)
        self.main.splitHandle=vanilla.Group((24,400,-24,8))
        self.splitHandle=SVGBatchSplitHandleV10.alloc().initWithFrame_(((0,0),(1000,8)));self.splitHandle.setAutoresizingMask_(2);self.splitHandle.owner=self
        self.main.splitHandle._nsObject.addSubview_(self.splitHandle)
        class PoolButton(vanilla.Button):nsButtonClass=SVGBatchPoolDropHeaderV2
        self.main.poolToggle=PoolButton((24,-154,-24,24),'',callback=self.toggle_pool)
        self.main.poolToggle.getNSButton().owner=self
        self.main.poolToggle.getNSButton().registerForDraggedTypes_(['local.svg-batch.assignment-drag'])
        self.pool_grid=InteractiveGrid.alloc().initWithFrame_(((0,0),(1020,120))); self.pool_grid.setup(self,True)
        self.main.poolScroll=vanilla.ScrollView((24,-250,-24,120),self.pool_grid,hasHorizontalScroller=False,autohidesScrollers=True)
        self.main.target=vanilla.TextBox((26,-108,700,25),'')
        # Relinking is an explicit File menu action, never a persistent target switch.
        self.main.settingSummary=vanilla.TextBox((26,-79,550,23),'')
        self.main.settings=vanilla.Button((364,20,112,30),M('导入设置…'),callback=self.open_settings)
        self.main.importGlyphs=vanilla.Button((-224,-109,200,52),M('导入 Glyphs'),callback=self.import_batch)
        self.main.setDefaultButton(self.main.importGlyphs)
        self.main.status=vanilla.TextBox((26,-39,830,24),'')
        self.main.stop=vanilla.Button((-154,-40,130,25),M('停止导入'),callback=self.cancel)
        self.main.restore=vanilla.Button((-194,-40,170,25),M('恢复本次导入'),callback=self.recover)
        self.main.selectionMenu=self.menu_button((-185,142,160,26),M('所选字格'),[])
        self.w.controls.update(search=self.main.search,filter=self.main.filter,target=self.main.target,status=self.main.status)
        self.build_table_dialog(); self.build_rules_dialog(); self.build_settings_dialog(); self.build_target_dialog()
        if previous:
            for name in ('source','readmode','whitespace','encoding','range','position','value','binding','dup','search','filter','dragmode'):
                getattr(self.w,name).set(getattr(previous.w,name).get())
            for name in ('source_path','loaded_source_text','document_source'):
                if hasattr(previous,name): setattr(self,name,getattr(previous,name))
            if 'recordcolumns' in previous.w.controls: self.w.recordcolumns.set(previous.w.recordcolumns.get())
            if previous.w.getNSWindow() is not None:previous.w.close()
            self.restore_bound_target()
        elif owner is not None and owner.selectedFontMaster:
            self.use_target(owner,owner.selectedFontMaster.id)
        self.sync_settings(); self.saved_state=copy.deepcopy(getattr(previous,'saved_state',self.project.state));self.main.bind('should close',self.request_close);self.main.bind('close',self.closed);self.main.bind('resize',self.layout);self.main.bind('became key',self.main_became_key);self.style_controls(self.main); self.refresh(); self.main.open()
        from .license_watch import LicenseMonitor
        self.license_monitor=LicenseMonitor(self);self.license_monitor.start(SVGBatchTick);self.refresh()
        self._initialized=True
        if not isolated:
            _active_panel=self
            from .panel_entry import register_panel
            register_panel(self)
        self.start_document_observer()
        self.update_document_context()
        # New sessions stay empty. Host targets are read only through the explicit menu.

    def style_controls(self,w):
        for value in vars(w).values():
            native=getattr(value,'_nsObject',None)
            if native is not None and hasattr(native,'setFont_') and value is not self.w.controls.get('source'):native.setFont_(NSFont.systemFontOfSize_(13))
        if w is getattr(self,'table',None):
            w.textSmall.getNSTextField().setFont_(NSFont.systemFontOfSize_(11))
            w.textLarge.getNSTextField().setFont_(NSFont.systemFontOfSize_(19))
            self.apply_table_text_size()
            self.style_target_editor()
        if w is self.main:
            for name in ('files','editMenu','helpMenu'):
                native=getattr(w,name).getNSButton();native.setBordered_(False);native.setFont_(NSFont.systemFontOfSize_(12))
            for name in ('importTable','addSVG','filter','selectionMenu'):
                native=getattr(w,name).getNSPopUpButton();native.setBezelStyle_(1);native.setControlSize_(0);native.setFont_(NSFont.systemFontOfSize_(13))
            for name in ('organize','duplicates','settings'):
                native=getattr(w,name).getNSButton();native.setBezelStyle_(1);native.setControlSize_(0);native.setFont_(NSFont.systemFontOfSize_(13))
            w.settings.frameAdjustments=w.addSVG.frameAdjustments
            w.search.getNSTextField().setBezelStyle_(1);w.search.getNSTextField().setControlSize_(0)
            w.importGlyphs.frameAdjustments=None;w.poolToggle.frameAdjustments=None
            primary=w.importGlyphs.getNSButton();primary.setBordered_(False);primary.setWantsLayer_(True);primary.layer().setCornerRadius_(7)
            primary.setAttributedTitle_(NSAttributedString.alloc().initWithString_attributes_(R(M('导入 Glyphs')),{NSFontAttributeName:NSFont.systemFontOfSize_(13),NSForegroundColorAttributeName:NSColor.whiteColor()}))
            w.poolToggle.getNSButton().setBordered_(False);w.poolToggle.getNSButton().setAlignment_(0);w.poolToggle.getNSButton().setFont_(NSFont.systemFontOfSize_(12));w.poolToggle.getNSButton().setToolTip_(R(M('拖到这里可移回待分配区')))
            for name in ('materials','settingSummary','status'):
                native=getattr(w,name).getNSTextField();native.setFont_(NSFont.systemFontOfSize_(12));native.setTextColor_(NSColor.secondaryLabelColor())
            for name in ('target','settingSummary','status','materials'):
                native=getattr(w,name).getNSTextField();native.cell().setLineBreakMode_(5);native.cell().setUsesSingleLineMode_(True)
        from .localized_ui import fit_labels
        fit_labels(w)

    def layout(self,s=None):
        if not hasattr(self,'settings_grid'):return
        width=self.main.getNSWindow().contentView().bounds().size.width
        self.main.importTable.setPosSize((24,6,142,30));self.main.addSVG.setPosSize((178,6,174,30))
        self.main.settings.setPosSize((364,6,112,30));self.main.organize.setPosSize((488,6,116,30))
        self.menu_titles.layout(width)
        search_width=max(140,min(520,width-380))
        self.main.search.setPosSize((24,54,search_width,30));self.main.filter.setPosSize((36+search_width,54,142,30))
        self.main.sizeSlider.setPosSize((-204,54,180,30))
        self.main.materials.setPosSize((24,97,width-440,24))
        self.main.dragHint.setPosSize((24,97,width-230,24))
        self.main.issues.setPosSize((36+min(480,measure_text(self.main.materials.get(),12)),97,120,24))
        self.main.duplicates.setPosSize((-270,97,95,25));self.main.selectionMenu.setPosSize((-164,94,140,25))
        self.main.ruleSummary.show(False);self.main.dragHint.show(False)
        status_band=bool(self.main.status.get() or self.timer or (self.host and any(not r.get('recovered') for r in self.host.records)))
        self.footer_height=124 if status_band else 96
        height=self.main.getNSWindow().contentView().bounds().size.height
        total=height-self.footer_height-18-131
        self.split_available=max(260,total-40)
        self.pool_pixels=max(100,min(self.split_available-160,self.split_available*self.pool_fraction))
        target_height=total-40-self.pool_pixels if self.pool_expanded else total-32
        divider_y=131+target_height
        self.main.scroll.setPosSize((24,131,-24,target_height))
        self.main.splitHandle.setPosSize((24,divider_y,-24,8));self.main.splitHandle.show(self.pool_expanded)
        self.main.poolToggle.setPosSize((24,divider_y+(8 if self.pool_expanded else 2),-24,28))
        self.main.poolScroll.setPosSize((24,divider_y+40,-24,self.pool_pixels));self.main.poolScroll.show(self.pool_expanded)
        attrs={NSFontAttributeName:NSFont.systemFontOfSize_(13)}
        target_width=min(max(130,measure_text(self.main.target.get(),13)+8),width-460)
        self.main.target.setPosSize((24,-self.footer_height+14,target_width,25));self.main.target.getNSTextField().setToolTip_(R(self.main.target.get()))
        settings_width=min(max(260,measure_text(self.main.settingSummary.get(),12)+10),width-430)
        self.main.settingSummary.setPosSize((24,-self.footer_height+45,settings_width,25))
        self.main.importGlyphs.setPosSize((-192,-self.footer_height+25,168,36))
        self.main.status.setPosSize((24,-35,width-220,22));self.main.stop.setPosSize((-164,-39,140,28));self.main.restore.setPosSize((-164,-39,140,28))
        self.backdrop.setNeedsDisplay_(True)
        for grid in (self.grid,self.pool_grid):grid.layout_cells();grid.setNeedsDisplay_(True)
    def menu_button(self,pos,title,items):
        button=vanilla.ActionButton(pos,items); item=button.getNSPopUpButton().itemAtIndex_(0)
        item.setImage_(None); item.setTitle_(R(title)); return button
    def add_control(self,window,name,control):
        setattr(window,name,control); self.w.controls[name]=control
        if not hasattr(window,'_batch_control_names'):window._batch_control_names=[]
        window._batch_control_names.append(name)
    def show_dialog(self,w):
        if w is None:self.ensure_dialog('table',self.build_table_dialog);w=self.table
        if not self.dialog_alive(w):return
        self.style_controls(w)
        if self.timer: alert(M('请先停止导入或等待导入完成。')); return
        if not w._batch_opened: w.open(); w._batch_opened=True
        else: w.show()
    def save_ui_preferences(self):
        import json
        path=ROOT/"ui-preferences.json"
        try:
            try:prefs=json.loads(path.read_text())
            except FileNotFoundError:prefs={}
            if not isinstance(prefs,dict):raise ValueError(M('界面偏好文件无效；未覆盖原文件'))
            prefs.update(pool_fraction=self.pool_fraction,pool_expanded=self.pool_expanded,display_size=self.display_size,table_text_size=self.table_text_size)
            atomic_json(path,prefs);self._preference_error_reported=False
        except (ValueError,OSError,TypeError) as exc:
            self.preference_error=ms(exc)
            if not getattr(self,'_preference_error_reported',False):traceback.print_exc();self._preference_error_reported=True
            # Keep the invalid/unwritable file for diagnosis, and still release
            # this panel's observers/timers in the normal close lifecycle.
            return False
    def build_table_dialog(self):
        w=self.table=self.dialog((780,640),M('字表整理'))
        w.help=vanilla.TextBox((20,18,730,35),M('粘贴或读取文字，排除标题与说明，再确认目标顺序。支持TXT、CSV、XLSX、DOCX与可提取文本的PDF；不识别图片文字。'))
        w.read=vanilla.Button((20,60,150,25),M('选择字表文件…'),callback=self.load_table_file)
        w.textSmall=vanilla.TextBox((508,65,18,20),'A')
        w.textSize=vanilla.Slider((532,60,190,25),minValue=12,maxValue=48,value=self.table_text_size,continuous=True,callback=self.table_text_slider)
        w.textLarge=vanilla.TextBox((735,61,25,25),'A')
        self.add_control(w,'source',SourceTextEditor((20,100,740,220),'',callback=self.source_display_changed))
        source_view=self.w.source.getNSTextView();source_view.owner=self;source_view.setRichText_(False);source_view.setImportsGraphics_(False);source_view.setFont_(NSFont.systemFontOfSize_(self.table_text_size))
        source_view.setAutomaticQuoteSubstitutionEnabled_(False);source_view.setAutomaticDashSubstitutionEnabled_(False);source_view.setAutomaticTextReplacementEnabled_(False)
        self.add_control(w,'readmode',vanilla.PopUpButton((20,336,170,25),[M('连续文字'),M('每行一个位置'),M('字符＋编码双列'),M('自动识别'),M('编码（含纯十六进制）'),M('交替行（编码在上）'),M('交替行（字符在上）')]))
        self.w.readmode.set(3)
        self.add_control(w,'whitespace',vanilla.CheckBox((212,336,170,25),M('忽略行内空白'),value=True))
        w.rangeLabel=vanilla.TextBox((405,339,75,20),M('保留行数'))
        self.add_control(w,'range',vanilla.EditText((482,336,115,25),'1-',placeholder='1-20'))
        self.add_control(w,'encoding',vanilla.PopUpButton((615,336,145,25),[M('默认（UTF-8）'),'Unicode（UTF-16）',M('简体中文'),M('繁体中文')]))
        self.add_control(w,'recordcolumns',vanilla.PopUpButton((20,369,295,25),[M('双列顺序自动识别'),M('字符第1列，编码第2列'),M('编码第1列，字符第2列')]))
        w.explain=vanilla.TextBox((330,371,430,28),M('纯十六进制请选择编码模式或指定编码列。'))
        self.add_control(w,'mode',vanilla.PopUpButton((20,401,190,25),[M('素材校对'),M('字表整理')]))
        self.w.mode.set(1); self.w.mode.show(False)
        w.positionLabel=vanilla.TextBox((20,410,70,22),M('位置'))
        self.add_control(w,'position',vanilla.EditText((80,405,75,25),'1'))
        self.add_control(w,'value',TargetEditText((170,405,210,25),'',placeholder=M('目标字符；留空表示占位'),callback=self.style_target_editor))
        w.edit=vanilla.Button((393,405,95,25),M('改字 / 留空'),callback=self.edit_target)
        w.add=vanilla.Button((500,405,85,25),M('插入位置'),callback=self.add_target)
        w.deleteItem=vanilla.Button((597,405,85,25),M('删除位置'),callback=self.delete_target)
        w.up=vanilla.Button((20,450,100,25),M('上移'),callback=lambda s:self.reorder(-1))
        w.down=vanilla.Button((132,450,100,25),M('下移'),callback=lambda s:self.reorder(1))
        self.add_control(w,'binding',vanilla.PopUpButton((248,450,300,25),[M('保留目标与素材绑定'),M('重新按位置对应')]))
        self.add_control(w,'dup',vanilla.PopUpButton((20,493,330,25),[M('标记重复，保留多个版本'),M('重复位置留空'),M('保留首次，删除后续重复')]))
        w.dedupe=vanilla.Button((364,493,130,25),M('处理重复'),callback=self.dedupe)
        w.note=vanilla.TextBox((20,537,600,40),M('删除或留空后，对应素材回到待分配区；源文件保持不变。'))
        w.codeDetails=vanilla.Button((640,535,120,25),M('核对编码…'),callback=self.show_editor_codes);w.codeDetails.show(False)
        w.done=vanilla.Button((580,586,180,30),M('完成，返回校对'),callback=lambda s:self.finish_dialog(w))
        w.adopt=vanilla.Button((20,586,230,30),M('预览并采用文字'),callback=self.extract)
    def open_table(self,s=None):
        self.ensure_dialog('table',self.build_table_dialog);self.show_dialog(self.table)
    def load_txt(self,s):return self.load_table_file(s)
    def open_duplicates(self,s=None): self.open_table()
    def build_rules_dialog(self):
        w=self.rules_window=self.dialog((600,360),M('批量对应'))
        w.help=vanilla.TextBox((20,20,560,48),M('编号对应保留缺号；顺序对应按文件顺序；字符／Unicode文件名直接匹配目标，不受文件顺序或拖入起点影响。'))
        self.add_control(w,'mapmode',vanilla.PopUpButton((20,85,560,25),[M('按文件编号（保留缺号）'),M('按自然文件顺序'),M('按字符／Unicode文件名匹配（忽略顺序与起点）')],callback=self.layout_rules))
        for x,name,label in [(20,'group',M('取第几组数字')),(215,'firstnumber',M('起始文件编号')),(410,'firstposition',M('对应字表位置'))]:
            setattr(w,name+'Label',vanilla.TextBox((x,139,170,22),label))
            self.add_control(w,name,vanilla.EditText((x,168,170,25),'1'))
        w.note=vanilla.TextBox((20,216,560,55),M('字符命名示例：一.svg、丁.svg、U+4E00.svg、uni4E00.svg、0x4E00.svg。\n字符模式保留现有分配；未匹配、重复目标及冲突逐项提示。'))
        w.done=vanilla.Button((20,299,180,30),M('预览并采用规则'),callback=self.map)
        w.back=vanilla.Button((420,299,160,30),M('返回校对'),callback=lambda s:self.finish_dialog(w))
        # UI-only drag selector remains separate from saved assignment state.
        self.w.controls['dragmode']=DetachedControl(0,[M('交换'),M('插入')])
        w.mapmode.set(['number','order','unicode'].index(self.project.state['settings'].get('mapping_mode','number')))
        for name,key in (('group','number_group'),('firstnumber','first_number'),('firstposition','first_position')):getattr(w,name).set(ms(self.project.state['settings'][key]))
    def layout_rules(self,s=None):
        w=self.rules_window;number=w.mapmode.get()==0
        for name in ('group','firstnumber','firstposition'):
            getattr(w,name).show(number);getattr(w,name+'Label').show(number)
        y=216 if number else 134
        w.note.setPosSize((20,y,560,55));w.done.setPosSize((20,y+83,180,30));w.back.setPosSize((420,y+83,160,30))
        left,top,width,height=w.getPosSize()
        if height!=y+144:w.setPosSize((left,top,600,y+144))
    def open_rules(self,s=None):
        self.ensure_dialog('rules_window',self.build_rules_dialog);self.layout_rules();self.show_dialog(self.rules_window)
    def set_drag_mode(self,index):
        self.w.dragmode.set(index); self.refresh()
    def build_target_dialog(self):
        w=self.target_window=self.dialog((580,280),M('选择导入目标'))
        w.help=vanilla.TextBox((20,20,540,43),M('选择已打开的字体和母版。预览不会修改字体，确认导入时会再次检查目标。'))
        w.font=vanilla.PopUpButton((20,88,540,25),[],callback=self.target_font_changed)
        w.master=vanilla.PopUpButton((20,130,540,25),[])
        w.note=vanilla.TextBox((20,171,540,34),M('若字体不是当前文档，请先切换到它，再进行导入。'))
        w.apply=vanilla.Button((360,224,200,30),M('使用此目标'),callback=self.apply_target)
    def open_target(self,s=None):
        self.ensure_dialog('target_window',self.build_target_dialog)
        font=getattr(Glyphs,'font',None)
        if font is None:raise ValueError(M('请先打开要关联的字体文档'))
        self.check_owner(allow_detached=True)
        if self.owner_font is not None and not self.owner_invalid:
            from .host_targets import same_object
            if not same_object(font,self.owner_font):raise ValueError(M('请切换到此面板所属字体；不同文档请从编辑菜单打开各自面板'))
        self.target_fonts=[font]
        self.target_window.font.setItems([f.familyName for f in self.target_fonts] or [M('请先在Glyphs打开字体')])
        if self.locked_font in self.target_fonts: self.target_window.font.set(self.target_fonts.index(self.locked_font))
        self.target_font_changed(None); self.show_dialog(self.target_window)
    def target_font_changed(self,s):
        fonts=getattr(self,'target_fonts',[])
        if not fonts: self.target_window.master.setItems([M('无可选母版')]); return
        f=fonts[self.target_window.font.get()]; self.target_masters=native_items(f.masters)
        self.target_window.master.setItems([m.name for m in self.target_masters])
        if f==self.locked_font:
            hits=[i for i,m in enumerate(self.target_masters) if m.id==self.locked_master]
            if hits: self.target_window.master.set(hits[0])
    def use_target(self,font,master_id):
        master=next(m for m in native_items(font.masters) if m.id==master_id)
        self.locked_font=font; self.locked_master=master_id
        self.project.edit(lambda:self.project.state.update(target=dict(font_path=ms(font.filepath),family=font.familyName,master_id=master.id,master_name=master.name)))
    def apply_target(self,s):
        def action():
            if not self.target_fonts: raise ValueError(M('请先在Glyphs打开目标字体'))
            self.reassociate(self.target_fonts[self.target_window.font.get()],self.target_masters[self.target_window.master.get()].id)
            self.finish_dialog(self.target_window)
        self.guard(action)
    def lock(self,s=None): self.open_target(s)

    def handle_display_key(self,window,event):
        detail=getattr(self,'dialog_registry',{}).get(M('字格详情'))
        if detail is not None and window==detail.getNSWindow() and (window.firstResponder() is detail.detail_grid or (hasattr(detail,'zoomSlider') and window.firstResponder()==detail.zoomSlider.getNSSlider())):
            char=ms(event.charactersIgnoringModifiers() or '')
            if event.modifierFlags() & NSCommandKeyMask and char in ('+','=','-','0'):
                detail.detail_grid.change_zoom(0 if char=='0' else -1 if char=='-' else 1);return True
        table=getattr(self,'table',None)
        if table is not None and window==table.getNSWindow():
            source=self.w.source.getNSTextView()
            char=ms(event.charactersIgnoringModifiers() or '')
            if window.firstResponder()==source and event.modifierFlags() & NSCommandKeyMask and char in ('+','=','-','0'):
                if source.hasMarkedText():return False
                self.change_table_text_size(0 if char=='0' else -1 if char=='-' else 1)
                return True
        # Only the main panel and its two grids; other text editors retain normal keys.
        if window!=self.main.getNSWindow():return False
        focus=window.firstResponder()
        if isinstance(focus,NSTextView):return False
        if focus not in (self.grid,self.pool_grid):return False
        flags=event.modifierFlags();char=ms(event.charactersIgnoringModifiers() or '')
        if flags & NSCommandKeyMask and char.lower()=='a':
            self.gestures.select_all(focus);return True
        if flags & NSCommandKeyMask and char in ('+','=','-','0'):
            self.change_display(0 if char=='0' else -1 if char=='-' else 1);return True
        if not flags & NSCommandKeyMask and event.keyCode() in (51,117):
            if event.isARepeat():
                self.delete_repeat_count=getattr(self,'delete_repeat_count',0)+1;return True
            self.remove_selection(region='pool' if focus is self.pool_grid else 'target');return True
        return False
    def table_text_slider(self,sender):
        if getattr(self,'editor_resize_queue',None) is None:self.editor_resize_queue=ResizeQueue(self)
        self.editor_resize_queue.request(round(max(12.,min(48.,float(sender.get()))),1))
    def change_table_text_size(self,direction=0,value=None):
        cancel_resize(self)
        self.table_text_size=round(max(12.,min(48.,float(value) if value is not None else 16. if direction==0 else self.table_text_size+2*direction)),1)
        self.apply_table_text_size(resize_only=True)
        self.save_ui_preferences()
    def apply_table_text_size(self,resize_only=False):
        table=getattr(self,'table',None)
        if table is None:return
        view=self.w.source.getNSTextView()
        selection=view.selectedRange()
        clip=view.enclosingScrollView().contentView()
        origin=clip.bounds().origin
        old_size=float(view.font().pointSize()) if view.font() else self.table_text_size
        manager=view.layoutManager();container=view.textContainer()
        manager.ensureLayoutForTextContainer_(container)
        anchor=None;offset=0.
        if manager.numberOfGlyphs():
            text_origin=view.textContainerOrigin()
            glyph=min(manager.numberOfGlyphs()-1,manager.glyphIndexForPoint_inTextContainer_((max(0.,origin.x-text_origin.x),max(0.,origin.y-text_origin.y)),container))
            anchor=manager.characterIndexForGlyphAtIndex_(glyph)
            rect=manager.boundingRectForGlyphRange_inTextContainer_((glyph,1),container)
            offset=origin.y-text_origin.y-rect.origin.y
        font=NSFont.systemFontOfSize_(self.table_text_size)
        self._styling_source=True
        try:
            plan=getattr(self,'editor_font_runs',None)
            if resize_only and plan is not None and plan.valid(view,self.editor_font_snapshot,self.editor_font_hints):
                self.editor_font_issues=plan.apply(view,self.table_text_size)
            else:
                restore_snapshot(view,self.editor_font_snapshot)
                self.editor_font_issues=apply_fonts(view,self.table_text_size,self.editor_font_hints)
                self.editor_font_snapshot=snapshot_fonts(view,self.editor_font_hints)
                self.editor_font_runs=FontRuns(view,self.editor_font_snapshot,self.editor_font_hints,self.editor_font_issues)
        finally:self._styling_source=False
        typing=dict(view.typingAttributes());typing[NSFontAttributeName]=font
        view.setTypingAttributes_(typing)
        view.setSelectedRange_(selection)
        # Layout-only font change: no string replacement, parsing or undo edits.
        manager.ensureLayoutForTextContainer_(container)
        next_y=origin.y*self.table_text_size/max(1.,old_size)
        if anchor is not None and manager.numberOfGlyphs():
            glyph=manager.glyphIndexForCharacterAtIndex_(anchor)
            rect=manager.boundingRectForGlyphRange_inTextContainer_((glyph,1),container)
            next_y=view.textContainerOrigin().y+rect.origin.y+offset*self.table_text_size/max(1.,old_size)
        clip.scrollToPoint_((origin.x,max(0.,next_y)))
        view.enclosingScrollView().reflectScrolledClipView_(clip)
        table.textSize.set(self.table_text_size)
        issues=self.editor_font_issues
        if issues:
            pua=sum(i['private'] for i in issues);missing=sum(not i['covered'] for i in issues)
            table.note.set((MP(M('%d 个私用区字符依赖源字体；编码未转换为标准汉字。'),pua) if pua else '')+(MP(M('%d 项显示字体未确认，请核对Unicode。'),missing) if missing else ''))
        else:table.note.set(M('删除或留空后，对应素材回到待分配区；源文件保持不变。'))
        table.codeDetails.show(bool(issues))
    def source_display_changed(self,sender):
        if not self._styling_source and not self.w.source.getNSTextView().hasMarkedText():self.apply_table_text_size()
    def show_editor_codes(self,sender=None):
        title=M('文字编码核对')
        if self.raise_dialog(title):return
        window=self.dialog((760,500),title,parent=self.table)
        lines=[M('以下为真实Unicode编码；显示字体不改变编码，不根据外观猜字。'),'']
        for item in self.editor_font_issues:
            lines.append(MP(M('%s  UTF-16位置%d  %s%s'),(item['codes'],item['range'][0]+1,item['font'],M('（私用区）') if item['private'] else '')))
        window.codes=vanilla.TextEditor((20,20,720,420),MJ('\n',lines),readOnly=True)
        window.done=vanilla.Button((580,455,160,25),M('返回整理'),callback=lambda s:self.close_dialog(window))
        self.show_dialog(window)
    def remove_selection(self,s=None,region=None,empty_only=False):
        if self.timer or self.source_task or self.gestures.active or self.gestures.pending or self.drop_draft:return
        focus=self.main.getNSWindow().firstResponder()
        if region is None:
            if focus not in (self.grid,self.pool_grid):return
            region='pool' if focus is self.pool_grid else 'target'
        sources=[c for c in self.gestures.sources() if c['kind']==region]
        if not sources:return
        def action():
            if region=='target':
                draft=target_delete_plan(self.project,sources,empty_only)
                x,y=len(draft['assigned']),len(draft['empty'])
                adopt_target_delete(self.project,draft)
                if y:
                    es=self.project.state['entries'];live={e['id'] for e in es}
                    self.gestures.keys.intersection_update(('target',eid) for eid in live)
                    current_id=self.selected['entry']['id'] if self.selected and self.selected['kind']=='target' else None
                    selected_entry=next((e for e in es if e['id']==current_id and ('target',e['id']) in self.gestures.keys),None)
                    if selected_entry is None:selected_entry=next((e for e in es if ('target',e['id']) in self.gestures.keys),None)
                    old_position=self.selected.get('position',1) if self.selected else 1
                    self.selected=dict(kind='target',entry=selected_entry,position=es.index(selected_entry)+1) if selected_entry else None
                    index=es.index(selected_entry) if selected_entry else min(max(0,old_position-1),max(0,len(es)-1))
                    self.w.position.set(ms(index+1));self.w.value.set(es[index]['value'] if es else '')
                    if self.gestures.anchor not in self.gestures.keys:self.gestures.anchor=selection_key(self.selected) if self.selected else None
                self.gestures.record('delete_targets',dict(unassigned=x,deleted_empty=y))
            else:
                remove_selected(self.project,sources)
                self.gestures.record('delete_selection',dict(region=region,count=len(sources)))
        self.guard(action)
    def delete_empty_targets(self,s=None):
        self.remove_selection(s,region='target',empty_only=True)
    def handle_display_wheel(self,grid,event):
        # Scoped to the two main document views; never monitor global events.
        if not event.modifierFlags() & NSCommandKeyMask:return False
        if grid not in (self.grid,self.pool_grid) or grid.window()!=self.main.getNSWindow():return False
        if isinstance(grid.window().firstResponder(),NSTextView):return False
        if self.gestures.active or self.gestures.pending or self.gestures.rubber or self.drop_draft:return True
        from .view_zoom import wheel_step
        delta=float(event.scrollingDeltaY())
        value,self._wheel_zoom=wheel_step(self.display_size,delta,bool(event.hasPreciseScrollingDeltas()),float(event.timestamp()),getattr(self,'_wheel_zoom',None))
        if value!=self.display_size:
            point=grid.convertPoint_fromView_(event.locationInWindow(),None)
            self.change_display(0,value=value,mouse_anchor=(grid,point))
        return True
    def change_display(self,direction,value=None,mouse_anchor=None):
        if self.gestures.active or self.gestures.pending or self.drop_draft:return
        anchors=[]
        for grid in (self.grid,self.pool_grid):
            y=grid.visibleRect().origin.y;index=min(max(0,int(y//grid.row_height)*grid.cols),max(0,len(grid.cells)-1))
            anchors.append((grid,index,y%grid.row_height/grid.row_height))
        pointer=None
        if mouse_anchor:
            grid,point=mouse_anchor
            cell=grid.hit(point)
            if cell:
                i=grid.cells.index(cell)
                pointer=(grid,selection_key(cell),(point.y-i//grid.cols*grid.row_height)/grid.row_height,point.y-grid.visibleRect().origin.y)
        self.display_size=round(max(.75,min(2.,value if value is not None else 1. if direction==0 else self.display_size+direction*.125)),3)
        self.main.sizeSlider.set(self.display_size)
        self.layout()
        for grid,index,fraction in anchors:
            y=(index//grid.cols+fraction)*grid.row_height
            grid.scrollPoint_((0,max(0,min(y,grid.bounds().size.height-grid.visibleRect().size.height))))
        if pointer:
            grid,k,fraction,screen_y=pointer
            index=next((i for i,c in enumerate(grid.cells) if selection_key(c)==k),None)
            if index is not None:
                y=(index//grid.cols+fraction)*grid.row_height-screen_y
                grid.scrollPoint_((0,max(0,min(y,grid.bounds().size.height-grid.visibleRect().size.height))))
        self.save_ui_preferences()
        self.gestures.record("display_size",dict(size=self.display_size))
    def menu_text_focus(self):
        focus=self.main.getNSWindow().firstResponder()
        return focus if isinstance(focus,NSTextView) else None
    def select_all_menu(self,s=None):
        focus=self.menu_text_focus()
        if focus is not None:focus.selectAll_(None);return
        view=self.main.getNSWindow().firstResponder()
        if view not in (self.grid,self.pool_grid):
            view=self.pool_grid if self.selected and self.selected['kind']=='pool' else self.grid
        self.main.getNSWindow().makeFirstResponder_(view);self.gestures.select_all(view)
    def menu_history(self,redo):
        focus=self.menu_text_focus()
        if focus is not None:
            if focus.isEditable():
                manager=focus.undoManager()
                if manager is not None:
                    if redo and manager.canRedo():manager.redo()
                    elif not redo and manager.canUndo():manager.undo()
            return
        self.history(redo)
    def menu_delete(self,s=None):
        focus=self.menu_text_focus()
        if focus is not None:
            if focus.isEditable():focus.deleteBackward_(None)
            return
        self.remove_selection(s)
    def update_edit_menu(self):
        sources=self.gestures.sources()
        title=M('移除所选材料  Delete') if sources and sources[0]['kind']=='pool' else M('移回待分配  Delete')
        if sources and sources[0]['kind']=='target':
            assigned=sum(c['entry']['id'] in self.project.state['assignments'] for c in sources)
            empty=len(sources)-assigned
            title=(M('移回待分配') if assigned else M('删除空稿目标'))+'  Delete'
        editing=self.menu_text_focus() is not None
        if editing:title=M('删除文字  Delete')
        self.main.editMenu.setItems([
            dict(title=(M('撤销文字') if editing else M('撤销校对'))+'  ⌘Z',callback=lambda s:self.menu_history(False)),
            dict(title=(M('重做文字') if editing else M('重做校对'))+'  ⇧⌘Z',callback=lambda s:self.menu_history(True)),
            dict(title=M('全选  ⌘A'),callback=self.select_all_menu),
            dict(title=title,callback=self.menu_delete),
            dict(title=M('放大字格  ⌘+'),callback=lambda s:self.change_display(1)),
            dict(title=M('缩小字格  ⌘−'),callback=lambda s:self.change_display(-1)),
            dict(title=M('默认字格大小  ⌘0'),callback=lambda s:self.change_display(0))])
        item=self.main.editMenu.getNSPopUpButton().itemAtIndex_(0);item.setImage_(None);item.setTitle_(R(M('编辑')))
        from .menu_hints import apply_hints
        apply_hints(self.main.editMenu.getNSPopUpButton().menu())

    def history(self,redo):
        if getattr(self,'settings_queue',None):self.settings_queue.flush()
        self.gestures.record("redo_requested" if redo else "undo_requested")
        if self.gestures.pending:self.gestures.cancel_group()
        if self.gestures.active:return
        if self.drop_draft:self.cancel_drop()
        super().history(redo)
        if self.timer: return
        self.gestures.record("history_completed")
        target=self.project.state.get('target',{})
        if self.locked_font and (target.get('master_id')!=self.locked_master or target.get('family')!=self.locked_font.familyName or target.get('font_path')!=ms(self.locked_font.filepath)):
            self.locked_font=None; self.locked_master=None
        self.refresh()

    def cell_status(self,e):
        if entry_warning(e):return M('显示字体缺失')
        status=self.status(e)
        if status==M('已分配'): return ''
        if status.startswith(M('重复')): return M('重复：本次只选一个版本')
        if status.startswith(M('多码点')): return M('多字或组合序列，需处理')
        if status==M('解析失败'): return M('读取失败')
        return status
    def record_display_for_edit(self,value):
        try:
            index=int(self.w.position.get())-1
            old=self.project.state['entries'][index] if 0<=index<len(self.project.state['entries']) else {}
        except (ValueError,TypeError):old={}
        candidates={}
        for entry in self.project.state['entries']:
            for i,name in font_map(entry).items():candidates.setdefault(entry['value'][i],set()).add(name)
        for i,name in (self.editor_font_snapshot or {}).get('fonts',{}).items():
            original=(self.editor_font_snapshot or {}).get('text','')
            if int(i)<len(original):candidates.setdefault(original[int(i)],set()).add(name)
        known=dict(self.editor_font_hints)
        for char,names in candidates.items():
            if len(names)!=1:known.pop(char,None)
        known.update({c:next(iter(names)) for c,names in candidates.items() if len(names)==1})
        return edited_display(old,value,known)
    def style_target_editor(self,sender=None):
        if self.table is None:return
        control=self.w.value
        if not hasattr(control,'getNSTextField'):return
        field=control.getNSTextField();value=control.get()
        entry=dict(value=value)
        info=self.record_display_for_edit(value)
        if info:entry['display']=info
        editor=field.currentEditor()
        if editor is not None and editor.hasMarkedText():return
        attributed=entry_attributed(entry,13)
        if attributed.length():
            attrs,_=attributed.attributesAtIndex_effectiveRange_(0,None)
            field.setFont_(attrs[NSFontAttributeName])
        if editor is not None:
            if editor.hasMarkedText():return
            selection=editor.selectedRange()
            attributed=entry_attributed(entry,13)
            # Font attributes only; no text replacement/undo operation.
            for index in range(attributed.length()):
                attrs,_=attributed.attributesAtIndex_effectiveRange_(index,None)
                editor.textStorage().addAttribute_value_range_(NSFontAttributeName,attrs[NSFontAttributeName],(index,1))
            editor.setSelectedRange_(selection)
        else:field.setAttributedStringValue_(entry_attributed(entry,13))
    def select_cell(self,cell):
        self.gestures.select(cell)
    def cell_menu(self,cell):
        menu=NSMenu.alloc().init(); menu.setAutoenablesItems_(False); self.menu_targets=[]
        for title,callback in self.cell_items(cell):
            target=SVGBatchCellActionTarget.alloc().init(); target.callback=callback; self.menu_targets.append(target)
            item=NSMenuItem.alloc().initWithTitle_action_keyEquivalent_(R(title),'invoke:',''); item.setTarget_(target); menu.addItem_(item)
        return menu
    def cell_items(self,cell):
        result=[(M('查看详情 / 放大…'),lambda s:self.enlarge(cell))]
        if cell['kind']=='target':
            result.extend([(M('修改目标字符／编码…'),lambda s:self.open_target_edit(s,entry_id=cell['entry']['id'])),(M('留空…'),self.blank_selected),(M('重新定位素材…'),self.relocate)])
            sources=[c for c in self.gestures.sources() if c['kind']=='target']
            assigned=sum(c['entry']['id'] in self.project.state['assignments'] for c in sources)
            empty=len(sources)-assigned
            if assigned:result.append((MP(M('将所选 %d 个素材移回待分配区'),assigned),self.unassign_selected))
            if empty:result.append((MP(M('删除所选 %d 个空稿目标'),empty),self.delete_empty_targets))
        return result
    def blank_selected(self,s):
        if not self.selected or self.selected['kind']!='target': return
        def action():
            es=copy.deepcopy(self.project.state['entries'])
            entry=next(e for e in es if e['id']==self.selected['entry']['id'])
            entry['value']='';entry.pop('host_binding',None);entry.pop('display',None);entry.pop('code_record',None)
            self.apply_entries(es)
        self.guard(action)
    def old_unassign_selected(self,s):
        if len(self.gestures.keys)>1:
            from .rearrange import plan
            self.guard(lambda:self.gestures.show_group(plan(self.project,self.gestures.sources(),dict(kind='pool'),filtered=bool(self.w.search.get()) or self.w.filter.get()!=0)))
            return
        if not self.selected or self.selected['kind']!='target': return
        aid=self.project.state['assignments'].get(self.selected['entry']['id'])
        if aid: self.guard(lambda:self.project.move(aid))
    def unassign_selected(self,s=None):
        # Explicit move-to-pool menu keeps its existing SVG-only semantics.
        if self.timer or self.source_task or self.gestures.active or self.gestures.pending or self.drop_draft:return
        sources=[c for c in self.gestures.sources() if c['kind']=='target']
        if sources:self.guard(lambda:remove_selected(self.project,sources))
    def slider_display(self,s):
        self.change_display(None,float(s.get()))
    def toggle_pool(self,s): self.pool_expanded=not self.pool_expanded; self.refresh(); self.save_ui_preferences()
    def search_changed(self,s=None):
        field=self.main.search.getNSTextField();editor=field.currentEditor()
        if editor is not None and editor.hasMarkedText():
            if self.main.search.get():return
            # Native cancel has cleared the field: discard the old composition
            # so a later IME commit cannot restore the cancelled query.
            editor.inputContext().discardMarkedText();editor.unmarkText()
        self.refresh()
        if not self.main.search.get():field.window().makeFirstResponder_(field)
    def main_became_key(self,s=None):
        if getattr(self,'_adopting_table',False):return
        lookup=getattr(self,'preview_lookup',None)
        if lookup is not None:lookup.revalidate()
        self.refresh()
    def refresh(self,s=None):
        if s is getattr(self.main,'search',None):
            editor=self.main.search.getNSTextField().currentEditor()
            if editor is not None and editor.hasMarkedText():return
        if not hasattr(self,'settings_grid') or getattr(self,'_adopting_table',False):return
        self.update_document_context()
        if self.drop_draft and (self.drop_draft[0] is not self.project or not states_equal(self.drop_draft[1],self.project.state)):
            self.drop_overlay={};self.drop_range=None
            self.drop_window.adopt.enable(False)
            self.drop_window.caption.set(M('材料或对应已变化，请取消排布后重新拖入。已有对应保持不变。'))
        candidate=getattr(self,'pending_host',None)
        if candidate and hasattr(self,'summary') and self.summary.getNSWindow() is not None and self.summary.getNSWindow().isVisible():
            import json
            if getattr(self,'source_task',None) or getattr(self,'pdf_intake',None) or candidate.state_signature!=json.dumps(self.project.state,sort_keys=True,ensure_ascii=False) or not candidate.context_valid():
                self.summary.confirm.enable(False);self.summary.summary.set(M('材料、设置或目标已变化；本预检失效，请返回重新预检。'))
        self.render_cache=OrderedDict()
        # Reuse the established filtering and asset checks; draw-only presentation differs.
        PanelActions.refresh(self,s)
        cells=self.grid.cells; self.grid.cells=[c for c in cells if c['kind']=='target']
        self.pool_grid.cells=[c for c in cells if c['kind']=='pool' and c.get('asset')]
        self.gestures.keys.intersection_update(selection_key(c) for c in self.grid.cells+self.pool_grid.cells)
        if self.gestures.pending and not states_equal(self.gestures.pending["before"],self.project.state):
            self.gestures.group_window.adopt.enable(False)
            self.gestures.group_window.caption.set(M('工程已变化，请取消并重新拖动。'))
        unassigned=len(self.project.unassigned()); self.main.poolToggle.getNSButton().setTitle_(R(('▾' if self.pool_expanded else '▸')+MP(M('  待分配   %d'),unassigned)))
        self.main.poolScroll.show(self.pool_expanded)

        self.grid.layout_cells(); self.pool_grid.layout_cells(); self.grid.setNeedsDisplay_(True); self.pool_grid.setNeedsDisplay_(True)
        self.refresh_settings_preview()
        state=self.project.state; settings=state['settings']; count=len(state['entries']); assigned=len(state['assignments'])
        self.main.materials.set(MP(M('%d 个目标 · %d 个材料   ·   缺稿 %d'),(count,len(state['assets']),sum(not e['id'] in state['assignments'] for e in state['entries']))) if count or state['assets'] or state.get('target_list_initialized') or state.get('target_source',{}).get('kind','').startswith('glyphs-') else M('加载字表与素材，开始校对'))
        source=state.get('target_source',{})
        if source.get('kind','').startswith('glyphs-'):self.main.materials.set(source['label']+' · '+self.main.materials.get())
        rules={'number':M('按文件编号对应 · 缺号保留空位'),'order':M('按自然文件顺序对应 · 注意漏文件错位'),'unicode':M('按字符 / Unicode文件名对应')}
        rule_text=rules.get(settings.get('mapping_mode','number'))
        if settings.get('mapping_mode','number')=='number' and (settings['first_number']!=1 or settings['first_position']!=1 or settings['number_group']!=1):
            rule_text=MP(M('文件编号 %d → 第%d格 · 取第%d组数字'),(settings['first_number'],settings['first_position'],settings['number_group']))
        duplicate_ids=self.project.duplicates()
        issues=sum(bool(e['id'] in duplicate_ids or record_problem(e) or entry_status(e) not in (M('可用'),M('空位')) or state['assignments'].get(e['id']) in self.errors) for e in state['entries'])
        self.main.materials.show(True);self.main.issues.set(MP(M('需处理 %d'),issues) if issues else '');self.main.issues.show(bool(issues) and not self.gestures.keys)
        self.main.issues.getNSTextField().setFont_(NSFont.systemFontOfSize_(12));self.main.issues.getNSTextField().setTextColor_(NSColor.systemRedColor())
        self.main.sizeSlider.set(self.display_size)
        if self.gestures.keys:self.main.materials.set(self.main.materials.get()+MP(M(' · 选中 %d 项（当前结果）'),len(self.gestures.keys)))
        self.main.ruleSummary.set(rule_text)
        self.main.dragHint.set(M('中央交换素材；目标间隙整格重排；拖到待分配区移回素材'))
        has_duplicates=bool(self.project.duplicates())
        self.main.duplicates.show(has_duplicates)
        if self.table is not None:self.table.dup.show(has_duplicates);self.table.dedupe.show(has_duplicates)
        self.main.selectionMenu.show(self.selected is not None)
        previous_selected=self.selected
        if self.selected:self.selected=next((c for c in self.grid.cells+self.pool_grid.cells if selection_key(c)==selection_key(self.selected)),None)
        if self.selected and self.selected['kind']=='target' and previous_selected['position']!=self.selected['position']:
            self.w.position.set(ms(self.selected['position']));self.w.value.set(self.selected['entry']['value'])
        self.main.selectionMenu.show(self.selected is not None)
        if self.selected:
            items=[dict(title=t,callback=c) for t,c in self.cell_items(self.selected)]; self.main.selectionMenu.setItems(items)
            item=self.main.selectionMenu.getNSPopUpButton().itemAtIndex_(0); item.setImage_(None); item.setTitle_(R(MP(M('选中 %d 项'),len(self.gestures.keys))))
            self.main.dragHint.setPosSize((630,146,250,22))
        else: self.main.dragHint.setPosSize((630,146,426,22))
        self.main.dragHint.show(False)
        self.main.target.set(MP(M('目标：%s  /  %s'),(self.locked_font.familyName,next((m.name for m in native_items(self.locked_font.masters) if m.id==self.locked_master),M('母版已变化')))) if self.locked_font else M('目标：尚未选择字体'))
        self.main.settingSummary.set((MP(M('%d 项已对应 · 原生导入 · %s · %s'),(assigned,M('保留原字宽') if settings['existing']=='append' else M('使用原生字宽'),{'skip':M('已有内容跳过'),'replace':M('替换已有轮廓'),'append':M('追加轮廓 · 保留原字宽')}[settings['existing']]))) if settings.get('import_method','canvas')=='native' else (MP(M('%d 项已对应 · 统一画布 · %g%% · %s · %s'),(assigned,settings['scale']*100,M('保留字宽') if settings['width_policy']=='preserve' or settings['existing']=='append' else M('统一字宽'),{'skip':M('已有内容跳过'),'replace':M('替换已有轮廓'),'append':M('追加轮廓 · 保留原字宽')}[settings['existing']]))))
        if settings.get('import_method','canvas')=='canvas' and settings.get('fit_target',False):self.main.settingSummary.set(MP(M('%d 项已对应 · 统一画布适配目标字格 · 保留原字宽'),assigned))
        self.main.importGlyphs.enable(bool(count and assigned and not self.timer and not getattr(self,'source_task',None) and not getattr(self,'pdf_intake',None)))
        target_changed=bool(self.locked_font and (getattr(Glyphs,'font',None)!=self.locked_font or not any(m.id==self.locked_master for m in native_items(self.locked_font.masters))))
        if self.owner_invalid or not self.locked_font:self.main.importGlyphs.enable(False)
        if target_changed or (getattr(self,'license_monitor',None) is not None and not self.license_monitor.allowed): self.main.importGlyphs.enable(False)
        primary=self.main.importGlyphs.getNSButton();primary.layer().setBackgroundColor_((NSColor.controlAccentColor() if primary.isEnabled() else NSColor.quaternaryLabelColor()).CGColor())
        self.main.stop.show(bool(self.timer)); recoverable=bool(self.host and any(not r.get('recovered') for r in self.host.records))
        self.main.restore.show(bool(not self.timer and recoverable and not getattr(self.host,'retired',False)))
        search=getattr(self,'search_plan',None)
        if search and search.text:
            missing=search.missing(state['entries'])
            note=MJ('；',search.notes[:2])
            if missing:note+=MF('{detail}未匹配：{detail_2}{detail_3}',detail='；' if note else '',detail_2=MJ('',missing[:12]),detail_3='…' if len(missing)>12 else '')
            self.main.materials.set(MP(M('找到 %d 项／共 %d 项 · 待分配匹配 %d 项%s · 仅筛选预览，导入仍按完整计划'),(len(self.grid.cells),count,len(self.pool_grid.cells),' · '+note if note else '')))
        self.main.status.set(M('请切换到此面板所属字体后写入；面板不会自动改绑。') if target_changed else self.result_message)
        if getattr(self,'license_monitor',None) is not None and not self.license_monitor.allowed and not self.timer:self.main.status.set(self.license_monitor.message)
        self.main.status.getNSTextField().setTextColor_(NSColor.systemOrangeColor() if target_changed else NSColor.secondaryLabelColor())
        self.update_edit_menu()
        self.style_target_editor()
        self.layout()
        self.refresh_detail()
        self.selection_base_materials=self.main.materials.get().partition(M(' · 选中 '))[0]
        from .selection_view import rebuild_lookup
        rebuild_lookup(self)
    def selection_changed(self,old_keys=None,view=None,boxes=(),final=True):
        from .selection_view import update
        update(self,old_keys,view,boxes,final)
    def drag(self,source,dest):
        # Existing swap/insert transaction, with mode choice now in a secondary menu.
        original=self.w.mode.get(); self.w.mode.set(0)
        try: return super().drag(source,dest)
        finally: self.w.mode.set(original)
    def enlarge(self,cell):
        from .detail_ui import build
        build(self,cell,InteractiveGrid)
    def refresh_detail(self):
        from .detail_ui import refresh
        refresh(self)
    def open(self,s):
        if self.host and any(not r.get('recovered') for r in self.host.records):
            if not alert(M('打开另一工程后，当前导入仍可在本面板恢复；请保留写前备份。继续打开？'),True): return
        super().open(s); self.restore_bound_target();self.selected=None; self.refresh()
    def import_batch(self,s):
        def action():
            if getattr(self,'settings_queue',None):
                self.settings_queue.flush()
                if not self.settings_queue.parameters_valid:raise ValueError(M('当前设置输入无效，请先修正或关闭设置窗口'))
            if self.raise_dialog(M('确认导入')):return
            if getattr(getattr(self,'preview_lookup',None),'running',False):raise ValueError(M('正在分批读取目标预览，请完成或按Esc取消后再预检'))
            if getattr(self,'source_task',None):raise ValueError(M('正在读取目标，请完成或按Esc取消后再导入'))
            if getattr(self,'pdf_intake',None):raise ValueError(M('正在读取材料，请先采用或取消后再导入'))
            if self.gestures.pending or self.gestures.active:raise ValueError(M('请先完成或取消素材拖动调整'))
            if self.drop_draft: raise ValueError(M('请先采用或取消排布预览，再导入Glyphs。'))
            self.check_owner()
            if not self.locked_font: self.open_target(); return
            if not self.retire_previous():return
            candidate=HostSession(self.project,self.locked_font,self.locked_master,ROOT)
            w=self.preflight_window=self.dialog((600,155),M('导入预检'))
            w.caption=vanilla.TextBox((20,18,560,66),M('正在核验目标、素材及候选；尚未写入…'))
            w.cancel=vanilla.Button((410,103,170,30),M('取消预检'),callback=lambda sender:self.cancel_preflight())
            self.preflight_task=dict(candidate=candidate,window=w)
            self.show_dialog(w)
            try:candidate.start_preflight()
            except Exception:
                self.cancel_preflight();raise
            self.preflight_tick_target=SVGBatchPreflightTickRC34.alloc().init();self.preflight_tick_target.owner=self
            self.timer=NSTimer.scheduledTimerWithTimeInterval_target_selector_userInfo_repeats_(.02,self.preflight_tick_target,'tick:',None,True)
        self.guard(action)
    def present_import_confirmation(self,candidate):
        rows=candidate.rows
        atomic_json(ROOT/'reports/preflight.json',rows)
        blocked=any(r['status'].startswith(M('阻止')) for r in rows)
        self.pending_host=candidate; w=self.summary=self.dialog((760,640),M('确认导入'))
        append_count=sum(r['status']==M('追加') for r in rows)
        replace=sum(r['status']==M('替换') for r in rows); missing=sum(r['status']==M('未分配') for r in rows)
        w.summary=vanilla.TextBox((20,18,720,132),MP(M('%s\n写入 %d 项 · 替换 %d 项 · 未分配 %d 项\n%s'),(self.main.target.get(),len(candidate.plan),replace,missing,M('请先处理下方冲突，尚未写入。') if blocked else M('确认后先保存可恢复副本，再写入所选母版。'))))
        if candidate.settings['existing']=='append':w.summary.set(w.summary.get()+MP(M('\n追加 %d 项；保留原路径、组件及字宽。再次导入会再次叠加，请核对。'),append_count))
        elif candidate.settings.get('import_method','canvas')=='native':w.summary.set(MF('{detail}\n原生导入会采用Glyphs生成的字宽，可能改变现有字宽。',detail=w.summary.get()))
        if candidate.settings.get('import_method','canvas')=='canvas' and candidate.settings.get('fit_target',False):w.summary.set(MF('{detail}\n按目标实际字宽和母版范围适配整个源画布；保留原字宽。',detail=w.summary.get()))
        display_rows=[]
        for row in rows:
            entry=self.project.state['entries'][row['position']-1];caption=entry_attributed(entry,13) if has_target(entry) else M('空位')
            if entry.get('host_binding') and entry['value'] and not entry_warning(entry):caption.appendAttributedString_(NSAttributedString.alloc().initWithString_(R(' · '+entry['host_binding']['glyph_name'])))
            display_rows.append(dict(position=row['position'],value=caption,status=row['status']+(' · '+MJ('；',row.get('warnings',[])) if row.get('warnings') else '')+(MP(M(' · 适配比例 %.6g'),row['fit_scale']) if 'fit_scale' in row else '')+(MP(M(' · 原生字宽 %g'),row['native_width']) if 'native_width' in row else '')))
        w.rowInfo=vanilla.TextEditor((20,455,720,96),'',readOnly=True)
        def row_selected(sender):
            if not self.dialog_alive(w):return
            selected=sender.getSelection();index=selected[0] if selected else 0
            from .diagnostics import explain
            w.rowInfo.set(display_rows[index]['status']+'\n\n'+explain(rows[index].get('diagnostics',[])) if display_rows else '')
        w.rows=vanilla.List((20,160,720,280),display_rows,selectionCallback=row_selected,columnDescriptions=[dict(title=M('位置'),key='position',width=65),dict(title=M('目标'),key='value',width=225 if any(e.get('host_binding') for e in self.project.state['entries']) else 85),dict(title=M('处理结果'),key='status')])
        w.back=vanilla.Button((20,590,170,30),M('返回校对'),callback=lambda s:self.finish_dialog(w))
        w.confirm=vanilla.Button((520,590,220,30),M('确认写入 Glyphs'),callback=self.confirm_import)
        w.confirm.enable(bool(candidate.plan and not blocked));w.bind('became key',self.refresh); self.show_dialog(w);row_selected(w.rows)

    def cancel_preflight(self,close_window=True):
        task=getattr(self,'preflight_task',None)
        if not task:return
        if self.timer:self.timer.invalidate();self.timer=None
        target=getattr(self,'preflight_tick_target',None)
        if target:target.owner=None
        self.preflight_task=None;self.preflight_window=None;self.pending_host=None
        if close_window:self.finish_dialog(task['window'])
        self.result_message=M('已取消预检；尚未写入，工程与对应保持不变')
        if not getattr(self,'_closing_cleanup',False):self.refresh()

    def preflight_tick(self,timer):
        task=getattr(self,'preflight_task',None)
        if not task or getattr(self,'_closed',False):timer.invalidate();return
        try:
            candidate=task['candidate'];more=candidate.preflight_chunk()
            task['window'].caption.set(MP(M('预检 %d / %d；尚未写入，可取消。'),(candidate.preflight_cursor,len(candidate.project.state['entries']))))
            if not more:
                timer.invalidate();self.timer=None;self.preflight_tick_target.owner=None
                self.preflight_task=None;self.preflight_window=None
                self.finish_dialog(task['window']);self.present_import_confirmation(candidate)
        except Exception as exc:
            traceback.print_exc();self.cancel_preflight()
            self.result_message=MF('预检失败，尚未写入：{detail}',detail=M('内存不足，请释放其他大型任务后重试') if isinstance(exc,MemoryError) else ms(exc))
            self.refresh();alert(self.result_message)

    def open_activation(self,s=None):
        from .license_ui import show
        show(self,s)
    def confirm_import(self,s):
        def action():
            candidate=self.pending_host
            if candidate is None:raise ValueError(M('预检已失效，请重新预检'))
            self.summary.confirm.enable(False)
            candidate.begin(); self.host=candidate; self.finish_dialog(self.summary); self.result_message=M('正在导入…')
            self.tick_target=SVGBatchTick.alloc().init(); self.tick_target.owner=self
            self.timer=NSTimer.scheduledTimerWithTimeInterval_target_selector_userInfo_repeats_(.05,self.tick_target,'tick:',None,True)
        self.guard(action)
    def tick(self,timer):
        if getattr(self,'_closed',False):timer.invalidate();return
        try:
            more=self.host.step(); self.result_message=MP(M('正在导入 %d / %d'),(len(self.host.records),len(self.host.plan)))
            if not more:
                timer.invalidate(); self.timer=None; self.result_message=MP(M('导入完成：已写入 %d 项'),len(self.host.records))
        except Exception as exc:
            timer.invalidate(); self.timer=None; self.host.cancelled=True
            if self.host.cursor<len(self.host.plan): self.host.plan[self.host.cursor]['row']['status']=MF('失败：{detail}',detail=ms(exc))
            self.result_message=self.host.abort(ms(exc))
            alert(self.result_message)
        self.refresh()
    def cancel(self,s):
        if getattr(self,'preflight_task',None):self.cancel_preflight();return
        super().cancel(s); self.result_message=self.host.abort_message if self.host and self.host.started else M('已取消，尚未写入'); self.refresh()
    def add_files(self,paths):
        if self.has_pdf_files(paths):return self.intake_files(paths)
        super().add_files(paths)
        if self.project.state['entries'] and self.project.state['assets'] and not self.project.state['assignments']:
            self.map(None)
    def status(self,e):
        return record_problem(e) or super().status(e)
    def drop_files(self,paths,start):
        if self.has_pdf_files(paths):return self.intake_files(paths,start)
        def action():
            if self.gestures.pending or self.gestures.active:raise ValueError(M('请先完成或取消素材拖动调整'))
            if self.drop_draft: raise ValueError(M('请先采用或取消当前排布预览'))
            before_assets=set(self.project.state['assets'])
            self.project.add_files(paths)
            # Include previously loaded paths too, without duplicating asset identity.
            roots=[Path(p).resolve() for p in paths]
            aids=[a for a,item in self.project.state['assets'].items() if a not in before_assets or any(Path(item['path'])==p or (p.is_dir() and Path(item['path']).parent==p) for p in roots)]
            if not aids:raise ValueError(M('没有可读取的矢量文件（支持 SVG、EPS、矢量PDF（按页加载））'))
            additions,rows,extent=direct_proposal(self.project,aids,start)
            self.present_drop_preview(start,additions,rows,extent)
        self.guard(action)
    def present_drop_preview(self,start,additions,rows,extent,before=None):
        if self.drop_draft:raise ValueError(M('请先采用或取消当前排布预览'))
        if before is not None and not states_equal(before,self.project.state):raise ValueError(M('材料或对应已变化，请重新拖动'))
        self.drop_draft=(self.project,copy.deepcopy(before if before is not None else self.project.state),dict(additions),copy.deepcopy(rows))
        self.drop_overlay=additions;self.drop_range=extent
        w=self.drop_window=self.dialog((760,490),M('从指定字格排布素材'))
        # The accepted proposal already freezes Finder-natural or internal-visible order.
        w.drop_asset_order=tuple(r['asset'] for r in rows)
        w.drop_start=start
        mode=self.project.state['settings']['mapping_mode']
        choices=[M('按编号定位（保留缺号）'),M('按所选顺序连续排布')]
        w.drop_modes=[('number',False),('order',True)]
        if mode!='number':
            choices.append(M('按自然文件顺序（当前规则）') if mode=='order' else M('按字符／Unicode匹配（当前规则）'))
            w.drop_modes.append((mode,False))
        if mode!='unicode':
            choices.append(M('按字符／Unicode匹配'));w.drop_modes.append(('unicode',False))
        w.rule=vanilla.PopUpButton((20,16,430,26),choices,callback=lambda sender:self.guard(self.switch_drop_rule))
        w.rule.set(1)
        w.caption=vanilla.TextBox((20,54,720,80),'')
        w.rows=vanilla.List((20,144,720,255),[],columnDescriptions=[dict(title=M('素材'),key='file',width=200),dict(title=M('位置'),key='position',width=55),dict(title=M('依据'),key='basis',width=130),dict(title=M('提示'),key='status')])
        w.back=vanilla.Button((20,429,160,30),M('取消排布'),callback=self.cancel_drop)
        w.adopt=vanilla.Button((540,429,200,30),M('采用无冲突对应'),callback=self.confirm_drop)
        w.bind('should close',lambda sender:(self.cancel_drop(),False)[1])
        self.update_drop_preview(additions,rows,extent)
        self.show_dialog(w)
    def update_drop_preview(self,additions,rows,extent):
        project,before,_,_=self.drop_draft
        self.drop_draft=(project,before,dict(additions),copy.deepcopy(rows))
        self.drop_overlay=dict(additions);self.drop_range=extent
        w=self.drop_window;start=w.drop_start;stats=placement_stats(additions,rows)
        settings=self.project.state['settings'];mode,selected_order=w.drop_modes[w.rule.get()]
        rule=M('按待分配区当前排列中的所选顺序；不跳过冲突位置') if selected_order else (MP(M('编号%d对应落点；取第%d组数字'),(settings['first_number'],settings['number_group']))) if mode=='number' else M('自然文件排序，连续排布') if mode=='order' else M('按字符／Unicode匹配，落点不改变目标')
        if mode=='number' and any(len(r['numbers'])>1 for r in rows):rule+=M('；多组数字，请核对编号规则')
        if any(r['basis']==M('字符／Unicode匹配') for r in rows) and mode!='unicode':rule+=M('；明确字符名仍按字符匹配')
        first=next((r for aid in w.drop_asset_order for r in rows if r['asset']==aid),None)
        first_text=(MP(M('首项 %s → 第%s格'),(first['file'],first['position'] if first['position'] is not None else '—'))) if first else M('无所选材料')
        rule=first_text+'；'+rule
        w.caption.set(MP(M('鼠标落点：第%d格 %s · 受影响范围：%s\n可新增对应%d项；%d项冲突／歧义；超界%d项；其他待分配%d项。已有分配保持。\n这里只调整预览；采用后仍需点击“导入Glyphs”才能写入。\n%s'),(start,self.project.state['entries'][start-1]['value'] or M('空位'),MP(M('第%d—%d格'),extent) if extent else M('无可对应位置'),len(additions),stats['conflicts'],stats['overflow'],stats['other'],rule)))
        w.rows.set([dict(file=r['file'],position=r['position'] if r['position'] is not None else '—',basis=r['basis'],status=r['status']) for r in rows])
        w.adopt.enable(bool(additions))
    def switch_drop_rule(self):
        if not self.drop_draft:raise ValueError(M('没有待采用的排布'))
        project,before,_,_=self.drop_draft
        if project is not self.project or not states_equal(before,self.project.state):raise ValueError(M('材料或对应已变化，请取消后重新拖入'))
        w=self.drop_window;mode,selected_order=w.drop_modes[w.rule.get()]
        additions,rows,extent=drop_proposal(self.project,w.drop_asset_order,w.drop_start,mode=mode,asset_order=w.drop_asset_order if selected_order else None)
        self.update_drop_preview(additions,rows,extent)
    def cancel_drop(self,s=None):
        self.drop_draft=None;self.drop_overlay={};self.drop_range=None
        if hasattr(self,'drop_window'):self.hide_dialog(self.drop_window)
        self.refresh()
    def confirm_drop(self,s=None):
        def action():
            if not self.drop_draft:raise ValueError(M('没有待采用的排布'))
            project,before,additions,rows=self.drop_draft
            if project is not self.project:raise ValueError(M('工程已变化，请重新拖入'))
            adopt_drop(self.project,before,additions,rows);self.cancel_drop()
        self.guard(action)
    def extract(self,s):
        if self.raise_dialog(M('核对字表解析')):return
        def action():
            import time
            stage=time.perf_counter();self.last_table_metrics={}
            raw=self.w.source.get(); lines=raw.split('\n')
            a,sep,b=self.w.range.get().partition('-'); start=int(a or '1'); end=int(b) if b else len(lines)
            if not 1<=start<=end<=len(lines): raise ValueError(M('来源行范围无效'))
            source=getattr(self,'source_path',M('粘贴')) if raw==getattr(self,'loaded_source_text',None) else M('粘贴/编辑')
            mode=['continuous','items','records','auto','codes','alternating_codes','alternating_chars'][self.w.readmode.get()]
            document=getattr(self,'document_source',{})
            if raw==document.get('text') and document.get('columns') and mode not in ('records','auto'):raise ValueError(M('已指定编码列的表格必须按字符＋编码双列读取，不能将编码拆成正文；请重新选择文件调整编码列。'))
            col=[None,(0,1),(1,0)][self.w.recordcolumns.get()]
            if raw==document.get('text') and document.get('columns') and mode=='auto':mode='records';col=col or document['columns']
            es,chosen=parse_table(MJ('\n',lines[start-1:end]),mode,self.w.whitespace.get(),source,start,col)
            self.last_table_metrics['parse_seconds']=time.perf_counter()-stage;stage=time.perf_counter()
            self.attach_document_sources(raw,es)
            attach_editor_records(self.w.source.getNSTextView(),es)
            self.last_table_metrics['source_fonts_seconds']=time.perf_counter()-stage;stage=time.perf_counter()
            self.table_draft=(copy.deepcopy(self.project.state),es,self.w.binding.get())
            w=self.table_preview=self.dialog((780,560),M('核对字表解析'),parent=self.table)
            bad=sum(entry_status(e) not in (M('可用'),M('空位')) for e in es)
            labels={'continuous':M('连续文字'),'items':M('每行一个位置'),'records':M('字符＋编码双列'),'ambiguous':M('读取方式待选择'),'codes':M('仅Unicode编码'),'alternating_codes':M('字符／编码交替行（编码在上）'),'alternating_chars':M('字符／编码交替行（字符在上）')}
            w.caption=vanilla.TextBox((20,18,740,62),MP(M('读取方式：%s · %d 个目标条目 · %d 条记录待确认\n红色记录不会导入。请返回整理，修正原记录或选择读取模式与列顺序后重新预览。'),(labels[chosen],len(es),bad)))
            content=[]; problems=[]
            for i,e in enumerate(es):
                code=e.get('code_record',{}).get('encoding','')
                st=entry_status(e); problem=st not in (M('可用'),M('空位'))
                content.append(MP('%d · %s   %s   %s   %s',(i+1,e.get('source_location',MP(M('原行%d'),e['line'])),e['value'] or '□',code,st if problem else M('空位') if not e['value'] else '')))
                problems.append(problem)
            w.rows=vanilla.TextEditor((20,92,740,370),MJ('\n',content))
            tv=w.rows.getNSTextView(); tv.setEditable_(False)
            tv.textStorage().beginEditing()
            try:
                offset=0
                for line,problem in zip(content,problems):
                    length=NSString.stringWithString_(R(line)).length()
                    if problem: tv.textStorage().addAttribute_value_range_('NSColor',NSColor.systemRedColor(),(offset,length))
                    offset+=length+1
                offset=0
                for line,entry in zip(content,es):
                    prefix=line.find(entry['value']) if entry['value'] else -1
                    if prefix>=0:tv.textStorage().replaceCharactersInRange_withAttributedString_((offset+NSString.stringWithString_(R(line[:prefix])).length(),NSString.stringWithString_(R(entry['value'])).length()),entry_attributed(entry,13))
                    offset+=NSString.stringWithString_(R(line)).length()+1
            finally:tv.textStorage().endEditing()
            w.back=vanilla.Button((20,490,170,30),M('返回整理并修正'),callback=lambda sender:self.finish_dialog(w))
            w.adopt=vanilla.Button((520,490,240,30),M('采用字表（问题项保留待确认）') if bad else M('采用字表'),callback=self.adopt_table)
            if self.project.state['assignments']:
                w.caption.set(MF('{detail}\n替换字表：{detail_2}；未保留的素材退回待分配。',detail=w.caption.get(),detail_2=self.w.binding.getItems()[self.w.binding.get()]))
            self.show_dialog(w)
            self.last_table_metrics['preview_window_seconds']=time.perf_counter()-stage
        self.guard(action)
    def adopt_table(self,s):
        # One atomic plan edit; no implicit material mapping or second full refresh.
        import time
        started=time.perf_counter();project=self.project
        previous=copy.deepcopy(project.state);undo=list(project.undo_stack);redo=list(project.redo_stack);pending=getattr(self,'pending_host',None)
        self.last_table_metrics=getattr(self,'last_table_metrics',{})
        draft=getattr(self,'table_draft',None);self._adopting_table=True
        try:
            if self.timer:raise ValueError(M('导入期间不能采用新字表'))
            if draft is None:raise ValueError(M('字表预览已采用或已失效，请重新解析'))
            before,es,binding=draft
            if project.state!=before:raise ValueError(M('字表已变化，请重新预览。'))
            project.replace_entries(es,'identity' if binding==0 else 'position',target_source=dict(kind='external',label=M('外部字表')))
            self.last_table_metrics['adopt_plan_seconds']=time.perf_counter()-started
            self.pending_host=None
            self.result_message=MP(M('已采用 %d 个目标；未自动重建对应，可稍后使用文件 → 批量对应…'),len(es))
            self.finish_dialog(self.table_preview)
            self.table_draft=None
        except Exception as exc:
            project.state=previous;project.undo_stack=undo;project.redo_stack=redo;self.pending_host=pending;self.table_draft=draft
            import traceback
            traceback.print_exc();alert(exc)
        finally:self._adopting_table=False
        self.refresh()
        self.last_table_metrics['adopt_callback_seconds']=time.perf_counter()-started
    def map(self,s):
        if self.raise_dialog(M('核对素材对应')):return
        def action():
            mode=['number','order','unicode'][self.w.mapmode.get()]
            rule=tuple(self.project.state['settings'][k] for k in ('number_group','first_number','first_position')) if mode=='unicode' else tuple(int(getattr(self.w,n).get()) for n in ('group','firstnumber','firstposition'))
            if mode=='unicode':
                if not self.project.state['entries']:raise ValueError(M('请先读取目标字表'))
                proposal,rows,_=drop_proposal(self.project,list(self.project.state['assets']),1,mode='unicode')
            else:proposal,rows=self.project.mapping_proposal(mode,*rule)
            atomic_json(ROOT/'reports/mapping-preview.json',rows)
            self.mapping_draft=(self.project,copy.deepcopy(self.project.state),proposal,rows,mode,rule)
            w=self.mapping_window=self.dialog((740,450),M('核对素材对应'),parent=self.rules_window)
            multi=any(len(r['numbers'])>1 for r in rows) and mode=='number'
            unresolved=sum(r['status'] not in (M('候选'),M('已在此位置')) for r in rows)
            rule_note=M('字符／Unicode精确匹配，与文件顺序和起点无关；保留全部已有对应，仅新增无冲突项。') if mode=='unicode' else M('采用后替换当前对应关系；文件内容保持不变。')
            w.caption=vanilla.TextBox((20,20,700,65),MP(M('可新增对应 %d 个素材 · %d 项未匹配或有冲突\n%s\n%s'),(len(proposal),unresolved,M('部分文件含多组数字，请核对位置或更改对应规则。') if multi else M('请核对文件与目标字符，数量相等不代表内容正确。'),rule_note)))
            targets=self.project.state['entries']
            display=[]
            for row in rows:
                pos=row['position']; value=entry_attributed(targets[pos-1],13) if pos and 1<=pos<=len(targets) else ''
                display.append(dict(file=row['file'],position=pos if pos is not None else '—',value=value,status=row['status']+(' · '+MJ('；',row.get('warnings',[])) if row.get('warnings') else '') if row['status']!=M('候选') else ''))
            w.rows=vanilla.List((20,105,700,250),display,columnDescriptions=[dict(title=M('素材文件'),key='file',width=220),dict(title=M('位置'),key='position',width=65),dict(title=M('目标'),key='value',width=70),dict(title=M('提示'),key='status')])
            w.rules=vanilla.Button((20,385,150,30),M('更改对应规则…'),callback=lambda s:(self.finish_dialog(w),self.open_rules()))
            w.adopt=vanilla.Button((510,385,210,30),M('采用此对应'),callback=self.adopt_mapping)
            self.show_dialog(w)
        self.guard(action)
    def adopt_mapping(self,s):
        def action():
            project,state,proposal,rows,mode,rule=self.mapping_draft
            if project is not self.project or state!=self.project.state: raise ValueError(M('材料或对应关系已变化，请重新预览对应。'))
            if mode=='unicode':
                checked,_,_=drop_proposal(self.project,list(self.project.state['assets']),1,mode='unicode')
                if checked!=proposal:raise ValueError(M('匹配规则已更新，请重新预览对应。'))
            def adopt():
                if mode=='unicode':self.project.state['assignments'].update(proposal)
                else:self.project.state['assignments']=proposal
                self.project.state['mapping_preview']=rows
                self.project.state['settings'].update(mapping_mode=mode,number_group=rule[0],first_number=rule[1],first_position=rule[2])
                for row in rows: self.project.state['assets'][row['asset']]['number_groups']=row['numbers']
            self.project.edit(adopt); self.finish_dialog(self.mapping_window)
        self.guard(action)


def show_panel(fallback=None):
    """Document identity selects the owner; launcher fallback never crosses documents."""
    global _active_panel
    from .panel_entry import document_panel
    from .i18n import prepare_open
    prepare_open()
    owner=getattr(Glyphs,'font',None)
    candidate=document_panel(owner)
    if live_panel(candidate):
        candidate.update_document_context();_active_panel=candidate
        return raise_panel(candidate)
    return Panel(previous=candidate,owner_font=owner)
