from pathlib import Path
__path__.insert(0,str(Path(__file__).resolve().parents[2]/'compiled/svg_batch'))
