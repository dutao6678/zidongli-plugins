"""Display-only wheel rate limiting; no project geometry or parsing."""
import math

def wheel_step(value,delta,precise,stamp,previous=None,low=.75,high=2.):
    if not math.isfinite(delta) or not math.isfinite(stamp):return value,previous
    sign=1 if delta>0 else -1 if delta<0 else 0
    old_stamp,credit,old_sign,residual=previous or (stamp,.125,sign,0.)
    credit=min(.125,credit+max(0.,stamp-old_stamp)*.5)
    if sign!=old_sign:credit=.125;residual=0.
    amount=math.copysign(min(abs(delta)*(.0025 if precise else .075),credit),delta) if sign else 0.
    next_value=round(max(low,min(high,value+amount+residual)),3)
    residual=0. if next_value in (low,high) else value+amount+residual-next_value
    return next_value,(stamp,max(0.,credit-abs(amount)),sign,residual)
