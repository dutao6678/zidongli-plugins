from .i18n import message as M,format_message as MF,percent_message as MP,join_message as MJ,string_message as ms,render as R
"""System font fallback only; display markers never alter target Unicode data."""
from functools import lru_cache
from AppKit import NSFont
from Foundation import NSString
from CoreText import CTFontCreateForString,CTFontCopyCharacterSet,CTFontCopyPostScriptName
from CoreFoundation import CFCharacterSetIsLongCharacterMember

@lru_cache(maxsize=2048)
def target_label(value):
    if not value:return '□',''
    string=NSString.stringWithString_(R(value))
    font=CTFontCreateForString(NSFont.systemFontOfSize_(14),string,(0,string.length()))
    charset=CTFontCopyCharacterSet(font)
    missing=ms(CTFontCopyPostScriptName(font)).startswith('LastResort') or any(not CFCharacterSetIsLongCharacterMember(charset,ord(char)) for char in value)
    codes=MJ(' ',(MP('U+%04X',ord(char)) for char in value))
    return ('□',codes) if missing else (value,codes if len(value)!=1 else '')
