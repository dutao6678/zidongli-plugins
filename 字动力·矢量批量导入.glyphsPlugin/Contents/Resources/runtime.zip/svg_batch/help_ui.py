from .i18n import message as M,format_message as MF,percent_message as MP,join_message as MJ,string_message as ms,render as R
"""Panel-owned About and explicit nonblocking public update check."""
import queue,threading,weakref
from . import localized_ui as vanilla
from Foundation import NSTimer,NSRunLoop,NSRunLoopCommonModes
from AppKit import NSPasteboard,NSPasteboardTypeString
from .panel_actions import SVGBatchTick
from .update_check import fetch_public

def loaded_version():
    from .version import VERSION,BUILD,CHANNEL
    return dict(version=VERSION,build=BUILD,channel=M(CHANNEL))

class UpdateTask:
    def __init__(self,panel,window):
        self.owner=weakref.ref(panel);self.window=window;self.cancel=threading.Event();self.results=queue.Queue();self.timer=None;self.target=None;self.active=False
    def start(self):
        if self.active:return
        self.active=True;current=loaded_version();cancel=self.cancel;results=self.results
        def work():
            try:result=fetch_public(current,cancel)
            except Exception as exc:result=dict(text=MF('检查更新失败：{detail}',detail=ms(exc)),failed=True)
            if not cancel.is_set():results.put(result)
        self.target=SVGBatchTick.alloc().init();self.target.owner=self
        self.timer=NSTimer.timerWithTimeInterval_target_selector_userInfo_repeats_(.1,self.target,'tick:',None,True)
        NSRunLoop.mainRunLoop().addTimer_forMode_(self.timer,NSRunLoopCommonModes)
        threading.Thread(target=work,name='ZiDongLi-public-metadata',daemon=True).start()
    def tick(self,timer):
        p=self.owner();w=self.window
        if p is None or getattr(p,'_closed',False) or w is None or w.getNSWindow() is None:self.close();return
        try:result=self.results.get_nowait()
        except queue.Empty:return
        self.result=result;w.info.set(result['text']);self.active=False;self.stop_timer()
    def stop_timer(self):
        if self.timer is not None:self.timer.invalidate();self.timer=None
        if self.target is not None:self.target.owner=None;self.target=None
    def close(self):self.cancel.set();self.stop_timer();self.window=None;self.active=False

class HelpUI:
    def open_about(self,s=None):
        if self.raise_dialog(M('关于插件')):return
        v=loaded_version();text=MP(M('字动力 · 矢量批量导入\n版本：%s\nbuild：%d\n状态：%s'),(v['version'],v['build'],v['channel']))
        w=self.about_window=self.dialog((520,280),M('关于插件'))
        w.info=vanilla.TextEditor((20,20,480,170),text,readOnly=True)
        def copy_version(sender):
            pb=NSPasteboard.generalPasteboard();pb.clearContents();pb.setString_forType_(text,NSPasteboardTypeString)
        w.copyVersion=vanilla.Button((20,220,150,30),M('复制版本信息'),callback=copy_version)
        w.done=vanilla.Button((350,220,150,30),M('关闭'),callback=lambda s:self.finish_dialog(w));self.show_dialog(w)
    def open_update(self,s=None):
        if self.raise_dialog(M('检查更新')):return
        w=self.update_window=self.dialog((580,350),M('检查更新'))
        w.info=vanilla.TextEditor((20,20,540,250),M('正在读取公开插件源…\n仅查询公开发布信息，不发送机器码、授权、工程或字体。'),readOnly=True)
        w.done=vanilla.Button((390,295,170,30),M('关闭'),callback=lambda s:self.finish_dialog(w))
        self.update_task=UpdateTask(self,w);self.show_dialog(w);self.update_task.start()

    def open_language(self,s=None):
        from .i18n import LANGUAGES,NAMES,language,preferred,save_preferred
        from .panel_entry import all_panels
        busy=any(getattr(p,'timer',None) or getattr(p,'source_task',None) or getattr(p,'pdf_intake',None) or getattr(getattr(p,'settings_queue',None),'pending',False) or getattr(p,'_closing_cleanup',False) for p in all_panels() if not getattr(p,'_closed',False))
        if busy:
            from .panel_actions import alert
            alert(M('有面板正在执行任务，请完成或安全停止后再选择界面语言。当前任务和工程不变。'));return
        if self.raise_dialog(M('界面语言')):return
        w=self.language_window=self.dialog((560,290),M('界面语言'))
        w.caption=vanilla.TextBox((20,18,520,45),M('语言偏好由所有字体面板共享，首次使用简体中文，不跟随系统切换。'))
        w.choices=vanilla.PopUpButton((20,76,520,28),list(NAMES));w.choices.set(LANGUAGES.index(preferred()))
        w.note=vanilla.TextBox((20,118,520,84),M('保存后，请关闭所有本插件面板并重新打开以应用语言；当前工程、材料对应及恢复记录会保留。正在运行的任务不会被语言切换中断。'))
        w.current=vanilla.TextBox((20,206,520,30),MF('当前界面：{current}；已保存偏好：{saved}',current=NAMES[LANGUAGES.index(language())],saved=NAMES[LANGUAGES.index(preferred())]),sizeStyle='small')
        def adopt(sender):
            from .panel_actions import alert
            try:save_preferred(LANGUAGES[w.choices.get()])
            except (ValueError,OSError) as exc:
                alert(M('界面偏好文件无效；未覆盖原文件')+'\n'+ms(exc));return
            self.finish_dialog(w)
            alert(M('语言偏好已保存。关闭所有本插件面板后重新打开生效；无需重启Glyphs，不会清空当前工作。'))
        w.cancel=vanilla.Button((20,248,160,28),M('取消'),callback=lambda sender:self.finish_dialog(w))
        w.apply=vanilla.Button((330,248,210,28),M('保存语言选择'),callback=adopt)
        self.show_dialog(w)
