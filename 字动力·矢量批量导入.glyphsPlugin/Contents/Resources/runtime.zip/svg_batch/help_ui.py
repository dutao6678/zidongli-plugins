"""Panel-owned About and explicit nonblocking public update check."""
import queue,threading,weakref
import vanilla
from Foundation import NSTimer,NSRunLoop,NSRunLoopCommonModes
from AppKit import NSPasteboard,NSPasteboardTypeString
from .panel_actions import SVGBatchTick
from .update_check import fetch_public

def loaded_version():
    from .version import VERSION,BUILD,CHANNEL
    return dict(version=VERSION,build=BUILD,channel=CHANNEL)

class UpdateTask:
    def __init__(self,panel,window):
        self.owner=weakref.ref(panel);self.window=window;self.cancel=threading.Event();self.results=queue.Queue();self.timer=None;self.target=None;self.active=False
    def start(self):
        if self.active:return
        self.active=True;current=loaded_version();cancel=self.cancel;results=self.results
        def work():
            try:result=fetch_public(current,cancel)
            except Exception as exc:result=dict(text='检查更新失败：'+str(exc),failed=True)
            if not cancel.is_set():results.put(result)
        self.target=SVGBatchTick.alloc().init();self.target.owner=self
        self.timer=NSTimer.timerWithTimeInterval_target_selector_userInfo_repeats_(.1,self.target,'tick:',None,True)
        NSRunLoop.mainRunLoop().addTimer_forMode_(self.timer,NSRunLoopCommonModes)
        threading.Thread(target=work,name='ZiDongLi-public-metadata',daemon=True).start()
    def tick(self,timer):
        p=self.owner();w=self.window
        if p is None or getattr(p,'_closed',False) or w is None or w.getNSWindow() is None:self.close();return
        try:result=self.results.get_nowait()
        except queue.Empty:return
        self.result=result;w.info.set(result['text']);self.active=False;self.stop_timer()
    def stop_timer(self):
        if self.timer is not None:self.timer.invalidate();self.timer=None
        if self.target is not None:self.target.owner=None;self.target=None
    def close(self):self.cancel.set();self.stop_timer();self.window=None;self.active=False

class HelpUI:
    def open_about(self,s=None):
        if self.raise_dialog('关于插件'):return
        v=loaded_version();text='字动力 · 矢量批量导入\n版本：%s\nbuild：%d\n状态：%s'%(v['version'],v['build'],v['channel'])
        w=self.about_window=self.dialog((520,280),'关于插件')
        w.info=vanilla.TextEditor((20,20,480,170),text,readOnly=True)
        def copy_version(sender):
            pb=NSPasteboard.generalPasteboard();pb.clearContents();pb.setString_forType_(text,NSPasteboardTypeString)
        w.copyVersion=vanilla.Button((20,220,150,30),'复制版本信息',callback=copy_version)
        w.done=vanilla.Button((350,220,150,30),'关闭',callback=lambda s:self.finish_dialog(w));self.show_dialog(w)
    def open_update(self,s=None):
        if self.raise_dialog('检查更新'):return
        w=self.update_window=self.dialog((580,350),'检查更新')
        w.info=vanilla.TextEditor((20,20,540,250),'正在读取公开插件源…\n仅查询公开发布信息，不发送机器码、授权、工程或字体。',readOnly=True)
        w.done=vanilla.Button((390,295,170,30),'关闭',callback=lambda s:self.finish_dialog(w))
        self.update_task=UpdateTask(self,w);self.show_dialog(w);self.update_task.start()
