from .i18n import message as M,format_message as MF,percent_message as MP,join_message as MJ,string_message as ms,render as R
"""Native search/cancel cell with the existing text-field adapter contract."""
from . import localized_ui as vanilla

class SearchControl(vanilla.SearchBox):
    def __init__(self,posSize,text='',callback=None,placeholder=None):
        super().__init__(posSize,text,callback=callback,placeholder=placeholder)
        field=self.getNSSearchField()
        field.setSendsSearchStringImmediately_(True)
        field.setSendsWholeSearchString_(False)
        field.setMaximumRecents_(0)
        field.cell().cancelButtonCell().setAccessibilityLabel_(R(M('清除搜索')))
    def getNSTextField(self):return self.getNSSearchField()
