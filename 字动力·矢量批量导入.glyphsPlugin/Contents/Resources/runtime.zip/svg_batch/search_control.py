"""Native search/cancel cell with the existing text-field adapter contract."""
import vanilla

class SearchControl(vanilla.SearchBox):
    def __init__(self,posSize,text='',callback=None,placeholder=None):
        super().__init__(posSize,text,callback=callback,placeholder=placeholder)
        field=self.getNSSearchField()
        field.setSendsSearchStringImmediately_(True)
        field.setSendsWholeSearchString_(False)
        field.setMaximumRecents_(0)
        field.cell().cancelButtonCell().setAccessibilityLabel_('清除搜索')
    def getNSTextField(self):return self.getNSSearchField()
