from .i18n import message as M,format_message as MF,string_message as ms,render as R
import json
from pathlib import Path
from . import localized_ui as vanilla
from .detail_text import DetailText
from .panel_actions import alert
from . import licensing


def busy():
    from .panel_entry import all_panels
    for p in all_panels():
        if getattr(p,'timer',None) or getattr(p,'preflight_task',None) or getattr(p,'pending_host',None):return True
        w=getattr(p,'recovery_window',None)
        if w is not None and w.getNSWindow() is not None and w.getNSWindow().isVisible():return True
    return False


def refresh_actions(panel,w,recheck=False):
    if recheck:
        try:
            info=licensing.run_helper('info',licensing.LICENSE_PATH)
            w._revocable=not info['deactivated']
        except (ValueError,OSError):w._revocable=False
    w.revoke.enable(bool(getattr(w,'_revocable',False)) and not busy())


def notify():
    from .panel_entry import all_panels
    for p in all_panels():
        if not getattr(p,'_closed',False):p.license_monitor.poll(force=True)


def confirm(panel,parent):
    if busy():alert(M('请先完成或取消导入、预检及恢复任务，再注销授权。'));return
    if panel.raise_dialog(M('确定注销此设备的授权？')):return
    w=panel.dialog((740,420),M('确定注销此设备的授权？'),parent=parent)
    w.body=DetailText((20,20,700,305));w.body.update(M('注销后，本机将无法执行新的导入写入，原授权文件不能直接重新激活。已有工程仍可查看、保存，并可执行必要恢复。\n\n如需换机，请保存注销凭证，并将其与新电脑机器码一并提供给作者办理。\n\n纯离线凭证不能证明授权已彻底销毁；作者将核对原签发记录。'))
    w._working=False
    def commit(sender):
        if w._working or getattr(w,'_batch_disposed',False):return
        if busy():alert(M('请先完成或取消导入、预检及恢复任务，再注销授权。'));return
        w._working=True;w.confirm.enable(False)
        try:licensing.run_helper('deactivate',licensing.LICENSE_PATH)
        except (ValueError,OSError) as exc:
            # If an atomic commit completed before an I/O error, the durable
            # receipt can be recovered from the existing receipt entry point.
            notify();alert(exc);w._working=False;w.confirm.enable(True);return
        panel.finish_dialog(w);notify();show_receipts(panel,parent)
    w.cancel=vanilla.Button((20,-52,180,30),M('取消'),callback=lambda s:panel.finish_dialog(w))
    w.confirm=vanilla.Button((-220,-52,200,30),M('确认注销'),callback=commit)
    w.cancel.getNSButton().setKeyEquivalent_('\r');w.confirm.getNSButton().setKeyEquivalent_('')
    panel.show_dialog(w);w.getNSWindow().setDefaultButtonCell_(w.cancel.getNSButton().cell());w.getNSWindow().makeFirstResponder_(w.cancel.getNSButton())


def show_receipts(panel,parent=None):
    if panel.raise_dialog(M('注销凭证')):return
    try:records=licensing.run_helper('receipts')
    except (ValueError,OSError) as exc:alert(exc);return
    if not records:alert(M('此设备尚无注销凭证。'));return
    w=panel.dialog((760,570),M('注销凭证'),parent=parent)
    w.note=vanilla.TextBox((20,18,720,65),M('凭证已保存在本机用户资料目录，可随时重新查看、复制或导出。请将凭证与新电脑机器码交给作者；它不证明旧机授权已被彻底销毁。'))
    def update(sender=None):w.text.update(json.dumps(records[w.choice.get()],ensure_ascii=False,sort_keys=True,indent=2))
    w.choice=vanilla.PopUpButton((20,90,720,26),[r['body']['licenseID']+' · '+licensing.display_expiry(r['body']['deactivatedAt']) for r in records],callback=update)
    w.text=DetailText((20,126,720,340))
    w.choice.set(len(records)-1);update()
    def copy(sender):
        from AppKit import NSPasteboard,NSPasteboardTypeString
        p=NSPasteboard.generalPasteboard();p.clearContents();p.setString_forType_(w.text.getNSTextView().string(),NSPasteboardTypeString)
    def export(sender):
        from AppKit import NSSavePanel
        if getattr(w,'_batch_owned_sheet',None) is not None:return
        record=records[w.choice.get()]
        save=NSSavePanel.savePanel()
        save.setNameFieldStringValue_('deactivation-'+record['body']['eventID']+'.svgdeactivation')
        def finished(code):
            try:
                if code!=1 or not panel.dialog_alive(w) or getattr(w,'_batch_closing',False):return
                from .model import atomic_json
                atomic_json(Path(ms(save.URL().path())),record)
            except (OSError,ValueError) as exc:
                alert(MF('导出失败，注销凭证仍保存在本机：{detail}',detail=ms(exc)))
            finally:
                save.orderOut_(None)
                if getattr(w,'_batch_owned_sheet',None) is save:
                    w._batch_owned_sheet=None;w._batch_sheet_callback=None
        w._batch_owned_sheet=save;w._batch_sheet_callback=finished
        save.beginSheetModalForWindow_completionHandler_(w.getNSWindow(),finished)
    w.copyReceipt=vanilla.Button((20,-50,180,30),M('复制凭证'),callback=copy)
    w.export=vanilla.Button((215,-50,230,30),M('导出注销凭证…'),callback=export)
    w.done=vanilla.Button((-190,-50,170,30),M('完成'),callback=lambda s:panel.finish_dialog(w))
    panel.show_dialog(w)
