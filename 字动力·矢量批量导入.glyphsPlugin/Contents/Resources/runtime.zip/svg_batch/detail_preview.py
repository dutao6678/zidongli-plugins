"""Local read-only detail canvas. No assignment gestures or host writes."""
import objc
from AppKit import NSView,NSColor,NSBezierPath,NSCommandKeyMask,NSFont,NSFontAttributeName,NSForegroundColorAttributeName
from Foundation import NSString
from .view_zoom import wheel_step

if 'SVGBatchDetailCanvasV2' not in globals():
    class SVGBatchDetailCanvasV2(NSView):
        def isFlipped(self):return True
        def acceptsFirstResponder(self):return True
        def acceptsFirstMouse_(self,event):return True
        @objc.python_method
        def setup(self,owner):
            self.owner=owner;self.asset=None;self.zoom=getattr(owner,'detail_preview_zoom',1.);self.wheel_state=None;self.factor=.2;self.canvas_x=0.
        @objc.python_method
        def fit_frame(self):
            if not getattr(self,'owner',None) or self.enclosingScrollView() is None:return
            clip=self.enclosingScrollView().contentView();size=clip.bounds().size
            self.base_width=max(1.,size.width);self.base_height=max(1.,size.height)
            # Uniform original 1000-unit preview canvas, never ink fitting.
            from .target_fit import view_rect
            self.frame_error=None
            try:self.viewport=view_rect(self.owner,self.asset,getattr(self,'entry',None),full=True)
            except (ValueError,OSError) as exc:self.viewport=(0.,0.,1000.,1000.);self.frame_error=str(exc)
            vx,vy,vw,vh=self.viewport;self.span=vw;self.bottom=vy
            self.factor=max(.001,min((self.base_width-24)/vw,(self.base_height-24)/vh))*self.zoom
            width=max(self.base_width,vw*self.factor+24);height=max(self.base_height,vh*self.factor+24)
            self.setFrameSize_((width,height));self.canvas_x=(width-vw*self.factor)/2
        @objc.python_method
        def change_zoom(self,direction=0,value=None,point=None):
            if not getattr(self,'owner',None):return
            visible=self.visibleRect();old_factor=self.factor
            point=point or (visible.origin.x+visible.size.width/2,visible.origin.y+visible.size.height/2)
            screen=(point[0]-visible.origin.x,point[1]-visible.origin.y)
            anchor=((point[0]-self.canvas_x)/old_factor,(point[1]-12)/old_factor)
            self.zoom=round(max(.5,min(4.,value if value is not None else 1. if not direction else self.zoom+direction*.125)),3)
            self.owner.detail_preview_zoom=self.zoom;self.fit_frame()
            x=self.canvas_x+anchor[0]*self.factor-screen[0];y=12+anchor[1]*self.factor-screen[1]
            self.scrollPoint_((max(0.,min(x,self.bounds().size.width-visible.size.width)),max(0.,min(y,self.bounds().size.height-visible.size.height))))
            self.setNeedsDisplay_(True)
        def mouseDown_(self,event):
            if getattr(self,'owner',None) and self.window():self.window().makeFirstResponder_(self)
        def keyDown_(self,event):
            if not getattr(self,'owner',None):return
            char=str(event.charactersIgnoringModifiers() or '')
            if event.modifierFlags()&NSCommandKeyMask and char in ('+','=','-','0'):
                self.change_zoom(0 if char=='0' else -1 if char=='-' else 1);return
            return objc.super(SVGBatchDetailCanvasV2,self).keyDown_(event)
        def scrollWheel_(self,event):
            if not getattr(self,'owner',None):return
            if event.modifierFlags()&NSCommandKeyMask:
                zoom,self.wheel_state=wheel_step(self.zoom,float(event.scrollingDeltaY()),bool(event.hasPreciseScrollingDeltas()),float(event.timestamp()),self.wheel_state,.5,4.)
                if zoom!=self.zoom:
                    pt=self.convertPoint_fromView_(event.locationInWindow(),None);self.change_zoom(value=zoom,point=(pt.x,pt.y))
                return
            return objc.super(SVGBatchDetailCanvasV2,self).scrollWheel_(event)
        def drawRect_(self,rect):
            if not self.owner:return
            self.fit_frame();NSColor.controlBackgroundColor().set();NSBezierPath.bezierPathWithRect_(self.bounds()).fill()
            x=self.canvas_x;f=self.factor
            if self.frame_error:
                NSString.stringWithString_('目标范围不可用：'+self.frame_error).drawAtPoint_withAttributes_((12,16),{NSFontAttributeName:NSFont.systemFontOfSize_(12)});return
            from .target_fit import view_rect
            vx,vy,vw,vh=self.viewport
            pt=lambda p:(x+(p[0]-vx)*f,12+(vy+vh-p[1])*f)
            rx,ry,rw,rh=view_rect(self.owner,self.asset,getattr(self,'entry',None))
            NSColor.separatorColor().set();outline=NSBezierPath.bezierPathWithRect_((pt((rx,ry+rh)),(rw*f,rh*f)));outline.setLineWidth_(.5);outline.stroke()
            baseline=NSBezierPath.bezierPath();baseline.moveToPoint_(pt((rx,0)));baseline.lineToPoint_(pt((rx+rw,0)));baseline.setLineWidth_(.5);baseline.stroke()
            from .append_preview import existing_path
            old=existing_path(self.owner,getattr(self,'entry',None))
            if old is not None:
                from AppKit import NSAffineTransform
                t=NSAffineTransform.transform();t.setTransformStruct_((f,0.,0.,-f,x-vx*f,12+(vy+vh)*f))
                path=old.copy();path.transformUsingAffineTransform_(t)
                NSColor.secondaryLabelColor().colorWithAlphaComponent_(.55).set();path.fill()
            if not self.asset:return
            try:
                contours=self.owner.geometry(self.asset,getattr(self,'entry',None));path=NSBezierPath.bezierPath()
                for contour in contours:
                    path.moveToPoint_(pt(contour[0][1]))
                    for segment in contour[1:]:
                        if segment[0]=='L':path.lineToPoint_(pt(segment[1]))
                        else:path.curveToPoint_controlPoint1_controlPoint2_(pt(segment[3]),pt(segment[1]),pt(segment[2]))
                    path.closePath()
                NSColor.labelColor().set();path.fill()
            except Exception as exc:
                NSString.stringWithString_('预览不可用：'+str(exc)).drawAtPoint_withAttributes_((12,16),{NSFontAttributeName:NSFont.systemFontOfSize_(12),NSForegroundColorAttributeName:NSColor.secondaryLabelColor()})
