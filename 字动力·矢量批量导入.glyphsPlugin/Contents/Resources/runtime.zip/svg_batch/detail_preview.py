from .i18n import message as M,format_message as MF,string_message as ms,render as R
"""Snapshot-only detail canvas; gestures never query a font or source file."""
import objc
from AppKit import (NSView,NSColor,NSBezierPath,NSCommandKeyMask,NSFont,NSFontAttributeName,
 NSForegroundColorAttributeName,NSAffineTransform,NSCursor,NSWindowDidResignKeyNotification,NSApplicationDidResignActiveNotification)
from Foundation import NSString,NSNotificationCenter
from .view_zoom import wheel_step
from .detail_view import ViewTransform

if 'SVGBatchDetailCanvasV3' not in globals():
    class SVGBatchDetailCanvasV3(NSView):
        def isFlipped(self):return True
        def acceptsFirstResponder(self):return True
        def acceptsFirstMouse_(self,event):return True
        @objc.python_method
        def setup(self,owner):
            self.owner=owner;self.asset=None;self.entry=None;self.view=ViewTransform(getattr(owner,'detail_preview_zoom',1.));self.wheel_state=None
            self.space=False;self.dragging=False;self.drag_start=None;self.zoom_control=None;self.observing=False
            self.error=None;self.reference=None;self.old_path=None;self.new_path=None
        @objc.python_method
        def observe(self):
            if self.observing or self.window() is None:return
            nc=NSNotificationCenter.defaultCenter()
            nc.addObserver_selector_name_object_(self,'clearGesture:',NSWindowDidResignKeyNotification,self.window())
            nc.addObserver_selector_name_object_(self,'clearGesture:',NSApplicationDidResignActiveNotification,None);self.observing=True
        @objc.signature(b'v@:@')
        def clearGesture_(self,notification):self.clear_gesture()
        @objc.python_method
        def clear_gesture(self):
            self.space=False;self.dragging=False;self.drag_start=None
            if self.window():self.window().invalidateCursorRectsForView_(self)
        @objc.python_method
        def retire(self):
            self.clear_gesture()
            if self.observing:NSNotificationCenter.defaultCenter().removeObserver_(self);self.observing=False
            self.zoom_control=None;self.old_path=None;self.new_path=None;self.owner=None
        def resignFirstResponder(self):
            self.clear_gesture();return objc.super(SVGBatchDetailCanvasV3,self).resignFirstResponder()
        def resetCursorRects(self):
            cursor=NSCursor.closedHandCursor() if self.dragging else NSCursor.openHandCursor() if self.space else NSCursor.arrowCursor()
            self.addCursorRect_cursor_(self.bounds(),cursor)
        @objc.python_method
        def snapshot(self,viewport,reference,old,contours,error=None):
            self.view.viewport=viewport;self.reference=reference;self.old_path=old.copy() if old is not None else None;self.error=error
            self.new_path=NSBezierPath.bezierPath()
            for row in contours or []:
                self.new_path.moveToPoint_(row[0][1])
                for seg in row[1:]:
                    if seg[0]=='L':self.new_path.lineToPoint_(seg[1])
                    else:self.new_path.curveToPoint_controlPoint1_controlPoint2_(seg[3],seg[1],seg[2])
                self.new_path.closePath()
            self.setNeedsDisplay_(True)
        @objc.python_method
        def fit_frame(self):
            b=self.bounds().size;self.view.size=(max(1.,b.width),max(1.,b.height))
        @objc.python_method
        def change_zoom(self,direction=0,value=None,point=None):
            if not self.owner:return
            self.fit_frame();self.view.change(value,direction,point);self.wheel_state=None
            self.owner.detail_preview_zoom=self.view.zoom
            if self.zoom_control is not None:self.zoom_control.set(self.view.zoom)
            self.setNeedsDisplay_(True)
        def mouseDown_(self,event):
            if not self.owner or not self.window():return
            self.window().makeFirstResponder_(self)
            if self.space:
                p=self.convertPoint_fromView_(event.locationInWindow(),None);self.fit_frame()
                self.drag_start=((p.x,p.y),self.view.pan);self.dragging=True;NSCursor.closedHandCursor().set()
        def mouseDragged_(self,event):
            if self.dragging and self.drag_start:
                p=self.convertPoint_fromView_(event.locationInWindow(),None);start,pan=self.drag_start
                self.view.drag(pan,(p.x-start[0],p.y-start[1]));self.setNeedsDisplay_(True)
        def mouseUp_(self,event):
            self.dragging=False;self.drag_start=None
            if self.space:NSCursor.openHandCursor().set()
            if self.window():self.window().invalidateCursorRectsForView_(self)
        def keyDown_(self,event):
            if not self.owner:return
            char=ms(event.charactersIgnoringModifiers() or '')
            if char==' ' and not event.modifierFlags()&NSCommandKeyMask:
                self.space=True;NSCursor.openHandCursor().set();self.window().invalidateCursorRectsForView_(self);return
            if event.modifierFlags()&NSCommandKeyMask and char in ('+','=','-','0'):
                self.change_zoom(0 if char=='0' else -1 if char=='-' else 1);return
            return objc.super(SVGBatchDetailCanvasV3,self).keyDown_(event)
        def keyUp_(self,event):
            if ms(event.charactersIgnoringModifiers() or '')==' ':self.clear_gesture();return
            return objc.super(SVGBatchDetailCanvasV3,self).keyUp_(event)
        def scrollWheel_(self,event):
            if not self.owner:return
            if event.modifierFlags()&NSCommandKeyMask:
                z,state=wheel_step(self.view.zoom,float(event.scrollingDeltaY()),bool(event.hasPreciseScrollingDeltas()),float(event.timestamp()),self.wheel_state,.5,4.)
                if z!=self.view.zoom:
                    p=self.convertPoint_fromView_(event.locationInWindow(),None);self.change_zoom(value=z,point=(p.x,p.y))
                self.wheel_state=state;return
            return objc.super(SVGBatchDetailCanvasV3,self).scrollWheel_(event)
        def drawRect_(self,rect):
            if not self.owner:return
            self.fit_frame();NSColor.controlBackgroundColor().set();NSBezierPath.bezierPathWithRect_(self.bounds()).fill()
            if self.error:
                NSString.stringWithString_(R(MF('预览不可用：{detail}',detail=self.error))).drawAtPoint_withAttributes_((12,16),{NSFontAttributeName:NSFont.systemFontOfSize_(12),NSForegroundColorAttributeName:NSColor.secondaryLabelColor()});return
            vx,vy,vw,vh=self.view.viewport;f=self.view.factor;x,y=self.view.origin()
            tr=NSAffineTransform.transform();tr.setTransformStruct_((f,0.,0.,-f,x-vx*f,y+(vy+vh)*f))
            if self.reference:
                rx,ry,rw,rh=self.reference;p=NSBezierPath.bezierPathWithRect_(((rx,ry),(rw,rh)))
                p.moveToPoint_((rx,0));p.lineToPoint_((rx+rw,0));p.transformUsingAffineTransform_(tr);p.setLineWidth_(.5);NSColor.separatorColor().set();p.stroke()
            for path,color in [(self.old_path,NSColor.secondaryLabelColor().colorWithAlphaComponent_(.55)),(self.new_path,NSColor.labelColor())]:
                if path is not None:
                    p=path.copy();p.transformUsingAffineTransform_(tr);color.set();p.fill()
