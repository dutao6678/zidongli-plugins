"""Main-thread, latest-only editor display resizing. No text/model changes."""
import copy,time,weakref
from collections import OrderedDict
from AppKit import NSFont,NSFontAttributeName
from Foundation import NSTimer,NSRunLoop,NSRunLoopCommonModes

class FontRuns:
    """Freeze resolved fonts, not guessed codepoint-to-font mappings."""
    def __init__(self,view,snapshot,hints,issues):
        self.storage=view.textStorage();self.text=str(view.string())
        self.snapshot=copy.deepcopy(snapshot);self.hints=dict(hints);self.issues=copy.deepcopy(issues)
        self.runs=[];self.sizes=OrderedDict();index=0;length=self.storage.length()
        while index<length:
            font,r=self.storage.attribute_atIndex_effectiveRange_(NSFontAttributeName,index,None)
            if font is None:font=view.font() or NSFont.systemFontOfSize_(16)
            end=min(length,r.location+r.length)
            if end<=index:raise ValueError('编辑框字体分段范围无效')
            self.runs.append((index,end-index,font.fontDescriptor()))
            index=end
    def valid(self,view,snapshot,hints):
        return self.storage is view.textStorage() and self.text==str(view.string()) and self.snapshot==snapshot and self.hints==hints
    def apply(self,view,size):
        fonts=self.sizes.get(size)
        if fonts is None:
            # Resolve each descriptor only once for this size, retain exact face.
            unique={};fonts=[]
            for start,length,descriptor in self.runs:
                if descriptor not in unique:unique[descriptor]=NSFont.fontWithDescriptor_size_(descriptor,size)
                if unique[descriptor] is None:raise ValueError('已确认的显示字体无法调整字号：'+str(descriptor.postscriptName()))
                fonts.append(unique[descriptor])
            self.sizes[size]=fonts
            while len(self.sizes)>16:self.sizes.popitem(last=False)
        self.sizes.move_to_end(size)
        self.storage.beginEditing()
        try:
            for (start,length,_),font in zip(self.runs,fonts):self.storage.addAttribute_value_range_(NSFontAttributeName,font,(start,length))
        finally:self.storage.endEditing()
        return copy.deepcopy(self.issues)

class ResizeQueue:
    """One weak-owner timer in common modes; never a queue of stale sizes."""
    interval=1/30
    def __init__(self,panel):
        self.owner=weakref.ref(panel);self.timer=None;self.pending=None;self.last=0.;self.window=None
        self.events=[]
    def request(self,value):
        p=self.owner()
        if p is None or p.table is None:return
        self.pending=value;p.table_text_size=value;self.window=p.table.getNSWindow()
        if self.timer is None:
            ref=weakref.ref(self)
            def tick(timer):
                queue=ref()
                if queue is None:timer.invalidate()
                else:
                    try:queue.tick()
                    except Exception:
                        queue.cancel();raise
            self.timer=NSTimer.timerWithTimeInterval_repeats_block_(self.interval,True,tick)
            NSRunLoop.mainRunLoop().addTimer_forMode_(self.timer,NSRunLoopCommonModes)
        if time.perf_counter()-self.last>=self.interval:self.flush()
    def flush(self):
        p=self.owner()
        if self.pending is None or p is None:return
        if p.w.source.getNSTextView().hasMarkedText():return
        value=self.pending;self.pending=None;p.table_text_size=value
        start=time.perf_counter();p.apply_table_text_size(resize_only=True);self.last=time.perf_counter()
        self.events.append(dict(value=value,start=start,end=self.last));self.events=self.events[-300:]
    def tick(self):
        p=self.owner()
        if p is None or getattr(p,'_closed',False) or p.table is None or p.table.getNSWindow() is not self.window:
            self.cancel();return
        # Read the actual latest native knob value, including its mouse-up value.
        value=round(float(p.table.textSize.get()),1)
        if value!=p.table_text_size:self.pending=value;p.table_text_size=value
        self.flush()
        if not p.table.textSize.getNSSlider().cell().isHighlighted() and self.pending is None:
            self.cancel();p.save_ui_preferences()
    def cancel(self):
        if self.timer is not None:self.timer.invalidate();self.timer=None
        self.pending=None;self.window=None

def cancel_resize(panel):
    queue=getattr(panel,'editor_resize_queue',None)
    if queue is not None:queue.cancel()
