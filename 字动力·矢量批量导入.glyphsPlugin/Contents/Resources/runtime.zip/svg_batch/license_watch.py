from .i18n import message as M,format_message as MF,percent_message as MP,join_message as MJ,string_message as ms,render as R
"""Session-owned main-thread expiry observer; never performs font writes.
Signature checks are cached only for display. HostSession.begin always revalidates.
"""
import time,weakref
from . import licensing

class LicenseMonitor:
    def __init__(self,panel):
        self.panel=weakref.ref(panel);self.timer=None;self.target=None
        self.display_zone=None;self.key=None;self.next_check=0;self.allowed=False;self.message='';self.revision=None
    def start(self,target_class):
        from Foundation import NSTimer,NSRunLoop,NSRunLoopCommonModes
        self.poll(force=True,refresh=False)
        self.target=target_class.alloc().init();self.target.owner=self
        self.timer=NSTimer.timerWithTimeInterval_target_selector_userInfo_repeats_(1,self.target,'tick:',None,True)
        NSRunLoop.mainRunLoop().addTimer_forMode_(self.timer,NSRunLoopCommonModes)
    def stop(self):
        if self.timer:self.timer.invalidate();self.timer=None
        if self.target:self.target.owner=None;self.target=None
    def tick(self,timer):
        p=self.panel()
        if p is None or getattr(p,'_closed',False):self.stop();return
        if p.update_document_context():p.refresh()
        self.poll()
    def poll(self,force=False,refresh=True):
        p=self.panel()
        if p is None:return
        w=getattr(p,'dialog_registry',{}).get(M('授权与激活'))
        if w is not None and hasattr(w,'revoke'):
            from .deactivation_ui import refresh_actions
            refresh_actions(p,w)
        now=time.time()
        # Zone changes affect labels, never validity or the signed grant.
        from datetime import datetime
        zone=datetime.now().astimezone().strftime('%Z %z')
        if zone!=self.display_zone:
            self.display_zone=zone
            w=getattr(p,'dialog_registry',{}).get(M('授权与激活'))
            if w is not None and w.getNSWindow() is not None:w.state.update(licensing.status_text())
        try:s=licensing.LICENSE_PATH.stat();key=(s.st_mtime_ns,s.st_size,s.st_ino)
        except OSError:key=None
        try:d=licensing.DEACTIVATIONS_PATH.stat();key=(key,d.st_mtime_ns,d.st_size,d.st_ino)
        except OSError:key=(key,None)
        if not force and key==self.key and now<self.next_check:return
        self.key=key
        try:
            grant=licensing.require_write_authorization();self.allowed=True;self.message=''
            end=grant.get('expiresAt');self.next_check=min(now+30,end) if end else now+30
            revision=(True,grant['licenseID'])
        except ValueError as exc:
            self.allowed=False;self.message=MF('{detail}；查看、保存和恢复仍可使用。',detail=ms(exc))
            grant=getattr(exc,'grant',None);revision=(False,ms(exc),grant.get('licenseID') if grant else None)
            self.next_check=now+30
        if force or revision!=self.revision:
            self.revision=revision
            w=getattr(p,'dialog_registry',{}).get(M('授权与激活'))
            if w is not None and w.getNSWindow() is not None:
                w.state.update(licensing.status_text())
                if hasattr(w,'revoke'):
                    from .deactivation_ui import refresh_actions
                    refresh_actions(p,w,recheck=True)
            # A single persistent, non-modal notice per transition; no repeat alerts.
            if refresh and not getattr(p,'_closed',False):p.refresh()
