from .i18n import message as M,format_message as MF,percent_message as MP,join_message as MJ,string_message as ms,render as R
"""Main-thread display snapshots, invalidated by full refresh, never by selection/resize."""
from collections import OrderedDict
from AppKit import NSBezierPath
from .preview_reference import reference


def data(panel,cell,aid):
    cache=getattr(panel,'render_cache',None)
    if cache is None:cache=panel.render_cache=OrderedDict()
    entry=cell.get('entry');key=(entry['id'] if entry else None,aid)
    if key in cache:
        cache.move_to_end(key);return cache[key]
    result=dict(frame=None,frame_error=None,path=None,existing_path=None,existing_visible=False,error=None,header={},status='')
    if entry:
        try:result['frame']=reference(panel,aid,entry)
        except (ValueError,OSError) as exc:result['frame_error']=ms(exc)
    if entry and (not aid or panel.project.state['settings']['existing']=='append'):
        try:
            from .append_preview import existing_path
            result['existing_path']=existing_path(panel,entry,host_only=not aid)
            path=result['existing_path']
            result['existing_visible']=path is not None and not path.isEmpty()
        except Exception as exc:result['error']=MF('已有内容预览失败：{detail}',detail=ms(exc))
    if aid:
        try:
            contours=panel.geometry(aid,entry);path=NSBezierPath.bezierPath()
            for contour in contours:
                path.moveToPoint_(contour[0][1])
                for segment in contour[1:]:
                    if segment[0]=='L':path.lineToPoint_(segment[1])
                    else:path.curveToPoint_controlPoint1_controlPoint2_(segment[3],segment[1],segment[2])
                path.closePath()
            result['path']=path
        except Exception as exc:
            result['error']=ms(exc)
            from .preview_lookup import PreviewPending
            result['pending']=isinstance(exc,PreviewPending)
            if not result['pending']:panel.errors[aid]=ms(exc)
    # Re-evaluate after successful geometry has cleared any previous failure.
    from .diagnostics import preview_records,badge
    result['status']=panel.cell_status(entry) if entry else ''
    result['diagnostics']=[] if result.get('pending') else preview_records(panel,entry,aid,result['frame'],locals().get('contours'),result['error'] or result['frame_error'],result['status'])
    result['diagnostic_badge']=badge(result['diagnostics'])
    if result['frame'] is None:
        from .native_import import preview_frame
        result['fallback']=preview_frame(panel)
    cache[key]=result
    while len(cache)>256:cache.popitem(last=False)
    return result
