from .i18n import message as M,format_message as MF,percent_message as MP,join_message as MJ,string_message as ms,render as R
"""Cancelable staged PDF intake. Workers see only files/frozen values, never UI/GS."""
import copy,queue,threading,time,traceback
from pathlib import Path
from Foundation import NSObject,NSTimer
from . import localized_ui as vanilla
from .model import natural_key,digest,states_equal
from .pdf_pages import reader,select_pages,name,cached_page
from .pdf_materials import worker

class SVGBatchPDFIntakeTickV1(NSObject):
    def tick_(self,timer):
        if self.owner is not None:self.owner.pdf_intake_step()
        else:timer.invalidate()

class PDFMaterialUI:
    def has_pdf_files(self,paths):
        return any(Path(p).suffix.lower()=='.pdf' or Path(p).is_dir() and any(f.suffix.lower()=='.pdf' for f in Path(p).iterdir() if f.is_file()) for p in paths)
    def cancel_pdf_intake(self):
        task=getattr(self,'pdf_intake',None)
        if task:task['cancel'].set()
        timer=getattr(self,'pdf_intake_timer',None)
        if timer:timer.invalidate()
        target=getattr(self,'pdf_intake_tick',None)
        if target:target.owner=None
        self.pdf_intake=None;self.pdf_intake_timer=None;self.pdf_intake_tick=None

    def intake_files(self,paths,start=None):
        def action():
            if getattr(self,'pdf_intake',None):raise ValueError(M('正在读取材料；请先采用或取消'))
            if self.timer or self.source_task or self.drop_draft or self.gestures.active or self.gestures.pending:raise ValueError(M('请先完成当前读取、排布或导入任务'))
            expanded=[]
            for path in paths:
                p=Path(path).resolve()
                expanded.extend(sorted((f for f in p.iterdir() if f.is_file() and f.suffix.lower() in ('.svg','.eps','.pdf')),key=natural_key) if p.is_dir() else [p])
            expanded=sorted(set(p for p in expanded if p.suffix.lower() in ('.svg','.eps','.pdf')),key=natural_key)
            if not expanded:return
            w=self.dialog((760,520),M('读取矢量文件'))
            task=dict(before=copy.deepcopy(self.project.state),project=self.project,paths=[ms(p) for p in expanded],start=start,cancel=threading.Event(),queue=queue.Queue(),ranges={},records=None,window=w,started=time.perf_counter())
            self.pdf_intake=task
            w.caption=vanilla.TextBox((20,18,720,48),M('正在读取PDF页数…；一页一字、一页一份素材，不识别或拆分页面中的文字。'))
            w.files=vanilla.PopUpButton((20,76,320,25),[M('正在读取…')],callback=self.pdf_choose_file)
            w.range=vanilla.EditText((355,76,240,25),M('全部'),callback=self.pdf_range_changed)
            w.scan=vanilla.Button((610,76,130,25),M('读取预览'),callback=self.pdf_scan)
            w.rows=vanilla.List((20,118,720,315),[],columnDescriptions=[dict(title=M('文件／原始页码'),key='name',width=330),dict(title=M('状态（不跳过问题页）'),key='status')])
            w.cancel=vanilla.Button((20,465,150,30),M('取消'),callback=lambda s:self.pdf_cancel_window())
            w.adopt=vanilla.Button((520,465,220,30),M('采用所选页面'),callback=self.pdf_adopt)
            w.adopt.enable(False);w.scan.enable(False);w.range.enable(False);w.files.enable(False)
            self.show_dialog(w)
            self.pdf_intake_tick=SVGBatchPDFIntakeTickV1.alloc().init();self.pdf_intake_tick.owner=self
            self.pdf_intake_timer=NSTimer.scheduledTimerWithTimeInterval_target_selector_userInfo_repeats_(.04,self.pdf_intake_tick,'tick:',None,True)
            self.pdf_worker(None)
        self.guard(action)

    def pdf_worker(self,ranges):
        t=self.pdf_intake;t['records']=None;t['busy']=True
        threading.Thread(target=worker,args=(tuple(t['paths']),copy.deepcopy(ranges),t['cancel'],t['queue']),daemon=True).start()

    def pdf_cancel_window(self):
        t=getattr(self,'pdf_intake',None)
        if not t:return
        w=t['window'];self.cancel_pdf_intake();self.finish_dialog(w);self.refresh()

    def pdf_choose_file(self,s):
        t=self.pdf_intake;t['window'].range.set(t['ranges'][t['pdfs'][s.get()]['path']])

    def pdf_range_changed(self,s):
        t=getattr(self,'pdf_intake',None)
        if not t or not t.get('pdfs'):return
        t['ranges'][t['pdfs'][t['window'].files.get()]['path']]=s.get()
        t['records']=None;t['window'].adopt.enable(False)

    def pdf_scan(self,s=None):
        def action():
            t=self.pdf_intake
            if t['busy']:return
            for f in t['pdfs']:select_pages(t['ranges'][f['path']],f['total'])
            t['window'].adopt.enable(False);t['window'].scan.enable(False);t['window'].range.enable(False);t['window'].files.enable(False)
            self.pdf_worker(t['ranges'])
        self.guard(action)

    def pdf_intake_step(self):
        t=getattr(self,'pdf_intake',None)
        if not t:return
        if getattr(self,'_closed',False):self.cancel_pdf_intake();return
        try:
            latest=None
            while True:
                try:kind,data=t['queue'].get_nowait()
                except queue.Empty:break
                if kind=='progress':latest=data;continue
                t['busy']=False
                if kind=='error':raise ValueError(data)
                if kind=='catalog':
                    t['catalog']=data;t['pdfs']=[f for f in data if f['total']>1]
                    t['ranges']={f['path']:M('全部') for f in t['pdfs']}
                    if not t['pdfs']:self.pdf_worker({});continue
                    w=t['window'];w.files.setItems([f['name']+MP(M('（%d页）'),f['total']) for f in t['pdfs']]);w.files.set(0)
                    w.caption.set(M('一页一份素材；默认全部页。可输入 1–20、25、30–40；采用后按原始页序。\n先读取预览；空白/图片/不支持页保留位置，可修改页码明确排除。'))
                    w.files.enable(True);w.range.enable(True);w.scan.enable(True);latest=None
                elif kind=='ready':
                    t['records']=data;w=t['window']
                    w.rows.set([dict(name=r['material']['name'],status=r['error'] or M('可读取（采用后按当前方式生成候选）')) for r in data])
                    w.caption.set(MP(M('共%d份素材；问题页%d份仍保留原位。可修改页码并重新预览以明确排除。\n取消不改变工程；采用仅加载素材，不写字体。'),(len(data),sum(bool(r['error']) for r in data))))
                    w.range.enable(bool(t['pdfs']));w.files.enable(bool(t['pdfs']));w.scan.enable(bool(t['pdfs']));w.adopt.enable(bool(data));latest=None
                    if not t['pdfs']:self.pdf_adopt(None);return
            if latest and t.get('busy'):t['window'].caption.set(MF('{latest}；可取消，不写字体。',latest=latest))
        except Exception as exc:
            traceback.print_exc();t['window'].caption.set(MF('读取失败：{detail}；原工程保持不变。',detail=ms(exc)));t['window'].adopt.enable(False);t['busy']=False

    def pdf_adopt(self,s):
        def action():
            t=self.pdf_intake
            if t['busy'] or t['records'] is None:raise ValueError(M('请先完成读取预览'))
            if t['project'] is not self.project or not states_equal(t['before'],self.project.state):raise ValueError(M('读取期间工程已变化，请取消后重新读取'))
            for r in t['records']:
                p=Path(r['material']['path']);stat=p.stat()
                if (stat.st_mtime_ns,stat.st_size)!=tuple(r['stamp']):raise ValueError(MF('{name}已变化；请重新读取',name=p.name))
            records=t['records'];start=t['start'];w=t['window']
            self.project.add_materials([r['material'] for r in records])
            if not hasattr(self,'pdf_sources'):self.pdf_sources={}
            aids=[]
            for r in records:
                m=r['material'];aid=next(a for a,v in self.project.state['assets'].items() if (v['path'],v.get('pdf_page'))==(m['path'],m.get('pdf_page')))
                aids.append(aid)
                if r['source'] is not None:
                    self.pdf_sources[(m['path'],m['sha256'],m.get('pdf_page'),*r['stamp'])]=r['source']
                if r['error']:self.errors[aid]=r['error']
            self.cancel_pdf_intake();self.finish_dialog(w);self.refresh()
            if start is not None:
                from .drop import direct_proposal
                proposal,rows,extent=direct_proposal(self.project,aids,start,visible_order=aids)
                self.present_drop_preview(start,proposal,rows,extent)
            elif self.project.state['entries'] and not self.project.state['assignments']:self.map(None)
        self.guard(action)
