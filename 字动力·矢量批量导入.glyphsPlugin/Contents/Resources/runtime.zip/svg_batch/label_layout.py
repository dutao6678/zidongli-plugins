"""Presentation-only header positions; reserve the target index on the first row."""
def header_layout(width,label_width,code_width,name_label=False):
    label_room=max(0,width-47)
    shown_label=min(label_width,label_room)
    inline_x=12+shown_label+7
    inline_room=max(0,width-35-inline_x)
    second_row=name_label or code_width>inline_room
    return dict(label_width=label_room,code_x=12 if second_row else inline_x,
                code_y=31 if second_row else 13,
                code_width=max(0,width-24) if second_row else inline_room,
                second_row=second_row)
