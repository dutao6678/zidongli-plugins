"""Incremental main-thread host reads, adopted through existing entry transactions."""
import copy,time,traceback
from Foundation import NSObject,NSTimer
from GlyphsApp import Glyphs
from .host_targets import capture,record,resolve_binding,registered_font,same_object,prune_sessions
from .native_collections import native_items
from .model import states_equal
from .panel_actions import alert

if 'SVGBatchHostReadTickV1' not in globals():
    class SVGBatchHostReadTickV1(NSObject):
        def tick_(self,timer):
            if self.owner is not None:self.owner.host_read_step()
            else:timer.invalidate()

class HostSourceUI:
    def cancel_host_read(self,message=None):
        timer=getattr(self,'source_timer',None)
        if timer:timer.invalidate()
        target=getattr(self,'source_tick',None)
        if target:target.owner=None
        self.source_timer=None;self.source_tick=None;self.source_task=None
        if message:self.result_message=message

    def read_current_glyphs(self,s=None,automatic=False):
        if automatic:return  # Retired automatic entry point: never scan an empty session.
        def action():
            if getattr(self,'pdf_intake',None):raise ValueError('正在读取材料，请先采用或取消')
            if getattr(self,'source_task',None):return
            if automatic and (self.project.state.get('target_list_initialized') or self.project.state['entries'] or self.project.state['assets'] or self.project_path or self.host):return
            if self.gestures.active or self.gestures.pending or self.drop_draft:raise ValueError('请先采用或取消当前素材排布预览')
            font=getattr(Glyphs,'font',None)
            if font is None:
                if not automatic:alert('当前没有打开的字体。可先粘贴文字或选择外部字表文件。')
                return
            prune_sessions(native_items(Glyphs.fonts));task=capture(font)
            task.update(before=copy.deepcopy(self.project.state),records=[],cursor=0,automatic=automatic,ticks=0,max_chunk=0.,started=time.perf_counter())
            task['old']={(b['font_session'],b['glyph_token'],b['master_id']):e for e in task['before']['entries'] if (b:=e.get('host_binding'))}
            self.source_task=task;self.source_tick=SVGBatchHostReadTickV1.alloc().init();self.source_tick.owner=self
            self.source_timer=NSTimer.scheduledTimerWithTimeInterval_target_selector_userInfo_repeats_(.01,self.source_tick,'tick:',None,True)
            self.main.status.set('正在读取%s · 0/%d；Esc取消，不会写字体'%('当前选区' if task['selection'] else '当前字体',len(task['glyphs'])))
        self.guard(action)

    def host_read_step(self):
        task=getattr(self,'source_task',None)
        if not task:return
        try:
            if getattr(self,'_closed',False):self.cancel_host_read();return
            if self.timer:self.cancel_host_read('导入已开始，读取已取消；写入沿用原预检目标。');self.refresh();return
            font=task['font']
            if not same_object(getattr(Glyphs,'font',None),font) or not any(same_object(font,f) for f in native_items(Glyphs.fonts)):
                raise ValueError('读取期间目标文档已切换或关闭；原校对工程保持不变')
            if not states_equal(task['before'],self.project.state):raise ValueError('读取期间校对工程已改变；已取消读取，保留当前内容')
            start=time.perf_counter();steps=0
            while task['cursor']<len(task['glyphs']) and steps<128 and time.perf_counter()-start<.012:
                position,glyph=task['glyphs'][task['cursor']]
                task['records'].append(record(font,glyph,task['master_id'],position,task['old']))
                task['cursor']+=1;steps+=1
            task['ticks']+=1;task['max_chunk']=max(task['max_chunk'],time.perf_counter()-start)
            self.main.status.set('正在读取目标 · %d/%d；Esc取消'%(task['cursor'],len(task['glyphs'])))
            if task['cursor']<len(task['glyphs']):return
            self.source_timer.invalidate();self.source_timer=None
            self.source_tick.owner=None;self.source_tick=None
            current={str(g.id):g for g in native_items(font.glyphs)}
            if any(str(g.id) not in current or not same_object(current[str(g.id)],g) for _,g in task['glyphs']):raise ValueError('读取期间字形被删除或替换；请重新读取')
            if not any(str(m.id)==task['master_id'] for m in native_items(font.masters)):raise ValueError('读取期间目标母版已变化')
            self.last_host_read_stats=dict(count=len(task['records']),ticks=task['ticks'],max_chunk=task['max_chunk'],seconds=time.perf_counter()-task['started'])
            records=task['records'];mode='当前选区' if task['selection'] else '当前字体'
            description=mode+'；按字体内顺序读取，未取得可验证的视图排序，不按点击或Unicode重排。'
            if not task['automatic']:
                binding=self.w.binding.getItems()[self.w.binding.get()]
                if not alert('%s · %d个目标\n%s\n无编码 %d 项；目标母版：%s\n%s；未保留的素材退回待分配，不删除源文件。\n是否采用？'%(mode,len(records),description,sum(not e['host_binding']['unicodes'] for e in records),task['master_name'],binding),True):
                    self.cancel_host_read('已取消读取；原工程保持不变');self.refresh();return
                if not states_equal(task['before'],self.project.state):raise ValueError('确认期间校对工程已变化，请重新读取')
            if not same_object(getattr(Glyphs,'font',None),font) or not any(same_object(font,f) for f in native_items(Glyphs.fonts)):raise ValueError('确认期间目标字体已变化；原校对工程保持不变')
            if not any(str(m.id)==task['master_id'] for m in native_items(font.masters)):raise ValueError('确认期间母版已变化；原校对工程保持不变')
            source=dict(kind='glyphs-selection' if task['selection'] else 'glyphs-font',label=mode,ordering='font-order',description=description,font_session=task['font_session'])
            target=dict(font_path=str(font.filepath),family=str(font.familyName),master_id=task['master_id'],master_name=task['master_name'])
            self.project.replace_entries(records,'identity' if task['automatic'] or self.w.binding.get()==0 else 'position',target_source=source,target=target)
            self.locked_font=font;self.locked_master=task['master_id']
            if task['automatic']:self.saved_state=copy.deepcopy(self.project.state)
            self.cancel_host_read(mode+'读取完成；使用字体内顺序，写入前将重新核验字形绑定。');self.refresh()
        except Exception as exc:
            traceback.print_exc();self.cancel_host_read(str(exc));self.refresh();alert(exc)

    def restore_bound_target(self):
        records=[e for e in self.project.state['entries'] if e.get('host_binding')]
        if not records:return
        font=registered_font(records[0]);master=self.project.state.get('target',{}).get('master_id')
        prune_sessions(native_items(Glyphs.fonts))
        if font is None or not any(same_object(font,f) for f in native_items(Glyphs.fonts)):
            self.locked_font=None;self.locked_master=None;self.result_message='原宿主绑定无法可靠恢复；请从当前 Glyphs 字体重新读取并确认对应。';return
        # Validate membership once; do not rasterise any reference glyphs.
        glyphs={str(g.id):g for g in native_items(font.glyphs)}
        try:
            for entry in records:resolve_binding(entry,font,master,glyphs)
        except ValueError as exc:
            self.locked_font=None;self.locked_master=None;self.result_message=str(exc);return
        self.locked_font=font;self.locked_master=master
