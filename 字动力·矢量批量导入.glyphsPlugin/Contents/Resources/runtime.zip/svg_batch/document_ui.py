from .i18n import message as M,format_message as MF,percent_message as MP,join_message as MJ,string_message as ms,render as R
"""On-demand reading options; source installation never edits Project state."""
from pathlib import Path
import copy
from . import localized_ui as vanilla
from .document_reader import read_book,extract_book,column_name
from .panel_actions import choose,alert

class DocumentUI:
    def load_table_file(self,s=None):
        self.open_table()
        paths=choose(types=['txt','csv','xlsx','docx','pdf','doc','xls'])
        if not paths:return
        if len(paths)!=1:alert(M('请一次选择一个字表文件；原字表保持不变'));return
        self.guard(lambda:self.prepare_document(paths[0]))
    def prepare_document(self,path):
        if self.raise_dialog(M('读取字表文件')):return
        encoding=['utf-8-sig','utf-16','gb18030','big5'][self.w.encoding.get()]
        book=read_book(path,encoding)
        if book['kind']=='txt':self.install_document(extract_book(book));return
        self.read_book=book;w=self.read_options=self.dialog((760,520),M('读取字表文件'),parent=self.table)
        w.caption=vanilla.TextBox((20,18,720,45),MF('{name}\n读取后进入字表整理，预览确认前保留现有字表与素材对应。',name=Path(path).name))
        kind=book['kind'];self.read_encoding=encoding
        if kind in ('csv','xlsx'):
            w.sheetLabel=vanilla.TextBox((20,76,100,20),M('工作表') if kind=='xlsx' else M('分隔符'))
            w.sheet=vanilla.PopUpButton((130,72,340,25),[sh['name']+(M('（隐藏）') if sh.get('hidden') else '') for sh in book['sheets']] if kind=='xlsx' else [M('逗号 ,'),'Tab',M('分号 ;'),M('竖线 |')],callback=self.document_sheet_changed)
            if kind=='csv':w.sheet.set([',','\t',';','|'].index(book['delimiter']))
            w.charLabel=vanilla.TextBox((20,118,100,20),M('字符列'))
            w.character=vanilla.PopUpButton((130,114,180,25),[])
            w.codeLabel=vanilla.TextBox((340,118,110,20),M('Unicode编码列'))
            w.code=vanilla.PopUpButton((460,114,280,25),[])
            w.rangeLabel=vanilla.TextBox((20,160,100,20),M('读取记录范围'))
            w.rows=vanilla.EditText((130,156,180,25),'1-',placeholder='1-20')
            w.header=vanilla.CheckBox((340,156,390,25),M('范围首条是标题（明确排除）'),value=False)
            w.hidden=vanilla.CheckBox((20,196,690,25),M('包含隐藏行列（取消后明确排除隐藏行列）'),value=True)
            w.hidden.show(kind=='xlsx')
            self.document_columns()
        elif kind=='docx':
            w.sectionLabel=vanilla.TextBox((20,80,100,20),M('读取内容'))
            w.section=vanilla.PopUpButton((130,76,420,25),[M('正文和表格（按原顺序）'),M('仅正文'),M('仅表格')],callback=lambda s:self.document_sample())
            w.rangeLabel=vanilla.TextBox((20,124,100,20),M('内容记录范围'))
            w.rows=vanilla.EditText((130,120,260,25),'1-',placeholder=M('按下方记录序号选择'))
            w.tableLabel=vanilla.TextBox((20,168,100,20),M('表格读取'))
            w.tableMode=vanilla.PopUpButton((130,164,420,25),[M('自动判别（有歧义先提示）'),M('每单元格一个位置（多字先提示）'),M('每行字符＋编码双列')])
        else:
            w.pageLabel=vanilla.TextBox((20,80,100,20),M('页码范围'))
            w.pages=vanilla.EditText((130,76,320,25),'1-',placeholder='1-3,5')
            w.pagesNote=vanilla.TextBox((20,120,720,66),MP(M('共%d页。多栏/表格的提取顺序须核对；不执行OCR。\n无文本页：%s'),(len(book['pages']),MJ(',',(ms(i+1) for i,t in enumerate(book['pages']) if not t.strip())) or M('无'))))
        w.sample=vanilla.TextEditor((20,242,720,175),'',readOnly=True)
        w.sample.getNSTextView().setEditable_(False)
        w.cancel=vanilla.Button((20,456,130,30),M('取消'),callback=lambda s:self.finish_dialog(w))
        w.read=vanilla.Button((490,456,250,30),M('读取到字表整理'),callback=self.confirm_document_read)
        self.document_sample();self.show_dialog(w)
    def document_columns(self):
        w=self.read_options;book=self.read_book;sh=book['sheets'][w.sheet.get() if book['kind']=='xlsx' else 0]
        count=sh['columns'];labels=[MF('{detail}列',detail=column_name(i)) if book['kind']=='xlsx' else MP(M('第%d列'),i+1) for i in range(count)]
        w.character.setItems(labels);w.character.set(0);w.code.setItems([M('不读取编码列')]+labels);w.code.set(0)
    def document_sheet_changed(self,s):
        def action():
            if self.read_book['kind']=='csv':
                previous=self.read_book
                try:self.read_book=read_book(previous['path'],self.read_encoding,[',','\t',';','|'][self.read_options.sheet.get()])
                except ValueError:
                    self.read_options.sheet.set([',','\t',';','|'].index(previous['delimiter']));raise
            self.document_columns();self.document_sample()
        self.guard(action)
    def document_sample(self):
        book=self.read_book;w=self.read_options;kind=book['kind']
        if kind in ('csv','xlsx'):
            sh=book['sheets'][w.sheet.get() if kind=='xlsx' else 0]
            rows=[]
            for r in sh['rows'][:12]:
                cells=r.get('values') if kind=='csv' else [r['cells'].get(i,'') for i in range(min(sh['columns'],8))]
                rows.append(MP('%d · %s  %s',(r['number'],r['location'],MJ(' | ',cells[:8]))))
            suffix=M('\n字符列每条记录为一个位置；空单元格保留，多字不会自动展开。')
            if kind=='xlsx':suffix+=M('\n按原始单元格值读取，不套用日期/数字显示格式；公式只用已保存缓存值。')
            if kind=='csv' and book['ambiguous']:suffix+=M('\n分隔符未能明确识别，请手动选择并核对。')
            if book.get('parse_error'):suffix+=MF('\n尚未读取成功：{parse_error}',parse_error=book['parse_error'])
        elif kind=='docx':
            section=['all','body','table'][w.section.get()];rs=[r for r in book['rows'] if section=='all' or r['section']==section]
            rows=[MP('%d · %s  %s',(i+1,r['location'],r['text'])) for i,r in enumerate(rs[:12])];suffix='\n'+ MJ('\n',book['warnings'])
        else:rows=[MP(M('第%d页：%s'),(i+1,t[:180].replace('\n',' | ') or M('（无可提取文本）'))) for i,t in enumerate(book['pages'][:8])];suffix=M('\n页码范围读取后仍须在整理窗口预览并核对顺序。')
        w.sample.set(MJ('\n',rows)+suffix)
    def confirm_document_read(self,s):
        def action():
            book=self.read_book;kind=book['kind'];w=self.read_options
            if kind in ('csv','xlsx'):
                result=extract_book(book,sheet=w.sheet.get() if kind=='xlsx' else 0,char_column=w.character.get(),code_column=w.code.get()-1 if w.code.get() else None,rows=w.rows.get(),header=w.header.get(),include_hidden=w.hidden.get())
            elif kind=='docx':result=extract_book(book,section=['all','body','table'][w.section.get()],rows=w.rows.get(),table_mode=['auto','cells','records'][w.tableMode.get()])
            else:result=extract_book(book,pages=w.pages.get())
            if result['warnings'] and not alert(MF('{detail}\n\n只读取所选内容到整理窗口？取消会保留原内容。',detail=MJ('\n',result['warnings'])),True):return
            self.install_document(result);self.finish_dialog(w)
        self.guard(action)
    def install_document(self,result):
        # Prepare fully before changing even the editable source buffer.
        text=result['text'];locations=list(result['locations'])
        self.set_source(text,result['path']);self.document_source=dict(kind=result['kind'],text=text,path=result['path'],locations=locations,columns=result['columns'],mode=result['mode'])
        self.w.range.set('1-');self.w.readmode.set(['continuous','items','records','auto'].index(result['mode']))
        self.w.recordcolumns.set(1 if result['columns'] else 0)
    def attach_document_sources(self,raw,entries):
        doc=getattr(self,'document_source',None)
        if not doc:return
        original=doc['text'].split('\n');current=raw.split('\n');exact=raw==doc['text']
        lookup={}
        if not exact:
            for line,location in zip(original,doc['locations']):lookup.setdefault(line,[]).append(location)
        for e in entries:
            if e.get('code_record',{}).get('alternating'):
                record=e['code_record'];refs=[]
                for n in e['source_lines']:
                    if exact and 0<=n-1<len(doc['locations']):loc=doc['locations'][n-1]
                    else:loc=MP(M('编辑后第%d行'),n)
                    refs.append(MP('%s（%s）',(loc,M('字符') if n==record.get('character_line') else M('编码') if n==record.get('encoding_line') else M('缺项'))))
                e['source']=doc['path'];e['source_location']=MJ(' ↔ ',refs)
                continue
            i=e['line']-1
            if exact and i<len(doc['locations']):
                e['source_location']=doc['locations'][i];e['source']=doc['path']
                # Explicit spreadsheet cells are literal values, unlike padded
                # fields in a pasted space-delimited record. Never trim a cell.
                record=e.get('code_record')
                if record and (doc.get('columns') or doc.get('kind')=='docx' and doc['locations'][i].startswith(M('表')) and record.get('character_column') is not None):
                    fields=original[i].split('\t');ci=0 if doc.get('columns') else record.get('character_column',1)-1
                    if not 0<=ci<len(fields):continue
                    value=fields[ci];e['value']=value;record['character']=value
                    if value and record.get('code_point') is not None and record.get('error','').startswith(M('缺少字符')):record['error']=''
            elif i<len(current):
                candidates=lookup.get(current[i],[])
                e['source']=doc['path'];e['source_location']=(MF('编辑后可能来源：{detail}{detail_2}',detail=MJ(' / ',candidates[:5]),detail_2=MP(M(' 等%d处'),len(candidates)) if len(candidates)>5 else '')) if candidates else MP(M('编辑新增/修改的第%d行'),i+1)
