"""Fresh, structured presentation diagnostics; never changes import eligibility.

The same curve extrema and frame comparison feed cards, details and preflight.
No diagnostic is inferred from artwork appearance or persisted as project data.
"""
from .i18n import message as M,format_message as MF,join_message as MJ,string_message as ms
from .outline_bounds import contour_bounds


def record(code,severity,label,reason,impact,action,blocks=False,**evidence):
    return dict(code=code,severity=severity,label=label,reason=reason,impact=impact,action=action,blocks=blocks,evidence=evidence)


def frame_records(contours,width,descender,ascender,bounds=None):
    bounds=bounds if bounds is not None else contour_bounds(contours) if contours is not None else None
    if bounds is None:return []
    left,bottom,right,top=bounds;epsilon=1e-7
    sides=[]
    for code,amount,label in [('left',-left,M('左侧超框')),('right',right-width,M('右侧超框')),('bottom',descender-bottom,M('下方超框')),('top',top-ascender,M('上方超框'))]:
        if amount>epsilon:sides.append(dict(side=code,amount=amount,label=label))
    if not sides:return []
    amounts=MJ('；',(MF('{side} {amount} 单位',side=s['label'],amount=format(s['amount'],'.6g')) for s in sides))
    return [record('geometry.outside','info',sides[0]['label'] if len(sides)==1 else M('轮廓超框'),
        MF('轮廓 X {left} → {right}、Y {bottom} → {top}；预计字格 X 0 → {width}、Y {descender} → {ascender}。{amounts}',left=format(left,'.6g'),right=format(right,'.6g'),bottom=format(bottom,'.6g'),top=format(top,'.6g'),width=format(width,'.6g'),descender=format(descender,'.6g'),ascender=format(ascender,'.6g'),amounts=amounts),
        M('轮廓不裁切，预览和正式写入保留相同坐标；超框本身不阻止写入，其他预检仍适用。'),
        M('无需处理；仅供按需查看。按当前模式及参数原样导入，不因越界自动裁切、缩放或移动轮廓。'),bounds=bounds,frame=(0.,descender,width,ascender),sides=sides)]


def source_records(source,settings):
    if not source:return []
    rows=[]
    if source.get('stroke_expanded'):
        rows.append(record('source.stroke_expanded','info',M('描边已展开'),M('当前描边已在临时副本中按线宽、端帽、转角和虚线设置展开为填充轮廓；源文件不变。'),M('预览与正式写入使用同一份展开结果；不保留中心线编辑形式，不自动合并或纠正字形。'),M('无需额外操作；可在详情核对可见轮廓，复杂且不能等价转换的特性会明确报错。')))
    if source.get('pdf_editor_metadata'):
        rows.append(record('pdf.editor_metadata','info',M('编辑元数据已排除'),
            M('该PDF页包含私有编辑元数据；插件仅使用页面绘制内容，原文件不变。'),
            M('这是已完成的自动处理，不额外改变页面矢量轮廓、坐标或尺寸，也不阻止导入。'),
            M('无需额外操作；继续按页面预览核对素材。')))
    images=source.get('resources',{}).get('images',0)
    if images:
        rows.append(record('pdf.images','warning',M('图片不导入'),MF('该PDF页检测到 {count} 个图片资源；原生接口只提供可导入的矢量轮廓。',count=images),
            M('图片不会出现在预览或字体轮廓中，也不会自动描摹；混合页的有效矢量仍可导入。'),
            M('若图片属于字形内容，请先在源文件中改为矢量；仅需现有矢量时，核对预览后可继续。'),images=images))
    if source.get('format')=='EPS' and source.get('warnings_note'):
        rows.append(record('eps.source_box','info',M('EPS源范围说明'),source['warnings_note'],
            M('当前使用文件声明的有效包围框；不能据此证明原始画板留白是否保留。此说明不阻止导入。'),
            M('位置符合预期时无需操作；仅在需要恢复完整画布留白时，使用高级设置中的自定源画布范围。'),source_box=source.get('source_box')))
    return rows


def status_records(status,error=None,display_warning=None):
    raw=ms(error or display_warning or status or '')
    if not raw or raw in (M('已分配'),M('可用'),M('缺字稿'),M('缺稿'),M('空位')):return []
    display=not error and bool(display_warning or M('显示字体') in raw or M('显示缺字') in raw)
    if display:
        return [record('display.font','warning',M('显示缺字'),raw,
            M('仅影响目标文字的显示；不改变目标编码或素材轮廓，是否可写入由目标绑定及预检决定。'),
            M('恢复来源显示字体或重新读取来源；不要根据替代显示字形猜测编码。'))]
    if M('重复') in raw:
        return [record('entry.duplicate','warning',M('重复目标'),raw,M('重复目标中只能选择一个版本写入；多个已分配位置指向同一字形时，预检会阻止写入。'),M('核对重复目标，只给本次需要的一个版本分配素材；其他版本可保留为空目标。'))]
    if any(word in raw for word in (M('编码'),M('Unicode'),M('格式'),'配对','多字',M('多码点'),'组合')):
        action=M('在字表整理中核对原记录和读取方式，或在详情修改目标字符／编码；使用当前支持的单个目标。')
    elif any(word in raw for word in ('宿主','绑定','母版',M('目标'),M('字宽'))):
        action=M('核对所属字体、母版和目标图层；绑定失效时通过“文件 → 重新关联当前字体…”重新核对。')
    else:
        action=M('按具体错误核对源文件及当前导入设置，重新读取后再预检；仍失败时保留文件和诊断供排查。')
    from .table import status_label
    label=status_label(raw)
    if label==M('需处理'):label=M('目标需核对')
    return [record('entry.check','error',label,raw,
        M('目标或候选尚未通过检查；本项不能据此视为可写入，正式预检会给出阻止原因。'),action,blocks=True)]


def collect(source=None,settings=None,contours=None,frame=None,status='',error=None,display_warning=None):
    rows=status_records(status,error,display_warning)+source_records(source,settings or {})
    if frame is not None:rows+=frame_records(contours,frame['width'],frame['descender'],frame['ascender'],frame.get('bounds'))
    return sorted(rows,key=lambda row:{'error':0,'warning':1,'info':2}[row['severity']])


def badge(rows):
    return next((r['label'] for r in rows if r['severity']=='error'),None) or next((r['label'] for r in rows if r['severity']=='warning'),None)


def explain(rows,include_info=True):
    return MJ('\n\n',(MF('具体原因：{reason}\n影响范围：{impact}\n处理办法：{action}',reason=r['reason'],impact=r['impact'],action=r['action']) for r in rows if include_info or r['severity']!='info'))


def preview_records(panel,entry,aid,frame=None,contours=None,error=None,status=None):
    from .editor_fonts import entry_warning
    source=None
    if status is None:status=panel.cell_status(entry) if entry else ''
    if aid and not error:
        try:source=panel.parsed_svg(aid)
        except (ValueError,OSError) as exc:error=ms(exc)
    return collect(source,panel.project.state['settings'],contours,frame,
        status=status,error=error,
        display_warning=entry_warning(entry) if entry and status==M('显示字体缺失') else None)
