"""Display frozen single-item candidates. No parsing, selection or scroll view."""
import objc
from AppKit import NSView,NSColor,NSBezierPath,NSAffineTransform,NSFont,NSFontAttributeName,NSForegroundColorAttributeName
from Foundation import NSString


def bezier(contours):
    path=NSBezierPath.bezierPath()
    for contour in contours:
        path.moveToPoint_(contour[0][1])
        for segment in contour[1:]:
            if segment[0]=='L':path.lineToPoint_(segment[1])
            else:path.curveToPoint_controlPoint1_controlPoint2_(segment[3],segment[1],segment[2])
        path.closePath()
    return path

if 'SVGBatchSettingsCanvasV1' not in globals():
    class SVGBatchSettingsCanvasV1(NSView):
        def isFlipped(self):return True
        @objc.python_method
        def setup(self,owner):self.owner=owner;self.snapshot=None;self.message='没有可预览材料'
        @objc.python_method
        def update(self,snapshot=None,message=''):
            self.snapshot=snapshot;self.message=message;self.setNeedsDisplay_(True)
        def drawRect_(self,rect):
            if getattr(self,'owner',None) is None:return
            NSColor.controlBackgroundColor().set();NSBezierPath.bezierPathWithRect_(self.bounds()).fill()
            snapshot=self.snapshot
            if snapshot is None:
                NSString.stringWithString_(self.message or '没有可预览材料').drawInRect_withAttributes_(((12,16),(max(1,self.bounds().size.width-24),100)),{NSFontAttributeName:NSFont.systemFontOfSize_(12),NSForegroundColorAttributeName:NSColor.secondaryLabelColor()});return
            frame=snapshot['frame'];vx,vy,vw,vh=frame['viewport'];size=self.bounds().size
            factor=max(.001,min((size.width-28)/vw,(size.height-28)/vh))
            tx=(size.width-vw*factor)/2-vx*factor;ty=(size.height-vh*factor)/2+(vy+vh)*factor
            x,y,w,h=frame['rect'];box=NSBezierPath.bezierPathWithRect_(((tx+x*factor,ty-(y+h)*factor),(w*factor,h*factor)))
            NSColor.separatorColor().set();box.setLineWidth_(.6);box.stroke()
            baseline=NSBezierPath.bezierPath();baseline.moveToPoint_((tx+x*factor,ty));baseline.lineToPoint_((tx+(x+w)*factor,ty));baseline.setLineWidth_(.5);baseline.stroke()
            transform=NSAffineTransform.transform();transform.setTransformStruct_((factor,0.,0.,-factor,tx,ty))
            for key,color in [('existing',NSColor.secondaryLabelColor().colorWithAlphaComponent_(.55)),('path',NSColor.labelColor())]:
                original=snapshot.get(key)
                if original is not None:
                    path=original.copy();path.transformUsingAffineTransform_(transform);color.set();path.fill()
