"""Session-local window, task and recovery presentation; host work stays main-thread."""
import copy,json,traceback
import vanilla
from AppKit import NSAlert,NSAlertFirstButtonReturn,NSTextView,NSApplication
from .editor_resize import cancel_resize
from .native_collections import descendant_views
from .model import identifier,atomic_json,states_equal
from .panel_actions import ROOT,alert

class DetachedControl:
    """Only draft values survive a child close; no native views/callbacks."""
    def __init__(self,value,items=None):self.value=copy.deepcopy(value);self.items=copy.deepcopy(items)
    def get(self):return copy.deepcopy(self.value)
    def set(self,value):self.value=copy.deepcopy(value)
    def getItems(self):return copy.deepcopy(self.items)

class SessionUI:
    def raise_dialog(self,title):
        w=getattr(self,'dialog_registry',{}).get(title)
        if w is not None and w.getNSWindow() is not None and w.getNSWindow().isVisible():
            w.show();w.getNSWindow().makeKeyAndOrderFront_(None);return True
        return False
    def dialog(self,size,title,parent=None):
        # Dynamic builders call raise_dialog first; hidden transient windows can
        # be disposed before rebuilding, so one title never owns two windows.
        registry=getattr(self,'dialog_registry',None)
        if registry is None:self.dialog_registry={};registry=self.dialog_registry
        old=registry.get(title)
        if old is not None:
            if old.getNSWindow() is not None:old.close()
            if old in self.dialogs:self.dialogs.remove(old)
        from .panel import CompactWindow
        key=NSApplication.sharedApplication().keyWindow()
        parent=parent or next((item for item in self.dialogs if item.getNSWindow() is not None and item.getNSWindow()==key),self.main)
        w=CompactWindow(size,title);w.getNSWindow().batch_owner=self;w._batch_opened=False
        w._batch_parent=parent;w._batch_disposed=False;w._batch_closing=False
        w.bind('should close',lambda sender:self.child_should_close(w))
        w.bind('close',lambda sender:self.dispose_dialog(w))
        registry[title]=w;self.dialogs.append(w);return w
    def ensure_dialog(self,name,builder):
        if getattr(self,name,None) is not None:return
        draft={k:v.get() for k,v in self.w.controls.items() if isinstance(v,DetachedControl)}
        builder()
        for k,value in draft.items():
            control=self.w.controls.get(k)
            if not isinstance(control,DetachedControl):control.set(value)
        if name=='settings_window':self.sync_settings()
        self.refresh()
    def dialog_alive(self,w):
        return w is not None and not getattr(w,'_batch_disposed',False) and w in self.dialogs
    def return_to_parent(self,w):
        if getattr(self,'_closing_cleanup',False) or getattr(self,'_closed',False):return
        parent=getattr(w,'_batch_parent',self.main)
        if getattr(parent,'_batch_closing',False) or getattr(parent,'_batch_disposed',False):return
        if parent is not self.main and not self.dialog_alive(parent):return
        if parent.getNSWindow() is not None:
            parent.show();parent.getNSWindow().makeKeyAndOrderFront_(None)
    def child_should_close(self,w):
        if getattr(w,'_batch_disposed',False) or getattr(w,'_batch_closing',False):return True
        w._batch_closing=True
        # Closing a parent is explicit: retire only its own descendants first.
        for child in list(self.dialogs):
            if getattr(child,'_batch_parent',None) is w:self.finish_dialog(child)
        if getattr(self,'settings_window',None) is w and getattr(self,'settings_queue',None):self.settings_queue.flush()
        if getattr(self,'pdf_intake',None) and self.pdf_intake['window'] is w:self.cancel_pdf_intake()
        if self.gestures.pending and getattr(self.gestures,'group_window',None) is w:
            self.gestures.record('group_cancel',dict(unchanged=self.gestures.pending['before']==self.project.state));self.gestures.pending=None
        if getattr(self,'drop_window',None) is w:self.drop_draft=None;self.drop_overlay={};self.drop_range=None
        return True
    def close_dialog(self,w):
        if w is not None and w.getNSWindow() is not None:w.getNSWindow().performClose_(None)
        return False
    def hide_dialog(self,w):
        if self.dialog_alive(w) and w.getNSWindow() is not None:
            self.child_should_close(w);w.close()
        return False
    def finish_dialog(self,w):return self.hide_dialog(w)
    def dispose_dialog(self,w):
        if getattr(w,'_batch_disposed',False):return
        self.child_should_close(w)
        w._batch_disposed=True
        if getattr(self,'update_window',None) is w and getattr(self,'update_task',None):self.update_task.close()
        if getattr(self,'table',None) is w:
            cancel_resize(self);self.editor_font_runs=None
        window=w.getNSWindow()
        # Freeze editable drafts before Vanilla releases native callback wrappers.
        for name in getattr(w,'_batch_control_names',[]):
            control=getattr(w,name);items=control.getItems() if hasattr(control,'getItems') else None
            self.w.controls[name]=DetachedControl(control.get(),items)
        if window is not None:
            for view in descendant_views(window.contentView()):
                view.removeAllToolTips()
                if hasattr(view,'unregisterDraggedTypes'):view.unregisterDraggedTypes()
                if hasattr(view,'owner'):view.owner=None
            window.batch_owner=None
        if getattr(self,'settings_window',None) is w:
            if getattr(self,'settings_queue',None):self.settings_queue.close()
            self.settings_grid=None
        if getattr(self,'summary',None) is w:self.pending_host=None
        for name,value in list(vars(self).items()):
            if value is w:setattr(self,name,None)
        if getattr(self.gestures,'group_window',None) is w:self.gestures.group_window=None
        self.dialog_registry={k:v for k,v in self.dialog_registry.items() if v is not w}
        if w in self.dialogs:self.dialogs.remove(w)
        self.return_to_parent(w)
    def request_close(self,s=None):
        if getattr(self,'settings_queue',None):self.settings_queue.flush()
        self.cancel_pdf_intake()
        self.cancel_host_read()
        if getattr(self,'_closed',False):return True
        if self.timer:
            self.cancel(None);self.result_message='已停止导入；已写入项和恢复记录保留。再次关闭可退出面板。';self.refresh();return False
        if self.gestures.active:self.gestures.active['cancelled']=True;return False
        if not states_equal(self.project.state,getattr(self,'saved_state',self.project.state)):
            a=NSAlert.alloc().init();a.setMessageText_('关闭前保存校对工程？');a.setInformativeText_('字体与源素材不会改变。选择“关闭”会在用户数据目录保留临时副本，供后续恢复；也可先保存工程。')
            for title in ('保存工程…','关闭','取消'):a.addButtonWithTitle_(title)
            answer=a.runModal()
            if answer==NSAlertFirstButtonReturn:
                self.save(None)
                if not states_equal(self.project.state,getattr(self,'saved_state',{})):return False
            elif answer==NSAlertFirstButtonReturn+1:
                self.project.save(ROOT/'backups'/('session-'+identifier()+'.json'))
                self.saved_state=copy.deepcopy(self.project.state)
            else:return False
        return True
    def escape(self,window):
        focus=window.firstResponder()
        if isinstance(focus,NSTextView) and focus.hasMarkedText():return False
        current=next((w for w in self.dialogs if self.dialog_alive(w) and w.getNSWindow()==window),None)
        if current is not None:self.close_dialog(current);return True
        if getattr(self,'pdf_intake',None):self.pdf_cancel_window();return True
        if getattr(getattr(self,'preview_lookup',None),'running',False):
            self.preview_lookup.stop(True);self.result_message='已取消目标预览读取；工程和对应保持不变';self.refresh();return True
        if getattr(self,'source_task',None):self.cancel_host_read('已取消读取；原工程保持不变');self.refresh();return True
        if self.timer:self.cancel(None);self.refresh();return True
        if getattr(self.gestures,'rubber',None):self.gestures.cancel_rubber();return True
        if self.gestures.active:self.gestures.active['cancelled']=True;return True
        if self.gestures.pending:self.gestures.cancel_group();return True
        if self.drop_draft:self.cancel_drop();return True
        visible=[w for w in self.dialogs if w.getNSWindow() is not None and w.getNSWindow().isVisible()]
        current=next((w for w in visible if w.getNSWindow()==window),None)
        if current is not None:self.close_dialog(current);return True
        if window==self.main.getNSWindow():return True  # Idle Esc never closes a project window.
        return False
    def closed(self,s):
        if getattr(self,'_closed',False):return
        self.cancel_pdf_intake()
        self.cancel_host_read()
        cancel_resize(self);self.editor_font_runs=None
        if getattr(self,'settings_queue',None):self.settings_queue.close()
        if getattr(self,'license_monitor',None):self.license_monitor.stop()
        if getattr(self,'update_task',None):self.update_task.close()
        if getattr(self,'preview_lookup',None):self.preview_lookup.close()
        self.stop_document_observer()
        from .host_index import release
        release(getattr(self,'owner_font',None))
        self._closing_cleanup=True
        # Stop tasks first, before detaching callbacks or traversing native views.
        if self.timer:
            self.timer.invalidate();self.timer=None
            if self.host:self.host.cancelled=True;self.host.journal()
        if getattr(self,'tick_target',None):self.tick_target.owner=None
        self.gestures.active=None;self.gestures.pending=None;self.gestures.rubber=None
        self.save_ui_preferences();failures=[];views=0
        for w in [self.main]+list(self.dialogs):
            window=w.getNSWindow()
            if window is None:continue
            try:
                for view in descendant_views(window.contentView()):
                    view.removeAllToolTips()
                    if hasattr(view,'unregisterDraggedTypes'):view.unregisterDraggedTypes()
                    if hasattr(view,'owner'):view.owner=None
                    views+=1
                window.batch_owner=None
            except Exception:failures.append(traceback.format_exc())
        if failures:
            atomic_json(ROOT/'reports/close-cleanup-error.json',dict(tracebacks=failures,views=views))
            raise RuntimeError('原生窗口清理未完成，完整异常已记录；不能宣称关闭成功')
        # Window-local plans are cancelled on close, never committed or copied
        # into the next native window session. Committed project/recovery stay.
        self.drop_draft=None;self.drop_overlay={};self.drop_range=None
        if getattr(self,'render_cache',None) is not None:self.render_cache.clear()
        self.selection_lookup={}
        for w in list(self.dialogs):
            if w.getNSWindow() is not None:w.close()
        for target in self.menu_targets:target.callback=None
        self.menu_targets.clear()
        self.dialogs.clear();self.dialog_registry={};self.pending_host=None;self._closed=True;self.cleanup_views=views
    def retire_previous(self):
        if not self.host or getattr(self.host,'retired',False) or not any(not r.get('recovered') for r in self.host.records):return True
        if not alert('保留上次导入结果，结束其活动恢复记录并开始新一轮？\n上次完整备份与记录会保留；新一轮写入前另行备份字体当时的真实状态。',True):return False
        self.host.retire();self.archived_hosts.append(self.host);self.host=None;return True
    def recover(self,s=None):
        if self.timer:return
        if self.raise_dialog('恢复本次导入'):return
        if not self.host or self.host.retired:return
        self.check_owner()
        checks=self.host.recovery_check()
        if not checks:alert('本次已无待恢复项目');return
        w=self.recovery_window=self.dialog((760,460),'恢复本次导入')
        self.recovery_checks=checks
        changed=[c for c in checks if c['kind']!='clean'];clean=[c for c in checks if c['kind']=='clean']
        w.caption=vanilla.TextBox((20,18,720,60),'可直接恢复 %d 项；后续变化/结构性冲突 %d 项。\n强制恢复会覆盖列表中“后续变化”目标的整个图层；先完整备份当前字体。'%(len(clean),len(changed)))
        w.rows=vanilla.List((20,90,720,235),[dict(value=c['value'],status=c['reason'] or '无后续变化，可恢复') for c in checks],columnDescriptions=[dict(title='目标',key='value',width=90),dict(title='检查结果',key='status')])
        w.cancel=vanilla.Button((20,365,120,30),'取消',callback=lambda s:self.finish_dialog(w))
        w.clean=vanilla.Button((170,365,240,30),'仅恢复无冲突项' if changed else '恢复本次导入',callback=lambda s:self.apply_recovery('clean'))
        w.clean.enable(bool(clean))
        w.force=vanilla.Button((430,365,310,30),'备份当前状态并强制恢复变化项…',callback=lambda s:self.apply_recovery('force'))
        w.force.enable(bool(changed) and not any(c['kind']=='structural' for c in changed))
        self.show_dialog(w)
    def apply_recovery(self,policy):
        def action():
            if policy=='force' and not alert('将覆盖这些目标在本次导入后的图层修改：\n'+ '、'.join(c['value'] for c in self.recovery_checks if c['kind']=='changed')+'\n会先保存当前完整字体。确认强制恢复？',True):return
            self.check_owner()
            count=self.host.recover(policy,expected=self.recovery_checks)
            remaining=sum(not r.get('recovered') for r in self.host.records)
            self.result_message='已恢复 %d 项；剩余 %d 项待处理'%(count,remaining)
            self.finish_dialog(self.recovery_window)
        self.guard(action)
