from .i18n import message as M,format_message as MF,percent_message as MP,join_message as MJ,string_message as ms,render as R
"""One typed KVO bridge per index; callbacks only mark revisions, never draw/read."""
import objc,weakref
from Foundation import NSObject

if 'SVGBatchIdentityObserverV1' not in globals():
    class SVGBatchIdentityObserverV1(NSObject):
        @objc.typedSelector(b'v@:@@@^v')
        def observeValueForKeyPath_ofObject_change_context_(self,key,obj,change,context):
            owner=self.owner() if self.owner is not None else None
            if owner is not None:owner.changed(ms(key))

def observer(owner):
    value=SVGBatchIdentityObserverV1.alloc().init();value.owner=weakref.ref(owner);return value
