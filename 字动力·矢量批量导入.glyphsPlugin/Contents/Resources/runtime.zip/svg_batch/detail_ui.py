from .i18n import message as M,format_message as MF,percent_message as MP,join_message as MJ,string_message as ms,render as R
"""Live detail presentation over the existing plan and cached preview geometry."""
import copy
from pathlib import Path
from Foundation import NSAttributedString,NSString
from AppKit import NSFont,NSFontAttributeName,NSForegroundColorAttributeName,NSColor
from .detail_text import DetailText
from .detail_preview import SVGBatchDetailCanvasV3
from .outline_bounds import dimensions_text
from .editor_fonts import entry_attributed,entry_warning
from .target_identity import unicode_label,code_caption
from .table import record_problem

def build(panel,cell,Grid):
    from . import localized_ui as vanilla
    if panel.raise_dialog(M('字格详情')):
        refresh(panel);return
    import json
    from AppKit import NSScreen
    from .panel_actions import ROOT
    from .detail_view import window_size
    screen=panel.main.getNSWindow().screen() or NSScreen.mainScreen();visible=screen.visibleFrame()
    try:saved=json.loads((ROOT/'ui-preferences.json').read_text()).get('detail_size',(840,900))
    except (OSError,ValueError,TypeError):saved=(840,900)
    size,minimum=window_size(saved,(visible.size.width,visible.size.height))
    w=panel.dialog(size,M('字格详情'),minSize=minimum)
    w.detail_entry_id=cell['entry']['id'] if cell['kind']=='target' else None
    w.detail_asset_id=cell.get('asset') if cell['kind']=='pool' else None
    w.detail_signature=None
    w.info=DetailText((20,12,-20,44))
    w.zoomHint=vanilla.TextBox((20,62,-210,24),M('⌘＋／－／0 · ⌘滚轮 · 空格拖动'),sizeStyle='small')
    w.zoomSlider=vanilla.Slider((-190,60,170,24),minValue=.5,maxValue=4.,value=getattr(panel,'detail_preview_zoom',1.),continuous=True,callback=lambda sender:w.detail_grid.change_zoom(value=sender.get()))
    w.zoomSlider.getNSSlider().setAccessibilityLabel_(R(M('详情预览缩放')))
    w.preview=vanilla.Group((20,92,-20,-238))
    native=w.preview.getNSView();v=SVGBatchDetailCanvasV3.alloc().initWithFrame_(native.bounds());v.setup(panel);v.setAutoresizingMask_(18)
    native.addSubview_(v);w.detail_grid=v;v.zoom_control=w.zoomSlider
    w.information=DetailText((20,-222,-20,166))
    w.information_text='' 
    if w.detail_entry_id:
        w.editTarget=vanilla.Button((20,-42,370,28),M('修改目标字符／编码…'),callback=lambda sender:panel.open_target_edit(sender,entry_id=w.detail_entry_id,parent=w))
    w.done=vanilla.Button((-200,-42,180,28),M('返回校对'),callback=lambda sender:panel.finish_dialog(w))
    def layout(sender=None):
        from .localized_ui import text_height
        size=w.getNSWindow().contentView().bounds().size
        width=max(1.,float(size.width)-40)
        # One text column, compact to its actual wrapped height. Long provenance
        # scrolls within a bounded information region, never over the buttons.
        needed=text_height(w.information_text,width,13)+8
        height=min(max(36.,needed),min(220.,max(80.,float(size.height)*.28)))
        w.information.setPosSize((20,-56-height,-20,height))
        w.preview.setPosSize((20,92,-20,-70-height))
        w.detail_grid.setNeedsDisplay_(True)
    w.detail_layout=layout
    w.bind('resize',layout)
    panel.show_dialog(w)
    frame=w.getNSWindow().frame()
    w.getNSWindow().setFrameOrigin_((visible.origin.x+(visible.size.width-frame.size.width)/2,visible.origin.y+(visible.size.height-frame.size.height)/2))
    v.observe();layout(None);refresh(panel)


def retire(w):
    """Called before the shared window lifecycle releases its native children."""
    grid=getattr(w,'detail_grid',None)
    if grid is None or not grid.owner:return
    import json,traceback
    from .panel_actions import ROOT
    from .model import atomic_json
    try:
        path=ROOT/'ui-preferences.json'
        try:prefs=json.loads(path.read_text())
        except FileNotFoundError:prefs={}
        if not isinstance(prefs,dict):raise ValueError('Invalid UI preferences; not overwritten')
        size=w.getNSWindow().contentView().bounds().size
        prefs['detail_size']=[float(size.width),float(size.height)];atomic_json(path,prefs)
    except (OSError,ValueError,TypeError):traceback.print_exc()
    finally:grid.retire()


def refresh(panel):
    w=getattr(panel,'dialog_registry',{}).get(M('字格详情'))
    if w is None:return
    from .preview_lookup import scope,PreviewPending
    entry=next((e for e in panel.project.state['entries'] if e['id']==getattr(w,'detail_entry_id',None)),None)
    try:
        with scope(panel,entry):return _refresh(panel)
    except PreviewPending as exc:
        w.detail_signature=None;w.detail_grid.asset=None;w.detail_grid.entry=None;w.detail_grid.snapshot((0.,0.,1000.,1000.),None,None,None,ms(exc))
        w.info.update(ms(exc));w.information_text=R(ms(exc));w.information.update(w.information_text);w.detail_layout()
        return

def _refresh(panel):
    w=getattr(panel,'dialog_registry',{}).get(M('字格详情'))
    if w is None or w.getNSWindow() is None or not w.getNSWindow().isVisible():return
    es=panel.project.state['entries'];eid=w.detail_entry_id
    e=next((e for e in es if e['id']==eid),None) if eid else None
    aid=panel.project.state['assignments'].get(eid) if eid else w.detail_asset_id
    a=panel.project.state['assets'].get(aid)
    if not a:aid=None
    try:
        stat=Path(a['path']).stat() if a else None
        stamp=(stat.st_mtime_ns,stat.st_size) if stat else None
    except OSError:stamp='unavailable'
    fit_context=None
    from .target_fit import enabled,target_context,preview_candidate,description
    if e:
        try:fit_context=target_context(panel.locked_font,panel.locked_master,e)['key']
        except ValueError as exc:fit_context=ms(exc)
    if e and panel.project.state['settings']['existing']=='append':
        from .native_import import preview_layer
        layer=preview_layer(panel.project,aid,panel.locked_font,panel.locked_master,e) if panel.locked_font else None
        fit_context=(fit_context,ms(layer.parent.lastChange) if layer is not None else None)
    signature=copy.deepcopy((fit_context,e,a,panel.project.state['settings'],stamp,panel.errors.get(aid),panel.project.state.get('target_source')))
    if signature==w.detail_signature:return
    w.detail_signature=signature
    # Display provenance and raw character are distinct. Never replace PUA text
    # storage with a fallback glyph name or a drawn placeholder when copying.
    if e:
        display=copy.deepcopy(e)
        if e.get('value'):display.pop('host_binding',None)
        header=entry_attributed(display,13)
    else:
        header=NSAttributedString.alloc().initWithString_(R(M('目标已移除') if eid else M('待分配素材'))).mutableCopy()
    suffix=('  '+code_caption(e) if e else '')+'\n'+((__import__('svg_batch.pdf_pages',fromlist=['name']).name(a['path'],a['pdf_page']) if a.get('pdf_page') is not None else a['name']) if a else M('尚无素材'))
    header.appendAttributedString_(NSAttributedString.alloc().initWithString_attributes_(R(suffix),{NSFontAttributeName:NSFont.systemFontOfSize_(13),NSForegroundColorAttributeName:NSColor.labelColor()}))
    w.info.update(header,NSString.stringWithString_(R(e.get('value',''))).length() if e else 0)
    source=(ms(e.get('source',''))+' · '+e.get('source_location',MF('原第{detail}行',detail=ms(e.get('line',''))))) if e else ''
    if a and a.get('pdf_page') is not None:source+=MF('\n素材来源：{path}{detail}',path=a['path'],detail=MP(M(' · 原始第%d/%d页'),(a['pdf_page'],a['pdf_pages'])))
    detail=(panel.errors.get(aid,'') if aid else '')+('\n'+entry_warning(e) if e else '')
    if e and e.get('host_binding'):
        b=e['host_binding'];detail+=MF('\n宿主字形：{glyph_name} · {detail}；真实对象绑定，非名称猜配。',glyph_name=b['glyph_name'],detail=unicode_label(e) or M('无编码'))
        source+=' · '+panel.project.state.get('target_source',{}).get('description','')
    if e and e.get('code_record'):detail+=MF('\n读取记录：{raw}\n{detail}',raw=e['code_record']['raw'],detail=record_problem(e))
    if e and e.get('target_original'):
        original=e['target_original'];detail+=MF('\n人工修改；原目标：{detail} · 原来源：{detail_2}',detail=MJ(' ',(MP('U+%04X',ord(c)) for c in original['value'])),detail_2=ms(original.get('source','')))
        if original.get('code_record'):detail+=MF(' · 原记录：{detail}',detail=ms(original['code_record'].get('raw','')))
    diagnostic_error=None
    svg=geometry=None
    if aid:
        try:svg=panel.parsed_svg(aid);geometry=panel.geometry(aid,e)
        except Exception as exc:diagnostic_error=ms(exc);detail+=MF('\n尺寸不可用：{detail}',detail=ms(exc))
    try:
        dimensions=dimensions_text(svg,geometry)
        if aid and svg and svg.get('format') in ('EPS','PDF') and panel.project.state['settings'].get('import_method','canvas')!='native':
            from .vector_canvas import preview_candidate as vector_candidate
            result=vector_candidate(panel,aid,e)
            bounds=result.get('source_bounds')
            if bounds:dimensions=dimensions.replace(M('原始笔画尺寸：—（以原生候选为准）'),MP(M('源轮廓：%g × %g（源单位，含原有变换）'),(bounds[2]-bounds[0],bounds[3]-bounds[1])))
            dimensions+=MF('\n采用源画布（X Y 宽 高）：{detail}',detail=MJ(' ',(MP('%g',v) for v in result['source_box'])))
            dimensions+=MF('\n源坐标 → 字体坐标：{detail}',detail=MJ(' ',(MP('%.6g',v) for v in result['source_matrix'])))
            if svg.get('rotation'):dimensions+=MP(M('\n已按页面旋转 %g° 处理'),svg['rotation'])
            if svg.get('warnings_note'):dimensions+='\n'+svg['warnings_note']
    except ValueError as exc:dimensions=dimensions_text();detail+=MF('\n尺寸不可用：{detail}',detail=ms(exc))
    if e and enabled(panel.project.state['settings']):
        try:
            if aid:dimensions+='\n'+description(preview_candidate(panel,aid,e))
            else:
                context=target_context(panel.locked_font,panel.locked_master,e);dimensions+=MP(M('\n目标字格：字宽 %g · 母版 %g → %g'),(context['width'],context['descender'],context['ascender']))
        except ValueError as exc:dimensions+=MF('\n适配不可用：{detail}',detail=ms(exc))
    if e:
        from .preview_reference import reference
        try:
            ref=reference(panel,aid,e)
            dimensions+=MP(M('\n当前字宽 %g → 预计导入字宽 %g\n字格范围：0 → %g；母版 %g → %g%s'),(ref['current_width'],ref['width'],ref['width'],ref['descender'],ref['ascender'],M(' · 轮廓超框') if ref['outside'] else ''))
        except (ValueError,OSError) as exc:diagnostic_error=diagnostic_error or ms(exc);dimensions+=MF('\n字格参照不可用：{detail}',detail=ms(exc))
    from .diagnostics import preview_records,explain
    try:
        diagnostics=preview_records(panel,e,aid,locals().get('ref'),geometry,error=diagnostic_error)
    except (ValueError,OSError) as exc:
        diagnostics=preview_records(panel,e,None,error=ms(exc))
    w.diagnostics=diagnostics
    diagnostic_text=explain(diagnostics)
    information=MJ('\n\n',([diagnostic_text] if diagnostic_text else [])+[MF('来源：{source}\n{detail}',source=source,detail=detail)])
    if panel.project.state['settings']['existing']=='append':dimensions+=M('\n追加：灰色为已有内容，深色为新轮廓；保留原字宽。')
    w.information_text=R(information).rstrip()+'\n'+R(dimensions).strip()
    w.information.update(w.information_text)
    w.detail_layout()
    w.detail_grid.asset=aid;w.detail_grid.entry=e
    try:
        from .target_fit import view_rect
        from .append_preview import existing_path
        w.detail_grid.snapshot(view_rect(panel,aid,e,full=True),view_rect(panel,aid,e),existing_path(panel,e),geometry,error=diagnostic_error)
    except (ValueError,OSError) as exc:
        w.detail_grid.snapshot((0.,0.,1000.,1000.),None,None,None,ms(exc))
    if hasattr(w,'editTarget'):w.editTarget.enable(e is not None)
