from .i18n import message as M,format_message as MF,percent_message as MP,join_message as MJ,string_message as ms,render as R
"""Live detail presentation over the existing plan and cached preview geometry."""
import copy
from pathlib import Path
from Foundation import NSAttributedString,NSString
from AppKit import NSFont,NSFontAttributeName,NSForegroundColorAttributeName,NSColor
from .detail_text import DetailText
from .detail_preview import SVGBatchDetailCanvasV2
from .outline_bounds import dimensions_text
from .editor_fonts import entry_attributed,entry_warning
from .target_identity import unicode_label,code_caption
from .table import record_problem

def build(panel,cell,Grid):
    from . import localized_ui as vanilla
    if panel.raise_dialog(M('字格详情')):
        refresh(panel);return
    w=panel.dialog((700,760),M('字格详情'))
    w.detail_entry_id=cell['entry']['id'] if cell['kind']=='target' else None
    w.detail_asset_id=cell.get('asset') if cell['kind']=='pool' else None
    w.detail_signature=None
    w.info=DetailText((20,18,660,78))
    v=SVGBatchDetailCanvasV2.alloc().initWithFrame_(((0,0),(570,220)));v.setup(panel)
    w.preview=vanilla.ScrollView((20,106,660,230),v,hasHorizontalScroller=True,autohidesScrollers=True);w.detail_grid=v
    w.zoomHint=vanilla.TextBox((20,337,660,22),M('预览缩放：⌘滚轮 · 点按预览后 ⌘＋／－／0'),sizeStyle='small')
    w.source=DetailText((20,368,660,172))
    w.dimensions=DetailText((20,546,660,156))
    if w.detail_entry_id:
        w.editTarget=vanilla.Button((20,716,260,28),M('修改目标字符／编码…'),callback=lambda s:panel.open_target_edit(s,entry_id=w.detail_entry_id,parent=w))
    w.done=vanilla.Button((500,716,180,28),M('返回校对'),callback=lambda s:panel.finish_dialog(w))
    panel.show_dialog(w);refresh(panel)


def refresh(panel):
    w=getattr(panel,'dialog_registry',{}).get(M('字格详情'))
    if w is None:return
    from .preview_lookup import scope,PreviewPending
    entry=next((e for e in panel.project.state['entries'] if e['id']==getattr(w,'detail_entry_id',None)),None)
    try:
        with scope(panel,entry):return _refresh(panel)
    except PreviewPending as exc:
        w.detail_signature=None;w.detail_grid.asset=None;w.detail_grid.entry=None;w.detail_grid.setNeedsDisplay_(True)
        w.info.update(ms(exc));w.source.update(ms(exc));w.dimensions.update('—')
        return

def _refresh(panel):
    w=getattr(panel,'dialog_registry',{}).get(M('字格详情'))
    if w is None or w.getNSWindow() is None or not w.getNSWindow().isVisible():return
    es=panel.project.state['entries'];eid=w.detail_entry_id
    e=next((e for e in es if e['id']==eid),None) if eid else None
    aid=panel.project.state['assignments'].get(eid) if eid else w.detail_asset_id
    a=panel.project.state['assets'].get(aid)
    if not a:aid=None
    try:
        stat=Path(a['path']).stat() if a else None
        stamp=(stat.st_mtime_ns,stat.st_size) if stat else None
    except OSError:stamp='unavailable'
    fit_context=None
    from .target_fit import enabled,target_context,preview_candidate,description
    if e:
        try:fit_context=target_context(panel.locked_font,panel.locked_master,e)['key']
        except ValueError as exc:fit_context=ms(exc)
    if e and panel.project.state['settings']['existing']=='append':
        from .native_import import preview_layer
        layer=preview_layer(panel.project,aid,panel.locked_font,panel.locked_master,e) if panel.locked_font else None
        fit_context=(fit_context,ms(layer.parent.lastChange) if layer is not None else None)
    signature=copy.deepcopy((fit_context,e,a,panel.project.state['settings'],stamp,panel.errors.get(aid),panel.project.state.get('target_source')))
    if signature==w.detail_signature:return
    w.detail_signature=signature
    # Display provenance and raw character are distinct. Never replace PUA text
    # storage with a fallback glyph name or a drawn placeholder when copying.
    if e:
        display=copy.deepcopy(e)
        if e.get('value'):display.pop('host_binding',None)
        header=entry_attributed(display,13)
    else:
        header=NSAttributedString.alloc().initWithString_(R(M('目标已移除') if eid else M('待分配素材'))).mutableCopy()
    suffix=('  '+code_caption(e) if e else '')+'\n'+((__import__('svg_batch.pdf_pages',fromlist=['name']).name(a['path'],a['pdf_page']) if a.get('pdf_page') is not None else a['name']) if a else M('尚无素材'))
    header.appendAttributedString_(NSAttributedString.alloc().initWithString_attributes_(R(suffix),{NSFontAttributeName:NSFont.systemFontOfSize_(13),NSForegroundColorAttributeName:NSColor.labelColor()}))
    w.info.update(header,NSString.stringWithString_(R(e.get('value',''))).length() if e else 0)
    source=(ms(e.get('source',''))+' · '+e.get('source_location',MF('原第{detail}行',detail=ms(e.get('line',''))))) if e else ''
    if a and a.get('pdf_page') is not None:source+=MF('\n素材来源：{path}{detail}',path=a['path'],detail=MP(M(' · 原始第%d/%d页'),(a['pdf_page'],a['pdf_pages'])))
    detail=(panel.errors.get(aid,'') if aid else '')+('\n'+entry_warning(e) if e else '')
    if e and e.get('host_binding'):
        b=e['host_binding'];detail+=MF('\n宿主字形：{glyph_name} · {detail}；真实对象绑定，非名称猜配。',glyph_name=b['glyph_name'],detail=unicode_label(e) or M('无编码'))
        source+=' · '+panel.project.state.get('target_source',{}).get('description','')
    if e and e.get('code_record'):detail+=MF('\n读取记录：{raw}\n{detail}',raw=e['code_record']['raw'],detail=record_problem(e))
    if e and e.get('target_original'):
        original=e['target_original'];detail+=MF('\n人工修改；原目标：{detail} · 原来源：{detail_2}',detail=MJ(' ',(MP('U+%04X',ord(c)) for c in original['value'])),detail_2=ms(original.get('source','')))
        if original.get('code_record'):detail+=MF(' · 原记录：{detail}',detail=ms(original['code_record'].get('raw','')))
    diagnostic_error=None
    svg=geometry=None
    if aid:
        try:svg=panel.parsed_svg(aid);geometry=panel.geometry(aid,e)
        except Exception as exc:diagnostic_error=ms(exc);detail+=MF('\n尺寸不可用：{detail}',detail=ms(exc))
    try:
        dimensions=dimensions_text(svg,geometry)
        if aid and svg and svg.get('format') in ('EPS','PDF') and panel.project.state['settings'].get('import_method','canvas')!='native':
            from .vector_canvas import preview_candidate as vector_candidate
            result=vector_candidate(panel,aid,e)
            bounds=result.get('source_bounds')
            if bounds:dimensions=dimensions.replace(M('原始笔画尺寸：—（以原生候选为准）'),MP(M('源轮廓：%g × %g（源单位，含原有变换）'),(bounds[2]-bounds[0],bounds[3]-bounds[1])))
            dimensions+=MF('\n采用源画布（X Y 宽 高）：{detail}',detail=MJ(' ',(MP('%g',v) for v in result['source_box'])))
            dimensions+=MF('\n源坐标 → 字体坐标：{detail}',detail=MJ(' ',(MP('%.6g',v) for v in result['source_matrix'])))
            if svg.get('rotation'):dimensions+=MP(M('\n已按页面旋转 %g° 处理'),svg['rotation'])
            if svg.get('warnings_note'):dimensions+='\n'+svg['warnings_note']
    except ValueError as exc:dimensions=dimensions_text();detail+=MF('\n尺寸不可用：{detail}',detail=ms(exc))
    if e and enabled(panel.project.state['settings']):
        try:
            if aid:dimensions+='\n'+description(preview_candidate(panel,aid,e))
            else:
                context=target_context(panel.locked_font,panel.locked_master,e);dimensions+=MP(M('\n目标字格：字宽 %g · 母版 %g → %g'),(context['width'],context['descender'],context['ascender']))
        except ValueError as exc:dimensions+=MF('\n适配不可用：{detail}',detail=ms(exc))
    if e:
        from .preview_reference import reference
        try:
            ref=reference(panel,aid,e)
            dimensions+=MP(M('\n当前字宽 %g → 预计导入字宽 %g\n字格范围：0 → %g；母版 %g → %g%s'),(ref['current_width'],ref['width'],ref['width'],ref['descender'],ref['ascender'],M(' · 轮廓超框') if ref['outside'] else ''))
        except (ValueError,OSError) as exc:diagnostic_error=diagnostic_error or ms(exc);dimensions+=MF('\n字格参照不可用：{detail}',detail=ms(exc))
    from .diagnostics import preview_records,explain
    try:
        diagnostics=preview_records(panel,e,aid,locals().get('ref'),geometry,error=diagnostic_error)
    except (ValueError,OSError) as exc:
        diagnostics=preview_records(panel,e,None,error=ms(exc))
    w.diagnostics=diagnostics
    diagnostic_text=explain(diagnostics)
    w.source.update(MJ('\n\n',([diagnostic_text] if diagnostic_text else [])+[MF('来源：{source}\n{detail}',source=source,detail=detail)]))
    if panel.project.state['settings']['existing']=='append':dimensions+=M('\n追加：灰色为已有内容，深色为新轮廓；保留原字宽。')
    w.dimensions.update(dimensions)
    w.detail_grid.asset=aid;w.detail_grid.entry=e
    w.detail_grid.setNeedsDisplay_(True)
    if hasattr(w,'editTarget'):w.editTarget.enable(e is not None)
