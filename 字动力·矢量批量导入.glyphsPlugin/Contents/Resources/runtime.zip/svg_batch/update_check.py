"""Explicit public metadata reads only. Pure parsing/comparison; no user data."""
import plistlib,time,subprocess
from urllib.parse import quote
PRODUCT='local.svg-batch-import'
SOURCE='https://raw.githubusercontent.com/dutao6678/zidongli-plugins/main/packages.plist'
REPOSITORY='https://github.com/dutao6678/zidongli-plugins'

def build_number(value):
    if isinstance(value,bool) or not str(value).isdigit():raise ValueError('发布数据中的build不是有效非负整数')
    return int(value)

def compare(current,remote):
    if remote.get('CFBundleIdentifier')!=PRODUCT:raise ValueError('公开清单中未找到本产品标识')
    build=build_number(remote.get('CFBundleVersion',''))
    version=remote.get('CFBundleShortVersionString')
    if not isinstance(version,str) or not version.strip():raise ValueError('公开版本号缺失')
    relation='newer' if build>current['build'] else 'same' if build==current['build'] else 'local'
    title={'newer':'发现较新的公开版本','same':'已是当前公开版本','local':'当前为较新的本地测试版'}[relation]
    detail='%s\n当前：%s · build %d\n公开：%s · build %d'%(title,current['version'],current['build'],version,build)
    if relation=='newer':detail+='\n请通过 Glyphs 插件管理器检查更新；本窗口不下载或安装。'
    elif relation=='local':detail+='\n无需降级；公开源暂未包含本地手测修订。'
    return dict(relation=relation,text=detail,version=version,build=build)

def fetch_public(current,cancel,read=None):
    deadline=time.monotonic()+18
    def fetch(url):
        if cancel.is_set():raise ValueError('检查已取消')
        if read is not None:return read(url)
        remaining=deadline-time.monotonic()
        if remaining<=0:raise TimeoutError('更新检查超时')
        # macOS system curl uses the system trust configuration; never disable TLS.
        process=subprocess.run(['/usr/bin/curl','--location','--fail','--silent','--show-error',
            '--proto','=https','--proto-redir','=https','--max-time',str(min(6,remaining)),
            '--max-filesize','1048576','--user-agent','ZiDongLi-Update-Check',url],
            capture_output=True,timeout=min(6,remaining)+2)
        if process.returncode:raise ValueError('公开源请求失败：'+process.stderr.decode('utf-8','replace').strip()[:500])
        data=process.stdout
        if len(data)>1024*1024:raise ValueError('公开元数据过大')
        return data
    try:
        manifest=plistlib.loads(fetch(SOURCE));plugins=manifest['packages']['plugins']
        if not isinstance(plugins,list):raise ValueError('插件清单格式无效')
        for item in plugins:
            if not isinstance(item,dict) or item.get('url','').removesuffix('.git').rstrip('/')!=REPOSITORY:continue
            path=item.get('path');branch=item.get('branch','main')
            if not isinstance(path,str) or not path.endswith('.glyphsPlugin') or '..' in path.split('/') or path.startswith('/'):raise ValueError('产品包路径无效')
            if not isinstance(branch,str) or not branch:raise ValueError('产品分支无效')
            url='https://raw.githubusercontent.com/dutao6678/zidongli-plugins/'+quote(branch,safe='')+'/'+quote(path,safe='/')+'/Contents/Info.plist'
            info=plistlib.loads(fetch(url))
            if info.get('CFBundleIdentifier')!=PRODUCT:continue
            result=compare(current,info)
            descriptions=item.get('descriptions',{})
            note=descriptions.get('zh-Hans',descriptions.get('en','')) if isinstance(descriptions,dict) else ''
            if isinstance(note,str) and note:result['text']+='\n\n公开说明：'+note[:2000]
            result['source']=SOURCE;return result
        raise ValueError('公开清单中未找到本产品标识')
    except (KeyError,TypeError,plistlib.InvalidFileException) as exc:raise ValueError('公开发布数据无效：'+str(exc)) from exc
