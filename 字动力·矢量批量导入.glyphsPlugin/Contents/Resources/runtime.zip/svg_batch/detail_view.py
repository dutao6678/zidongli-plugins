"""Pure detail view transform. No source, host, project or import parameters."""
import math

class ViewTransform:
    def __init__(self,zoom=1.):
        self.zoom=max(.5,min(4.,float(zoom)));self.pan=(0.,0.);self.size=(1.,1.);self.viewport=(0.,0.,1000.,1000.)
    @property
    def factor(self):
        w,h=self.size;_,_,vw,vh=self.viewport
        return max(.000001,min(max(1.,w-24)/vw,max(1.,h-24)/vh))*self.zoom
    def origin(self):
        w,h=self.size;_,_,vw,vh=self.viewport;f=self.factor
        return ((w-vw*f)/2+self.pan[0]*f,(h-vh*f)/2+self.pan[1]*f)
    def world(self,point):
        x,y=self.origin();return ((point[0]-x)/self.factor,(point[1]-y)/self.factor)
    def change(self,value=None,direction=0,point=None,reset=False):
        if reset or (value is None and not direction):self.zoom=1.;self.pan=(0.,0.);return
        w,h=self.size;point=point or (w/2,h/2);a=self.world(point)
        v=value if value is not None else self.zoom+direction*.125
        if not math.isfinite(v):return
        self.zoom=round(max(.5,min(4.,v)),3);f=self.factor;_,_,vw,vh=self.viewport
        self.pan=((point[0]-(w-vw*f)/2)/f-a[0],(point[1]-(h-vh*f)/2)/f-a[1])
    def drag(self,pan,delta):self.pan=(pan[0]+delta[0]/self.factor,pan[1]+delta[1]/self.factor)


def window_size(saved,available):
    aw,ah=available;maximum=(max(1.,aw-32),max(1.,ah-56));minimum=(min(640.,maximum[0]),min(560.,maximum[1]))
    try:
        w,h=map(float,saved)
        if not math.isfinite(w+h):raise ValueError()
    except (TypeError,ValueError):w,h=840.,900.
    return tuple(max(lo,min(hi,v)) for lo,hi,v in zip(minimum,maximum,(w,h))),minimum
